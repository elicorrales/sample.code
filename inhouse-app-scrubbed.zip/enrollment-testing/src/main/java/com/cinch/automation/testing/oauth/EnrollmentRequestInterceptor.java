package com.cinch.automation.testing.oauth;

import java.io.IOException;

import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpResponse;

public class EnrollmentRequestInterceptor extends OAuthHttpRequestInterceptor {
  private String apiKey;

  public EnrollmentRequestInterceptor(String apiKey) {
    this.apiKey = apiKey;
  }

  @Override
  public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
    request.getHeaders().add("X-Api-Key", apiKey);
    super.traceRequest(request, body);
    ClientHttpResponse response = execution.execute(request, body);
    super.traceResponse(response);
    return response;
  }

}
