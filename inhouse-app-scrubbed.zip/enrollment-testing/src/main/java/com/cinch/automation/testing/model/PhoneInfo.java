package com.cinch.automation.testing.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PhoneInfo implements Serializable {



	/**
	 * 
	 */
	private static final long serialVersionUID = 6936049159194927218L;

	String cellPhone;
	String workPhone;
	String altPhone;
	
	Phone homePhone;
	Phone availablePhone;

	public String getCellPhone() {
		return cellPhone;
	}
	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}
	public String getWorkPhone() {
		return workPhone;
	}
	public void setWorkPhone(String workPhone) {
		this.workPhone = workPhone;
	}
	public String getAltPhone() {
		return altPhone;
	}
	public void setAltPhone(String altPhone) {
		this.altPhone = altPhone;
	}
	public Phone getHomePhone() {
		return homePhone;
	}
	public void setHomePhone(Phone homePhone) {
		this.homePhone = homePhone;
	}
	public Phone getAvailablePhone() {
		return availablePhone;
	}
	public void setAvailablePhone(Phone availablePhone) {
		this.availablePhone = availablePhone;
	}


	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PhoneInfo [cellPhone=");
		builder.append(cellPhone);
		builder.append(", workPhone=");
		builder.append(workPhone);
		builder.append(", altPhone=");
		builder.append(altPhone);
		builder.append(", homePhone=");
		builder.append(homePhone);
		builder.append(", availablePhone=");
		builder.append(availablePhone);
		builder.append("]");
		return builder.toString();
	}
}