package com.cinch.automation.testing.model;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TelemarketingTableEntry  {

	private String id;	
	private String cellCode;	
	private String tollFree;	
	private String createdDate;
	private String updatedDate;
	private String publishedDate;
	@NotNull(message="Please enter a start date.")
	private String cellCodeStartDate;
	@NotNull(message="Please enter an end date.")
	private String cellCodeEndDate;
	private String description;	
	private String createdBy;
	private String updatedBy;	
	private String lastUserActivity;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCellCode() {
		return cellCode;
	}
	public void setCellCode(String cellCode) {
		this.cellCode = cellCode;
	}
	public String getTollFree() {
		return tollFree;
	}
	public void setTollFree(String tollFree) {
		this.tollFree = tollFree;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getPublishedDate() {
		return publishedDate;
	}
	public void setPublishedDate(String publishedDate) {
		this.publishedDate = publishedDate;
	}
	public String getCellCodeStartDate() {
		return cellCodeStartDate;
	}
	public void setCellCodeStartDate(String cellCodeStartDate) {
		this.cellCodeStartDate = cellCodeStartDate;
	}
	public String getCellCodeEndDate() {
		return cellCodeEndDate;
	}
	public void setCellCodeEndDate(String cellCodeEndDate) {
		this.cellCodeEndDate = cellCodeEndDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getLastUserActivity() {
		return lastUserActivity;
	}
	public void setLastUserActivity(String lastUserActivity) {
		this.lastUserActivity = lastUserActivity;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TelemarketingTableEntry [id=");
		builder.append(id);
		builder.append(", cellCode=");
		builder.append(cellCode);
		builder.append(", tollFree=");
		builder.append(tollFree);
		builder.append(", createdDate=");
		builder.append(createdDate);
		builder.append(", updatedDate=");
		builder.append(updatedDate);
		builder.append(", publishedDate=");
		builder.append(publishedDate);
		builder.append(", cellCodeStartDate=");
		builder.append(cellCodeStartDate);
		builder.append(", cellCodeEndDate=");
		builder.append(cellCodeEndDate);
		builder.append(", description=");
		builder.append(description);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", updatedBy=");
		builder.append(updatedBy);
		builder.append(", lastUserActivity=");
		builder.append(lastUserActivity);
		builder.append("]");
		return builder.toString();
	}
}
