package com.cinch.automation.testing.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CreditCardInformation implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 4843897773054804058L;

	String creditCardNumber = "4055011111111111";
	
	// the other values seem to be pre-populated from the GET enrollment API call
	
	String creditCardTypeCode;
	String expirationMonth;
	String expirationYear;
	String holderFirstName;
	String holderMiddleName;
	String holderLastName;
	String securityCode;
	String expirationDate;
	
	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public String getCreditCardTypeCode() {
		return creditCardTypeCode;
	}
	public void setCreditCardTypeCode(String creditCardTypeCode) {
		this.creditCardTypeCode = creditCardTypeCode;
	}
	public String getExpirationMonth() {
		return expirationMonth;
	}
	public void setExpirationMonth(String expirationMonth) {
		this.expirationMonth = expirationMonth;
	}
	public String getExpirationYear() {
		return expirationYear;
	}
	public void setExpirationYear(String expirationYear) {
		this.expirationYear = expirationYear;
	}
	public String getHolderFirstName() {
		return holderFirstName;
	}
	public void setHolderFirstName(String holderFirstName) {
		this.holderFirstName = holderFirstName;
	}
	public String getHolderMiddleName() {
		return holderMiddleName;
	}
	public void setHolderMiddleName(String holderMiddleName) {
		this.holderMiddleName = holderMiddleName;
	}
	public String getHolderLastName() {
		return holderLastName;
	}
	public void setHolderLastName(String holderLastName) {
		this.holderLastName = holderLastName;
	}
	public String getSecurityCode() {
		return securityCode;
	}
	public void setSecurityCode(String securityCode) {
		this.securityCode = securityCode;
	}
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CreditCardInformation [creditCardNumber=");
		builder.append(creditCardNumber);
		builder.append(", creditCardTypeCode=");
		builder.append(creditCardTypeCode);
		builder.append(", expirationMonth=");
		builder.append(expirationMonth);
		builder.append(", expirationYear=");
		builder.append(expirationYear);
		builder.append(", holderFirstName=");
		builder.append(holderFirstName);
		builder.append(", holderMiddleName=");
		builder.append(holderMiddleName);
		builder.append(", holderLastName=");
		builder.append(holderLastName);
		builder.append(", securityCode=");
		builder.append(securityCode);
		builder.append(", expirationDate=");
		builder.append(expirationDate);
		builder.append("]");
		return builder.toString();
	}

}