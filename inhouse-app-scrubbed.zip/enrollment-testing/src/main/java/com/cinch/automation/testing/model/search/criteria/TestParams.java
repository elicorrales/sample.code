package com.cinch.automation.testing.model.search.criteria;

import java.util.List;

import com.cchs.microservice.dto.product.ProductAdditional;
import com.cchs.microservice.dto.product.ProductComboOption;
import com.cchs.microservice.dto.product.ProductOption;
//import com.cinch.automation.testing.model.ProductComboOption;
//import com.cinch.automation.testing.model.ProductOption;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TestParams {

	private String clientId;
	private String cellCode;
	private String zip;
	private String newDeduct;
	private String buydwnCost;
	private String pymtType;
	private String pymtFreq;
	private String indCode;
	private String enrDate;
	private String prodGenSeq;
	
	private List<ProductComboOption> comboOptions;
	private List<ProductOption> options;
	private List<ProductAdditional> additionals;
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getCellCode() {
		return cellCode;
	}
	public void setCellCode(String cellCode) {
		this.cellCode = cellCode;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getNewDeduct() {
		return newDeduct;
	}
	public void setNewDeduct(String newDeduct) {
		this.newDeduct = newDeduct;
	}
	public String getBuydwnCost() {
		return buydwnCost;
	}
	public void setBuydwnCost(String buydwnCost) {
		this.buydwnCost = buydwnCost;
	}
	public String getPymtType() {
		return pymtType;
	}
	public void setPymtType(String pymtType) {
		this.pymtType = pymtType;
	}
	public String getPymtFreq() {
		return pymtFreq;
	}
	public void setPymtFreq(String pymtFreq) {
		this.pymtFreq = pymtFreq;
	}
	public String getIndCode() {
		return indCode;
	}
	public void setIndCode(String indCode) {
		this.indCode = indCode;
	}
	public String getEnrDate() {
		return enrDate;
	}
	public void setEnrDate(String enrDate) {
		this.enrDate = enrDate;
	}
	public String getProdGenSeq() {
		return prodGenSeq;
	}
	public void setProdGenSeq(String prodGenSeq) {
		this.prodGenSeq = prodGenSeq;
	}
	public List<ProductComboOption> getComboOptions() {
		return comboOptions;
	}
	public void setComboOptions(List<ProductComboOption> comboOptions) {
		this.comboOptions = comboOptions;
	}
	public List<ProductOption> getOptions() {
		return options;
	}
	public void setOptions(List<ProductOption> options) {
		this.options = options;
	}
	public List<ProductAdditional> getAdditionals() {
		return additionals;
	}
	public void setAdditionals(List<ProductAdditional> additionals) {
		this.additionals = additionals;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TestParams [clientId=");
		builder.append(clientId);
		builder.append(", cellCode=");
		builder.append(cellCode);
		builder.append(", zip=");
		builder.append(zip);
		builder.append(", newDeduct=");
		builder.append(newDeduct);
		builder.append(", buydwnCost=");
		builder.append(buydwnCost);
		builder.append(", pymtType=");
		builder.append(pymtType);
		builder.append(", pymtFreq=");
		builder.append(pymtFreq);
		builder.append(", indCode=");
		builder.append(indCode);
		builder.append(", enrDate=");
		builder.append(enrDate);
		builder.append(", prodGenSeq=");
		builder.append(prodGenSeq);
		builder.append(", comboOptions=");
		builder.append(comboOptions);
		builder.append(", options=");
		builder.append(options);
		builder.append(", additionals=");
		builder.append(additionals);
		builder.append("]");
		return builder.toString();
	}

	
	
}
