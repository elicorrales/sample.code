package com.cinch.automation.testing.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EnrollmentPricing {

	String enrollmentTotalPremiumPrice;
	String enrollmentTax;

	public String getEnrollmentTotalPremiumPrice() {
		return enrollmentTotalPremiumPrice;
	}
	public void setEnrollmentTotalPremiumPrice(String enrollmentTotalPremiumPrice) {
		this.enrollmentTotalPremiumPrice = enrollmentTotalPremiumPrice;
	}
	public String getEnrollmentTax() {
		return enrollmentTax;
	}
	public void setEnrollmentTax(String enrollmentTax) {
		this.enrollmentTax = enrollmentTax;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EnrollmentPricing [enrollmentTotalPremiumPrice=");
		builder.append(enrollmentTotalPremiumPrice);
		builder.append(", enrollmentTax=");
		builder.append(enrollmentTax);
		builder.append("]");
		return builder.toString();
	}
}