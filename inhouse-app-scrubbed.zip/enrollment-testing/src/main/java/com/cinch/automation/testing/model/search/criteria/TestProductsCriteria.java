package com.cinch.automation.testing.model.search.criteria;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TestProductsCriteria {

    int    nextIdxToTest;
    List<TestParams> testList;

	public int getNextIdxToTest() {
		return nextIdxToTest;
	}

	public void setNextIdxToTest(int nextIdxToTest) {
		this.nextIdxToTest = nextIdxToTest;
	}

	public List<TestParams> getTestList() {
		return testList;
	}

	public void setTestList(List<TestParams> testList) {
		this.testList = testList;
	}

}