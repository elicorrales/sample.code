package com.cinch.automation.testing.model.search.criteria;


public class FindContractInfoSearchCriteria {


	private String contract;

	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = contract;
	}
	
	
}