package com.cinch.automation.testing.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BillingTerm {

	String description;
	String paymentPlanId;
	String billingMechanismCode;
	String paymentFrequency;
	String industryCode;
	String enrollmentType;

	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPaymentPlanId() {
		return paymentPlanId;
	}
	public void setPaymentPlanId(String paymentPlanId) {
		this.paymentPlanId = paymentPlanId;
	}
	public String getBillingMechanismCode() {
		return billingMechanismCode;
	}
	public void setBillingMechanismCode(String billingMechanismCode) {
		this.billingMechanismCode = billingMechanismCode;
	}
	public String getPaymentFrequency() {
		return paymentFrequency;
	}
	public void setPaymentFrequency(String paymentFrequency) {
		this.paymentFrequency = paymentFrequency;
	}
	public String getIndustryCode() {
		return industryCode;
	}
	public void setIndustryCode(String industryCode) {
		this.industryCode = industryCode;
	}
	public String getEnrollmentType() {
		return enrollmentType;
	}
	public void setEnrollmentType(String enrollmentType) {
		this.enrollmentType = enrollmentType;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BillingTerm [description=");
		builder.append(description);
		builder.append(", paymentPlanId=");
		builder.append(paymentPlanId);
		builder.append(", billingMechanismCode=");
		builder.append(billingMechanismCode);
		builder.append(", paymentFrequency=");
		builder.append(paymentFrequency);
		builder.append(", industryCode=");
		builder.append(industryCode);
		builder.append(", enrollmentType=");
		builder.append(enrollmentType);
		builder.append("]");
		return builder.toString();
	}

}
