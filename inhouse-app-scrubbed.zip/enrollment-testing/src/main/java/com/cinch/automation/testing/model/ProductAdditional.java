package com.cinch.automation.testing.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductAdditional {

	String categoryId;
	String description;
	String itemCode;
	String quantityCoveredByDefault;
	String maxAdditionalQuantity;
	String costPerAdditionalItem;
	String quantitySelected;

	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getQuantityCoveredByDefault() {
		return quantityCoveredByDefault;
	}
	public void setQuantityCoveredByDefault(String quantityCoveredByDefault) {
		this.quantityCoveredByDefault = quantityCoveredByDefault;
	}
	public String getMaxAdditionalQuantity() {
		return maxAdditionalQuantity;
	}
	public void setMaxAdditionalQuantity(String maxAdditionalQuantity) {
		this.maxAdditionalQuantity = maxAdditionalQuantity;
	}
	public String getCostPerAdditionalItem() {
		return costPerAdditionalItem;
	}
	public void setCostPerAdditionalItem(String costPerAdditionalItem) {
		this.costPerAdditionalItem = costPerAdditionalItem;
	}
	public String getQuantitySelected() {
		return quantitySelected;
	}
	public void setQuantitySelected(String quantitySelected) {
		this.quantitySelected = quantitySelected;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ProductAdditional [categoryId=");
		builder.append(categoryId);
		builder.append(", description=");
		builder.append(description);
		builder.append(", itemCode=");
		builder.append(itemCode);
		builder.append(", quantityCoveredByDefault=");
		builder.append(quantityCoveredByDefault);
		builder.append(", maxAdditionalQuantity=");
		builder.append(maxAdditionalQuantity);
		builder.append(", costPerAdditionalItem=");
		builder.append(costPerAdditionalItem);
		builder.append(", quantitySelected=");
		builder.append(quantitySelected);
		builder.append("]");
		return builder.toString();
	}

}
