package com.cinch.automation.testing.controllers;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class VersionController {

    private String applicationName;
 
    private String buildVersion;
 
    private String buildTimestamp;
 
    private String appEncoding;
 
    private String appJavaVersion;
 
    @Autowired
    public void setApplicationName(@Value("${application.name}") String applicationName) { this.applicationName = applicationName; }
 
    @Autowired
    public void setBuildVersion(@Value("${build.version}") String buildVersion) { this.buildVersion = buildVersion; }
 
    @Autowired
    public void setBuildTimestamp(@Value("${build.timestamp}") String buildTimestamp) { this.buildTimestamp = buildTimestamp; }
 
    @Autowired
    public void setAppEncoding(@Value("${app.encoding}") String appEncoding) { this.appEncoding = appEncoding; }
 
    @Autowired
    public void setAppJavaVersion(@Value("${app.java.version}") String appJavaVersion) { this.appJavaVersion = appJavaVersion; }
 
 
    @GetMapping("/buildinfo")
    public ResponseEntity<?> version() {
 
        Map<String, String> propertiesMap = new HashMap<String,String>();
        propertiesMap.put("buildVersion", buildVersion);
        propertiesMap.put("applicationName", applicationName);
        propertiesMap.put("buildTimestamp", buildTimestamp);
        propertiesMap.put("appEncoding", appEncoding);
        propertiesMap.put("appJavaVersion", appJavaVersion);
 
 
        return ResponseEntity.ok(propertiesMap);
    }
}
