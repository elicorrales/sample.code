package com.cinch.automation.testing.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cchs.microservice.dto.product.ProductPlan;
import com.cinch.automation.testing.api.services.BackendApiServices;
import com.cinch.automation.testing.model.EnrollmentResult;
import com.cinch.automation.testing.model.TelemarketingTableEntry;
import com.cinch.automation.testing.model.search.criteria.FindProductListSearchCriteria;
import com.cinch.automation.testing.model.search.criteria.TestParams;
import com.cinch.automation.testing.model.search.criteria.TestProductsCriteria;
import com.cinch.automation.testing.model.ui.response.CellCodesAjaxResponseBody;
import com.cinch.automation.testing.model.ui.response.ContractInfoAjaxResponseBody;
import com.cinch.automation.testing.model.ui.response.EnrollmentsAjaxResponseBody;
import com.cinch.automation.testing.model.ui.response.ProductsAjaxResponseBody;
import com.cinch.automation.testing.model.ui.response.ResponseBody;
import com.cinch.automation.testing.util.EnrollmentTestingAsyncTask;


/************************************************************************************************************************************************
*************************************************************************************************************************************************
 * This class is the Java-world single entry-point of the application (in a sense). It handles all of the client browser's ajax calls.
 * 
 * On the browser side, it is set up as an SPA (single-page app), and all requests to server-side are via ajax calls.
 * 
 * The main wrinkle with this class is seen in the product/enrollment-testing loop. It has to contend with:
 * - maximum number of products
 * - maximum number of product to handle per request
 * - keeping track of last product handled (this is tag-teamed with the browser)
 * 
 * This controller uses a Service for the actual back-end API calls
 * 
 * The remaining classes in this application are model or parameter objects
 * 
 * @see com.cinch.automation.testing.util.EnrollmentTestingAsyncTask#call()
 * 
 * @author ecorrales
 *
*************************************************************************************************************************************************
************************************************************************************************************************************************/
@RestController
public class FrontEndClientAjaxController {

	private static final Logger logger = LoggerFactory.getLogger(FrontEndClientAjaxController.class);

	private int numProdBatchSize = 16;
	
	private ExecutorService taskPool = Executors.newFixedThreadPool(16);

	private BackendApiServices services;

	@Autowired
	public void setServices(BackendApiServices services) { this.services = services; }

	@Autowired
	public void setNumProductsBatchSize(@Value("${number.products.batch.size}") int numProdBatchSize) {

		this.numProdBatchSize = numProdBatchSize;
	}


	/*************************************************************************************************************************
	 * This method is usually called upon page load, in order to provide a list of cell codes to the user
	 * within the initial product-search form.
	 * The method invokes a backend REST service.
	 * 
	 * @return the response entity - an array of cell codes
	 ************************************************************************************************************************/
    @GetMapping("/cellcodes")
    public ResponseEntity<?> loadCellCodes() {

    	logger.debug("/cellcodes");

        CellCodesAjaxResponseBody result = new CellCodesAjaxResponseBody();

        try {

        	TelemarketingTableEntry[] entries = services.findCellCodes();

        	if (null == entries || 0 == entries.length) {

            	result.setMsg("no cell codes found!");

        	} else {

            	result.setMsg("success: found cell codes");
        	}

        	result.setCellCodes(entries);

        	return ResponseEntity.ok(result);

        } catch (Exception e) {
        	String errorMessage = "Error finding cell codes: " + e.getMessage();
        	logger.error(errorMessage,e);
        	result.setMsg(errorMessage);
        	return ResponseEntity.badRequest().body(result);
        	
        }

    }

 
 
	/*************************************************************************************************************************
     * This method handles the user's initial search-product form submission.
     * It returns all products found for the specific parameter combination.
     * 
     * @param critera - all of the product-search form's input parameters
     * @param errors - any errors encountered by invoking the backend API service
     * @return the response entity - an array of ProductPlan
     ************************************************************************************************************************/
    @PostMapping("/products")
    public ResponseEntity<?> getSearchProducts(@Valid @RequestBody FindProductListSearchCriteria critera, Errors errors) {


    	logger.debug("/products");

        ProductsAjaxResponseBody result = new ProductsAjaxResponseBody();

        if (errors.hasErrors()) {
            return handleIncomingErrors(errors,result);
        }

        try {

        	ProductPlan[] products = services.findProductsByClientIdCellZip(critera.getClientId(),critera.getCellCode(),critera.getZip());

        	if (null == products || 0 == products.length) {
            	result.setMsg("no products found!");
        	} else {
            	result.setMsg("success: found products");
        	}

        	result.setProductPlans(products);

        	return ResponseEntity.ok(result);

        } catch (Exception e) {
        	
        	String errorMessage = "Error finding products: " + e.getMessage();
        	logger.error(errorMessage,e);
        	result.setMsg(errorMessage);
        	return ResponseEntity.badRequest().body(result);
        	
        }

    }

 
    
	/*************************************************************************************************************************
     * This method handles the user's enrollment-testing form submission.
     * It invokes a series of backend API services to gather more information and
     * to subsequently perform the test (attempt an enrollment).
     * The test result is either a contract number, or an error message describing
     * why the test failed.
     * The parameters (criteria) are such that this method can invoke a series of tests
     * concurrently, waiting for all tests before returning the results.
     * It may not handle all of the requested tests. The maximum number of tests
     * it will execute depend on the numProdBatchSize.
     * In addition to returning test results, it returns the index into the test list
     * where it left off.
     * The idea is for the client page to re-submit the same list, including the
     * updated index.
     * The purpose behind this technique is to provide a more responsive UI.
     * For instance, the UI could provide a regularly updated table of data, and also
     * a progress bar.
     * It returns all products found for the specific parameter combination.
     * 
     * @param criteria all of the enrollment-test (a list) requests, and current starting index
     * @param errors any input errors
     * @return the response entity - a list of EnrollmentResult, which could include contract numbers, or specific errors, or communication errors
     ************************************************************************************************************************/
    @PostMapping("/enrollments")
    public ResponseEntity<?> testProductsRequestEnrollments(@Valid @RequestBody TestProductsCriteria criteria, Errors errors) {

    	logger.debug("/enrollments");

        EnrollmentsAjaxResponseBody result = new EnrollmentsAjaxResponseBody();

        if (errors.hasErrors()) {
            return handleIncomingErrors(errors,result);
        }

       	List<EnrollmentResult> enrollmentResults = new ArrayList<EnrollmentResult>();
        
       	try {

       		List<TestParams> testList = criteria.getTestList();
       		int nextIdxToTest         = criteria.getNextIdxToTest();

    	   	List<Future<EnrollmentResult>> enrFutureResults = new ArrayList<>();

    	   	int tempNumProdBatchSize = numProdBatchSize;
    	   	// let's respond more quickly with the first batch of tests to give user a warm-fuzzy
    	   	if (0==nextIdxToTest && testList.size() > 8) {

    	   		tempNumProdBatchSize = 4;
    	   	} 

    	   	// This loop creates test executions from the incoming test list, as asynchronous tasks given
    	   	// to the task pool.
    	   	// There are two different limits that can cause the loop to exit.
    	   	//
    	   	// 1 - the number of items(tests) in the test list - we reached the end of the list.
    	   	// 2 - the limit to the items that will be handled in this call from the outside (the batch size).
    	   	//
    	   	// It is very likely that the batch size is smaller than the number of items in the test list.
    	   	// Thus, 'i' is the counter that keeps track of the test list, and 'j' keeps track of the batch size.
    	   	// The loop will terminate for whichever (i or j) reaches its limit first.
    	   	// Because of the probability/possibility that not all items will be handled during this invocation,
    	   	// there exists a 'nextIdxToTest' that is returned back to the front-end UI, so it knows how far
    	   	// through the test list was processed.
       		for (int i=nextIdxToTest,j=0;j<tempNumProdBatchSize && i<testList.size();i++,j++) { 

       			TestParams params = testList.get(i);
       			
       			Future<EnrollmentResult> future = taskPool.submit(new EnrollmentTestingAsyncTask(services,params));
 
       			nextIdxToTest++;

       			enrFutureResults.add(future);

       		}

       		for (Future<EnrollmentResult> enr : enrFutureResults) {

       			EnrollmentResult enrRes = enr.get();
       			enrollmentResults.add(enrRes);
       		}

       		
   			if (0 < enrollmentResults.size()) {
   				
   				result.setEnrollmentResults(enrollmentResults.toArray(enrollmentResults.stream().toArray(EnrollmentResult[]::new)));
   			}

           	result.setMsg("success: tested enrollments");

   			result.setNextProductToTestIdx(nextIdxToTest);

           	return ResponseEntity.ok(result);

       	} catch (Exception e) {
        		
        	String errorMessage = "Error testing enrollments: " + e.getMessage();
        	logger.error(errorMessage,e);
        	result.setMsg(errorMessage);
       		return ResponseEntity.badRequest().body(result);
       	}
        

    }


 
 
 
	/*************************************************************************************************************************
     * This method was intended to be tied to a hyperlink in the UI page, one for each successful enrollment.
     * It return a JSON string that is the actual contract information.
     * 
     * @param contract the contract number
     * @return the raw JSON contract information
     ************************************************************************************************************************/
    @GetMapping("/contractinfo/{contract}")
    public ResponseEntity<?> getContractInfo(@Valid @PathVariable("contract") String contract) {

    	logger.debug("/contractinfo/{contract}");

        ContractInfoAjaxResponseBody result = new ContractInfoAjaxResponseBody();

        try {

        	String json = services.findContractInfoByContractNumber(contract);

        	if (null == json || 0 == json.length()) {

            	result.setMsg("no contract info found!");

        	} else {

            	result.setMsg("success: found contract info");
        	}

        	result.setResult(json);

        	return ResponseEntity.ok(result);

        } catch (Exception e) {
        	
        	String errorMessage = "Error finding contract info: " + e.getMessage();
        	logger.error(errorMessage,e);
        	result.setMsg(errorMessage);
        	return ResponseEntity.badRequest().body(result);
        	
        }

    } 

    
    private ResponseEntity<?> handleIncomingErrors(Errors errors, ResponseBody body) {
            body.setMsg(errors.getAllErrors() .stream().map(x -> x.getDefaultMessage()) .collect(Collectors.joining(",")));
            return ResponseEntity.badRequest().body(body);
    }
 
} // end of class
