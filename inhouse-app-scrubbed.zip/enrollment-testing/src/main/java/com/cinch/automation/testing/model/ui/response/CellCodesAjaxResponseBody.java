package com.cinch.automation.testing.model.ui.response;

import com.cinch.automation.testing.model.TelemarketingTableEntry;

public class CellCodesAjaxResponseBody extends ResponseBody {

    TelemarketingTableEntry[] cellCodes;
    
	public TelemarketingTableEntry[] getCellCodes() {
		return cellCodes;
	}
	public void setCellCodes(TelemarketingTableEntry[] cellCodes) {
		this.cellCodes = cellCodes;
	}
}