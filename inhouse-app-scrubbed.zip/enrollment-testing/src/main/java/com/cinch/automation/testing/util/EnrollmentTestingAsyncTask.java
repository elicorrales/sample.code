package com.cinch.automation.testing.util;

import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cinch.automation.testing.api.services.BackendApiServices;
import com.cinch.automation.testing.model.BankAccount;
import com.cinch.automation.testing.model.DeductibleBuydown;
import com.cinch.automation.testing.model.Enrollment;
import com.cinch.automation.testing.model.EnrollmentPricing;
import com.cinch.automation.testing.model.EnrollmentResult;
import com.cinch.automation.testing.model.search.criteria.TestParams;

/******************************************************************************************************************************************
 * This class handles all of the invocations of the BackendApiServices.
 * Its purpose is to attempt to enroll.
 * It gathers and uses all of the user's input parameters, as well as other data.
 * 
 * It is intended to be used within the context of a thread-pool, and returns Future results
 * 
 * 
 * @author ecorrales
 *
 */
public class EnrollmentTestingAsyncTask implements Callable<EnrollmentResult> {

	private static final Logger logger = LoggerFactory.getLogger(EnrollmentTestingAsyncTask.class);

	private BackendApiServices services;

	private TestParams params;
	
	/****************************************************************************************************************
	 * This constructor takes the user's input parameters used to conduct the enrollment testing, as well as
	 * a reference to the collection of backend API service REST calls available to use for this purpose.
	 * 
	 * @param services
	 * @param params
	 */
	public EnrollmentTestingAsyncTask(BackendApiServices services, TestParams params) {
		this.services = services; this.params = params;
	}


	/*****************************************************************************************************************
	 * 
	 * The main method in this class.  Its purpose is to attempt to create an enrollment for a product, based on all
	 * of the user's input paramters and also the pre-populated Enrollment obtained from the backend.
	 * 
	 * @return the result of the enrollment attempt. It could be the actual enrollment, or it could be the enrollment errors encountered, or it could be any exception-related errors
	 ****************************************************************************************************************/
	@Override
	public EnrollmentResult call() throws Exception {

		logger.debug(this.getClass().getSimpleName() + ".call()");
		
		
   		Enrollment enrollmentRequest = null;
		EnrollmentResult enrollmentResult = null;
   						
		try {

			enrollmentRequest = services.findEnrollmentByProductClientIdCellZip(params);

			if (null != enrollmentRequest) {

				String state = services.findStateByZip(params.getZip());

				enrollmentRequest.getPrimaryCustomer().getAddress().setState(state);
				enrollmentRequest.getPrimaryCustomer().getAddress().setZip(params.getZip());
				enrollmentRequest.getBillingAddress().setState(state);
				enrollmentRequest.getBillingAddress().setZip(params.getZip());
   							
				if ("ACH_AUTO".equals(params.getPymtType())) {

					if (null==enrollmentRequest.getPaymentInformation().getBankAccountInformation()) {
						enrollmentRequest.getPaymentInformation().setBankAccountInformation(new BankAccount());
					}
				}
				enrollmentRequest.getPaymentInformation().setBillingMechanismCode(params.getPymtType());
				enrollmentRequest.getPaymentInformation().setPaymentFrequency(params.getPymtFreq());
				enrollmentRequest.getClientInfo().setIndustryCode(params.getIndCode());
				if (null!=params.getNewDeduct() && null!=params.getBuydwnCost()) {
					if (null==enrollmentRequest.getDeductibleBuydown()) {
						enrollmentRequest.setDeductibleBuydown(new DeductibleBuydown());
					}
					enrollmentRequest.getDeductibleBuydown().setNewDeductible(params.getNewDeduct());
					enrollmentRequest.getDeductibleBuydown().setBuydownCost(params.getBuydwnCost());
				}
 
				//NOTE : need to work more on this - getting backend error (serialization issue)
				// we're not going to be doing any combo options or options as input parameters for now.
				if (null!=params.getComboOptions() && 0<params.getComboOptions().size()) {
					enrollmentRequest.setProductComboOptions(params.getComboOptions());
				}
				if (null!=params.getOptions() && 0<params.getOptions().size()) {
					enrollmentRequest.setProductOptions(params.getOptions());
				}
				if (null!=params.getAdditionals() && 0<params.getAdditionals().size()) {
					enrollmentRequest.setProductAdditionals(params.getAdditionals());
				}

  				EnrollmentPricing pricing = services.getEnrollmentCalculatedPricing(enrollmentRequest);
  				if (null != pricing) {
  					enrollmentRequest.setTax(pricing.getEnrollmentTax());
  					enrollmentRequest.setTotalPremiumPrice(pricing.getEnrollmentTotalPremiumPrice());
  				}
  								
  								
   				enrollmentResult = services.attemptAnEnrollment(enrollmentRequest);
   				enrollmentResult.setEnrollment(enrollmentRequest);
			}
							
		} catch (Exception e2) {

			// this portion is just to log on server
			String loggerErrorMessage = "Error attempting Enrollment: " + (null!=params?params.toString():"No Params");
			logger.error(loggerErrorMessage,e2);

			// this portion is to return to front-end UI
			// trying to capture as many errors as possible to show on UI - makes it easier for users to inform
			// IT developer whenever this app has an issue, without having to look at log
			String errorMessage = e2.getMessage();
			if (null==errorMessage) {
				Throwable cause = e2.getCause();
				if (null!=cause) {
					String causeMsg = cause.getMessage();
					if (null!=causeMsg) {
						errorMessage = causeMsg;
					} else {
						errorMessage = cause.getClass().getName();
					}
				} else {
					errorMessage = e2.getClass().getName();
				}
			}
			//setting a result and the incoming enrollment param to have something to show in the UI details
			if (null==enrollmentResult) {
				// the front-end UI is expecting an EnrollmentResult no matter what
				enrollmentResult = new EnrollmentResult(); enrollmentResult.setEnrollment(enrollmentRequest);
			}
			enrollmentResult.setErrorMessage(errorMessage);
		}

		//setting a result and the incoming enrollment param to have something to show in the UI details
		if (null==enrollmentResult) {
			// this one probably is not needed
			enrollmentResult = new EnrollmentResult(); enrollmentResult.setEnrollment(enrollmentRequest);enrollmentResult.setErrorMessage("Null EnrollmentResult");
		}
						
   		return enrollmentResult;
	}
}
