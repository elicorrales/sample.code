package com.cinch.automation.testing.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BaseCoverage {

	String categoryId;
	String description;
	String quantityCoveredByDefault;
	String maxAdditionalQuantity;

	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getQuantityCoveredByDefault() {
		return quantityCoveredByDefault;
	}
	public void setQuantityCoveredByDefault(String quantityCoveredByDefault) {
		this.quantityCoveredByDefault = quantityCoveredByDefault;
	}
	public String getMaxAdditionalQuantity() {
		return maxAdditionalQuantity;
	}
	public void setMaxAdditionalQuantity(String maxAdditionalQuantity) {
		this.maxAdditionalQuantity = maxAdditionalQuantity;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BaseCoverage [categoryId=");
		builder.append(categoryId);
		builder.append(", description=");
		builder.append(description);
		builder.append(", quantityCoveredByDefault=");
		builder.append(quantityCoveredByDefault);
		builder.append(", maxAdditionalQuantity=");
		builder.append(maxAdditionalQuantity);
		builder.append("]");
		return builder.toString();
	}
}
