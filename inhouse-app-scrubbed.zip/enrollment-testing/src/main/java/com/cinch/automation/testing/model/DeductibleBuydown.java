package com.cinch.automation.testing.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DeductibleBuydown implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4763016972196810541L;

	String newDeductible;
	String buydownCost;

	public String getNewDeductible() {
		return newDeductible;
	}

	public void setNewDeductible(String newDeductible) {
		this.newDeductible = newDeductible;
	}

	public String getBuydownCost() {
		return buydownCost;
	}

	public void setBuydownCost(String buydownCost) {
		this.buydownCost = buydownCost;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DeductibleBuydown [newDeductible=");
		builder.append(newDeductible);
		builder.append(", buydownCost=");
		builder.append(buydownCost);
		builder.append("]");
		return builder.toString();
	}

}