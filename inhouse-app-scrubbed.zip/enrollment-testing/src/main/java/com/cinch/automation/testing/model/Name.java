package com.cinch.automation.testing.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Name implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4230571587143253963L;

	String prefix;
	String companyName;
	String firstName;
	String lastName;
	String middleInitial;
	String suffix;

	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleInitial() {
		return middleInitial;
	}
	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}
	public String getSuffix() {
		return suffix;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Name [prefix=");
		builder.append(prefix);
		builder.append(", companyName=");
		builder.append(companyName);
		builder.append(", firstName=");
		builder.append(firstName);
		builder.append(", lastName=");
		builder.append(lastName);
		builder.append(", middleInitial=");
		builder.append(middleInitial);
		builder.append(", suffix=");
		builder.append(suffix);
		builder.append("]");
		return builder.toString();
	}
}