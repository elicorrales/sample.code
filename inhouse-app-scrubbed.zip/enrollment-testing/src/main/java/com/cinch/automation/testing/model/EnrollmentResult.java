package com.cinch.automation.testing.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EnrollmentResult implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1562941523017719080L;


	private int    idx;
	private String successFlag;
	private String errorMessage;
	private String contractNumber;
	private Enrollment enrollment;
	private String rawEnrollmentRequest;
	
	public String getRawEnrollmentRequest() {
		return rawEnrollmentRequest;
	}
	public void setRawEnrollmentRequest(String rawEnrollmentRequest) {
		this.rawEnrollmentRequest = rawEnrollmentRequest;
	}
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public Enrollment getEnrollment() {
		return enrollment;
	}
	public void setEnrollment(Enrollment enrollment) {
		this.enrollment = enrollment;
	}
	public String getSuccessFlag() {
		return successFlag;
	}
	public void setSuccessFlag(String successFlag) {
		this.successFlag = successFlag;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getContractNumber() {
		return contractNumber;
	}
	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EnrollmentResult [idx=");
		builder.append(idx);
		builder.append(", successFlag=");
		builder.append(successFlag);
		builder.append(", errorMessage=");
		builder.append(errorMessage);
		builder.append(", contractNumber=");
		builder.append(contractNumber);
		builder.append(", enrollment=");
		builder.append(enrollment);
		builder.append(", rawEnrollmentRequest=");
		builder.append(rawEnrollmentRequest);
		builder.append("]");
		return builder.toString();
	}

}