package com.cinch.automation.testing.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AvailablePhone {

	String cellPhone;
	String homePhone;
	String phoneNumber;
	String areaCode;
	String extention;
	public String getCellPhone() {
		return cellPhone;
	}
	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}
	public String getHomePhone() {
		return homePhone;
	}
	public void setHomePhone(String homePhone) {
		this.homePhone = homePhone;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	public String getExtention() {
		return extention;
	}
	public void setExtention(String extention) {
		this.extention = extention;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AvailablePhone [cellPhone=");
		builder.append(cellPhone);
		builder.append(", homePhone=");
		builder.append(homePhone);
		builder.append(", phoneNumber=");
		builder.append(phoneNumber);
		builder.append(", areaCode=");
		builder.append(areaCode);
		builder.append(", extention=");
		builder.append(extention);
		builder.append("]");
		return builder.toString();
	}


}