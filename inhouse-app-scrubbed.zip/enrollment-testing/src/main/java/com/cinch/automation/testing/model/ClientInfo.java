package com.cinch.automation.testing.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientInfo implements Serializable{

	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4908961695686583L;
	
	
	String clientCode;
	String cellCode;
	String ccmId;
	String companyCode;
	String affiliateId;
	String supplementaryCcmId;
	String industryCode;
	String externalCcmId;
	String clientXrefId;
	String agentName;
	public String getClientCode() {
		return clientCode;
	}
	public void setClientCode(String clientCode) {
		this.clientCode = clientCode;
	}
	public String getCellCode() {
		return cellCode;
	}
	public void setCellCode(String cellCode) {
		this.cellCode = cellCode;
	}
	public String getCcmId() {
		return ccmId;
	}
	public void setCcmId(String ccmId) {
		this.ccmId = ccmId;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getAffiliateId() {
		return affiliateId;
	}
	public void setAffiliateId(String affiliateId) {
		this.affiliateId = affiliateId;
	}
	public String getSupplementaryCcmId() {
		return supplementaryCcmId;
	}
	public void setSupplementaryCcmId(String supplementaryCcmId) {
		this.supplementaryCcmId = supplementaryCcmId;
	}
	public String getIndustryCode() {
		return industryCode;
	}
	public void setIndustryCode(String industryCode) {
		this.industryCode = industryCode;
	}
	public String getExternalCcmId() {
		return externalCcmId;
	}
	public void setExternalCcmId(String externalCcmId) {
		this.externalCcmId = externalCcmId;
	}
	public String getClientXrefId() {
		return clientXrefId;
	}
	public void setClientXrefId(String clientXrefId) {
		this.clientXrefId = clientXrefId;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ClientInfo [clientCode=");
		builder.append(clientCode);
		builder.append(", cellCode=");
		builder.append(cellCode);
		builder.append(", ccmId=");
		builder.append(ccmId);
		builder.append(", companyCode=");
		builder.append(companyCode);
		builder.append(", affiliateId=");
		builder.append(affiliateId);
		builder.append(", supplementaryCcmId=");
		builder.append(supplementaryCcmId);
		builder.append(", industryCode=");
		builder.append(industryCode);
		builder.append(", externalCcmId=");
		builder.append(externalCcmId);
		builder.append(", clientXrefId=");
		builder.append(clientXrefId);
		builder.append(", agentName=");
		builder.append(agentName);
		builder.append("]");
		return builder.toString();
	}


}