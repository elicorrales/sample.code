package com.cinch.automation.testing.util;

public interface TestingConstants {
  
  public static class OauthTokenKeys { 
    public static final String GRANT_TYPE_CLIENT_CREDENTIALS    = "client_credentials";
    public static final String X_API_KEY_TOKEN                  = "X-Api-Key";
  } 

}
