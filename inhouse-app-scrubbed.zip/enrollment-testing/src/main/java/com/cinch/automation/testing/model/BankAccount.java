/*
 * It was easier to just create this class , set the @JsonProperty Access.READ_WRITE, than to  go through all of the hassle of using the API jar classes
 */
package com.cinch.automation.testing.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BankAccount implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7718393600856755935L;

	private String bankAccountType = "CHECKING";
	@JsonProperty(access = Access.READ_WRITE)
	private String bankAccountNumber = "2340923440923548";
	private String bankRoutingNumber = "123456789";
	public String getBankAccountType() {
		return bankAccountType;
	}
	public void setBankAccountType(String bankAccountType) {
		this.bankAccountType = bankAccountType;
	}
	public String getBankAccountNumber() {
		return bankAccountNumber;
	}
	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}
	public String getBankRoutingNumber() {
		return bankRoutingNumber;
	}
	public void setBankRoutingNumber(String bankRoutingNumber) {
		this.bankRoutingNumber = bankRoutingNumber;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BankAccount [bankAccountType=");
		builder.append(bankAccountType);
		builder.append(", bankAccountNumber=");
		builder.append(bankAccountNumber);
		builder.append(", bankRoutingNumber=");
		builder.append(bankRoutingNumber);
		builder.append("]");
		return builder.toString();
	}

	
}
