package com.cinch.automation.testing.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentInformation implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -9000485793614246844L;


	
	String paymentFrequency;
	String billingMechanismCode;
	BankAccount bankAccountInformation;

	CreditCardInformation creditCardInformation;

	public String getPaymentFrequency() {
		return paymentFrequency;
	}

	public void setPaymentFrequency(String paymentFrequency) {
		this.paymentFrequency = paymentFrequency;
	}

	public String getBillingMechanismCode() {
		return billingMechanismCode;
	}

	public void setBillingMechanismCode(String billingMechanismCode) {
		this.billingMechanismCode = billingMechanismCode;
	}

	public BankAccount getBankAccountInformation() {
		return bankAccountInformation;
	}

	public void setBankAccountInformation(BankAccount bankAccountInformation) {
		this.bankAccountInformation = bankAccountInformation;
	}

	public CreditCardInformation getCreditCardInformation() {
		return creditCardInformation;
	}

	public void setCreditCardInformation(CreditCardInformation creditCardInformation) {
		this.creditCardInformation = creditCardInformation;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PaymentInformation [paymentFrequency=");
		builder.append(paymentFrequency);
		builder.append(", billingMechanismCode=");
		builder.append(billingMechanismCode);
		builder.append(", bankAccountInformation=");
		builder.append(bankAccountInformation);
		builder.append(", creditCardInformation=");
		builder.append(creditCardInformation);
		builder.append("]");
		return builder.toString();
	}

}