package com.cinch.automation.testing.model;

import java.io.Serializable;
import java.util.List;

import com.cchs.microservice.dto.product.ProductAdditional;
import com.cchs.microservice.dto.product.ProductComboOption;
import com.cchs.microservice.dto.product.ProductOption;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Enrollment implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1624056703088935479L;

	private String productId;
	private String basePremiumPrice;
	private String baseDeductible;
	private String tax;
	private String totalPremiumPrice;
	private String enrollmentDate;
	private String effectiveDate;
	private String expirationDate;
	
	private String purchaseTypeCode;
	private String unitTypeCode;
    private String productTypeCode;
    private boolean enrollmentConfirmation;

    private DeductibleBuydown deductibleBuydown;
	private PrimaryCustomer primaryCustomer;
    private Address billingAddress;
	private ClientInfo clientInfo;
	private PaymentInformation paymentInformation;

	private List<ProductComboOption> productComboOptions;
	private List<ProductOption> productOptions;
	private List<ProductAdditional> productAdditionals;


	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getBasePremiumPrice() {
		return basePremiumPrice;
	}
	public void setBasePremiumPrice(String basePremiumPrice) {
		this.basePremiumPrice = basePremiumPrice;
	}
	public String getBaseDeductible() {
		return baseDeductible;
	}
	public void setBaseDeductible(String baseDeductible) {
		this.baseDeductible = baseDeductible;
	}
	public String getTax() {
		return tax;
	}
	public void setTax(String tax) {
		this.tax = tax;
	}
	public String getTotalPremiumPrice() {
		return totalPremiumPrice;
	}
	public void setTotalPremiumPrice(String totalPremiumPrice) {
		this.totalPremiumPrice = totalPremiumPrice;
	}
	public String getEnrollmentDate() {
		return enrollmentDate;
	}
	public void setEnrollmentDate(String enrollmentDate) {
		this.enrollmentDate = enrollmentDate;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	public String getPurchaseTypeCode() {
		return purchaseTypeCode;
	}
	public void setPurchaseTypeCode(String purchaseTypeCode) {
		this.purchaseTypeCode = purchaseTypeCode;
	}
	public String getUnitTypeCode() {
		return unitTypeCode;
	}
	public void setUnitTypeCode(String unitTypeCode) {
		this.unitTypeCode = unitTypeCode;
	}
	public String getProductTypeCode() {
		return productTypeCode;
	}
	public void setProductTypeCode(String productTypeCode) {
		this.productTypeCode = productTypeCode;
	}
	public boolean isEnrollmentConfirmation() {
		return enrollmentConfirmation;
	}
	public void setEnrollmentConfirmation(boolean enrollmentConfirmation) {
		this.enrollmentConfirmation = enrollmentConfirmation;
	}
	public DeductibleBuydown getDeductibleBuydown() {
		return deductibleBuydown;
	}
	public void setDeductibleBuydown(DeductibleBuydown deductibleBuydown) {
		this.deductibleBuydown = deductibleBuydown;
	}
	public PrimaryCustomer getPrimaryCustomer() {
		return primaryCustomer;
	}
	public void setPrimaryCustomer(PrimaryCustomer primaryCustomer) {
		this.primaryCustomer = primaryCustomer;
	}
	public Address getBillingAddress() {
		return billingAddress;
	}
	public void setBillingAddress(Address billingAddress) {
		this.billingAddress = billingAddress;
	}
	public ClientInfo getClientInfo() {
		return clientInfo;
	}
	public void setClientInfo(ClientInfo clientInfo) {
		this.clientInfo = clientInfo;
	}
	public PaymentInformation getPaymentInformation() {
		return paymentInformation;
	}
	public void setPaymentInformation(PaymentInformation paymentInformation) {
		this.paymentInformation = paymentInformation;
	}
	public List<ProductComboOption> getProductComboOptions() {
		return productComboOptions;
	}
	public void setProductComboOptions(List<ProductComboOption> productComboOptions) {
		this.productComboOptions = productComboOptions;
	}
	public List<ProductOption> getProductOptions() {
		return productOptions;
	}
	public void setProductOptions(List<ProductOption> productOptions) {
		this.productOptions = productOptions;
	}
	public List<ProductAdditional> getProductAdditionals() {
		return productAdditionals;
	}
	public void setProductAdditionals(List<ProductAdditional> productAdditionals) {
		this.productAdditionals = productAdditionals;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Enrollment [productId=");
		builder.append(productId);
		builder.append(", basePremiumPrice=");
		builder.append(basePremiumPrice);
		builder.append(", baseDeductible=");
		builder.append(baseDeductible);
		builder.append(", tax=");
		builder.append(tax);
		builder.append(", totalPremiumPrice=");
		builder.append(totalPremiumPrice);
		builder.append(", enrollmentDate=");
		builder.append(enrollmentDate);
		builder.append(", effectiveDate=");
		builder.append(effectiveDate);
		builder.append(", expirationDate=");
		builder.append(expirationDate);
		builder.append(", purchaseTypeCode=");
		builder.append(purchaseTypeCode);
		builder.append(", unitTypeCode=");
		builder.append(unitTypeCode);
		builder.append(", productTypeCode=");
		builder.append(productTypeCode);
		builder.append(", enrollmentConfirmation=");
		builder.append(enrollmentConfirmation);
		builder.append(", deductibleBuydown=");
		builder.append(deductibleBuydown);
		builder.append(", primaryCustomer=");
		builder.append(primaryCustomer);
		builder.append(", billingAddress=");
		builder.append(billingAddress);
		builder.append(", clientInfo=");
		builder.append(clientInfo);
		builder.append(", paymentInformation=");
		builder.append(paymentInformation);
		builder.append(", productComboOptions=");
		builder.append(productComboOptions);
		builder.append(", productOptions=");
		builder.append(productOptions);
		builder.append(", productAdditionals=");
		builder.append(productAdditionals);
		builder.append("]");
		return builder.toString();
	}
	
	

}