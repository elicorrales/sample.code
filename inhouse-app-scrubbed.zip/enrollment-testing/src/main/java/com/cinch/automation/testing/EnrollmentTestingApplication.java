package com.cinch.automation.testing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(value = "com.cinch.automation.testing")
public class EnrollmentTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnrollmentTestingApplication.class, args);
	}
}
