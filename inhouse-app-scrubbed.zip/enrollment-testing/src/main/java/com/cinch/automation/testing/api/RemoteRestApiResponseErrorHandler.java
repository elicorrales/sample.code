package com.cinch.automation.testing.api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

import com.cinch.automation.testing.model.Enrollment;
import com.fasterxml.jackson.databind.ObjectMapper;


/******************************************************************************************************************************************************
 *The purpose of this class is to convert the text of any exceptions thrown by the REST calls to the backend services, into something useful and readable
 *by both the system logging, an by the front-end UI.
 *
 * Specifically, it converts all of the information into a JSON string.
 * 
 * Another key point about this class is that it ties the user input parameters, the product information, and the enrollment information, with the
 * exceptions / errors.   This is useful when looking at errors in the log (such as when an notification email is received).  All of the known data related
 * to that error is found / viewable with the error.
 * 
 * @author ecorrales
 *
 *****************************************************************************************************************************************************/
public class RemoteRestApiResponseErrorHandler implements ResponseErrorHandler {

	private static final Logger logger = LoggerFactory.getLogger(RemoteRestApiResponseErrorHandler.class);

	private String url;
	private String requestPurpose;
	private Enrollment enrollment;
	
	/*********************************************************************************************************
	 *This constructor is used by most of the RestTemplate backend API service calls, with the exception of 
	 *the one that does the enrollment. The 'requestPurpose' is not really that important - just informative.
	 *
	 * @param url the actual,final url string passed to the RestTemplate to invoke the backend API service
	 * @param requestPurpose
	 ********************************************************************************************************/
	public RemoteRestApiResponseErrorHandler(String url, String requestPurpose) {
		
		this.url = url;
		this.requestPurpose = requestPurpose;
	}

	/*********************************************************************************************************
	 *This constructor is used for when making the actual enrollment attempt.
	 *By passing in the enrollment request used to make the call, this handler can tie the input data
	 *to any error results.
	 *
	 * @param url the actual,final url string passed to the RestTemplate to invoke the backend API service
	 * @param enrollment
	 ********************************************************************************************************/
	public RemoteRestApiResponseErrorHandler(String url, Enrollment enrollment) {

		this.url = url;
		this.enrollment = enrollment;
		
	}

	/*********************************************************************************************************
	 * 
	 * Any HTTP code that is not a 2XX is considered an error.
	 * 
	 * @return true if error, false if not error
	 ********************************************************************************************************/
	@Override
	public boolean hasError(ClientHttpResponse response) throws IOException {

		return response.getStatusCode().is2xxSuccessful ()?false:true;

	}

	/*********************************************************************************************************
	 * This is the key or main method or purpose of this class.  It is the one that does all the work of
	 * converting error / exception messages into a single raw JSON blob, and also ties in the input url,
	 * and the input enrollment. It is invoked by the framework to handle any RestTemplate errors.
	 ********************************************************************************************************/
	@Override
	public void handleError(ClientHttpResponse response) throws IOException {
		
		_handleError(response,null);
	}


	/*********************************************************************************************************
	 * Spring RestTemplate invocations can return without throwing an error and invoking this handler, however,
	 * the data itself may be faulty.  This method is a convenience to be able to throw our own error back up,
	 * and use the same formatting as in this error handler's main method.
	 ********************************************************************************************************/
	public void throwBadBackendDataError(String reason) throws IOException {
		
		_handleError(null,reason);
	}

	private void _handleError(ClientHttpResponse response, String reason) throws IOException {
		
		StringBuilder builder = new StringBuilder();

		builder.append("{");
	
		if (null!=reason) {
	
			builder.append("\"reason\":");
			builder.append("\""+reason+"\"");
		}

		if (null!=url) {
			if (null!=reason) {
				builder.append(",");
			}
			builder.append("\"url\":\"");
			builder.append(url);
			builder.append("\"");
		}

		if (null!=response) { // this method can have been manually invoked (not by frame work), thus there won't be a 'response' object

			StringBuilder bodyBuilder = new StringBuilder();
			String line = null;
			BufferedReader in = new BufferedReader(new InputStreamReader(response.getBody()));
			while ((line=in.readLine())!=null) {
				bodyBuilder.append(line);
			}

			String bodyString = bodyBuilder.toString();
			if (!bodyString.isEmpty()) {
				builder.append(",\"backendApiResultBody\":");
				builder.append(bodyString);
			}
		}

		if (null!=enrollment) {
			builder.append(",\"enrollment\":");
			ObjectMapper objectMapper = new ObjectMapper();
			StringWriter strEnr = new StringWriter();
			objectMapper.writeValue(strEnr, enrollment);
			builder.append(strEnr);
		}

		if (null!=requestPurpose) {
			builder.append(", \"reqPurp\":");
			builder.append(requestPurpose);
		}

		builder.append("}");

		throw new RuntimeException(builder.toString());
	}


}
