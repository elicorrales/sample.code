package com.cinch.automation.testing.model.ui.response;

public class ContractInfoAjaxResponseBody extends ResponseBody {

}