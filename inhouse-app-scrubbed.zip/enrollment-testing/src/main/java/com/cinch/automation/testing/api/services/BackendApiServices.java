package com.cinch.automation.testing.api.services;




import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cchs.microservice.dto.product.ProductPlan;
import com.cinch.automation.testing.api.RemoteRestApiResponseErrorHandler;
import com.cinch.automation.testing.model.CityInformation;
import com.cinch.automation.testing.model.Enrollment;
import com.cinch.automation.testing.model.EnrollmentPricing;
import com.cinch.automation.testing.model.EnrollmentResult;
import com.cinch.automation.testing.model.TelemarketingTableEntry;
import com.cinch.automation.testing.model.search.criteria.TestParams;
import com.cinch.automation.testing.util.Loggable;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
/**************************************************************************************************************************************
 * 
 * This class wraps, encloses, abstracts away all of of the REST services calls to the backend API services, that are used for
 * this entire application, from creating the needed user-form data , to gathering information, to attempting enrollments.
 * <p> 
 * NOTE: each method assigns it own RemoteRestApiResponseErrorHandler to the RestTemplate because the handler's main purpose is to
 * convert exceptions into usable JSON data for the front-end UI, as well as for system logging, and that varies a bit with each
 * service call.
 * 
 * @author ecorrales
 *
 *************************************************************************************************************************************/
@Service
public class BackendApiServices {

	private String cellcodesUrl;
	private String zipcodesUrl;
	private String productsUrl;
	private String productsUrlExtraParams;
	private String enrollmentUrl;
	private String enrollmentUrlExtraParams;
	private String calcPricingUrl;
	private String contractInfoUrl;
	
	
	private RestTemplate restTemplate;
	
	@Autowired
	public void setCellcodesUrl(@Value("${cellcodes.url}") String url) {
		this.cellcodesUrl = url;
	}
	
	@Autowired
	public void setZipcodesUrl(@Value("${zipcodes.url}") String url) {
		this.zipcodesUrl = url;
	}
	
	@Autowired
	public void setProductsUrl(@Value("${products.url}") String url) {
		this.productsUrl = url;
	}

	@Autowired
	public void setProductsUrlExtraParams(@Value("${products.url.extra.params}") String extra) {
		this.productsUrlExtraParams = extra;
	}
	

	@Autowired
	public void setEnrollmentUrl(@Value("${enrollment.url}") String url) {
		this.enrollmentUrl = url;
	}

	@Autowired
	public void setEnrollmentUrlExtraParams(@Value("${enrollment.url.extra.params}") String extra) {
		this.enrollmentUrlExtraParams = extra;
	}
	

	@Autowired
	public void setCalcPricingUrl(@Value("${calc.pricing.url}") String url) {
		this.calcPricingUrl = url;
	}
	

	@Autowired
	public void setContractInfoUrl(@Value("${contract.info.url}") String url) {
		this.contractInfoUrl = url;
	}
	

	
	/*******************************************************************************************************************
	 * 
	 * Creates the instance of the RestTemplate to be used for all backend api REST service calls.
	 * 
	 ******************************************************************************************************************/
	public BackendApiServices() {
		
		restTemplate = new RestTemplate();
	}
	

	/********************************************************************************************************************
	 * 
	 * This method gets the list of known cell codes to be used in the UI as an input-selection.
	 * 
	 * @return an array of cell codes
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 *******************************************************************************************************************/
	@Loggable
    public TelemarketingTableEntry[] findCellCodes() throws JsonParseException, JsonMappingException, IOException {


    	TelemarketingTableEntry[] entries = null;
    	
		RemoteRestApiResponseErrorHandler errorHandler = new RemoteRestApiResponseErrorHandler(cellcodesUrl,"Finding Cell Codes");
		restTemplate.setErrorHandler(errorHandler);
   		ResponseEntity<String> response = restTemplate.getForEntity(cellcodesUrl, String.class);

   		String entriesJson = response.getBody();

   		if (null==entriesJson || entriesJson.isEmpty()) {
   			errorHandler.throwBadBackendDataError("No Cell Codes");
   		}
 
   		ObjectMapper mapper = new ObjectMapper();
 
   		JsonNode root = mapper.readTree(entriesJson);
       	
   		int size = root.size();
       	
   		if (0==size) {
   			errorHandler.throwBadBackendDataError("No Cell Codes");
   		}
 
   		List<TelemarketingTableEntry> entriesList = new ArrayList<TelemarketingTableEntry>();


   		ObjectMapper mapper2 = new ObjectMapper();
   		Iterator<JsonNode> iterator = root.elements();
   		while (iterator.hasNext()) {
      		
   			JsonNode node = iterator.next();
      		
   			TelemarketingTableEntry entry = mapper2.readValue(node.toString(), TelemarketingTableEntry.class);

   			entriesList.add(entry);
      		
   		}

   		entries = entriesList.stream().toArray(TelemarketingTableEntry[]::new);

    	return entries;
    }


	/********************************************************************************************************************
	 * This method attempt to get the state, given the zip code.
	 * 
	 * @param zip
	 * @return the state, if found
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 *******************************************************************************************************************/
	@Loggable
    public String findStateByZip(String zip) throws JsonParseException, JsonMappingException, IOException {


    	String url = zipcodesUrl + '/' + zip;
       	
    	RemoteRestApiResponseErrorHandler errorHandler = new RemoteRestApiResponseErrorHandler(url, "Finding State for " + zip);
		restTemplate.setErrorHandler(errorHandler);
   		CityInformation[] citiesInfo = restTemplate.getForObject(url, CityInformation[].class);


   		if (null!=citiesInfo && 0!=citiesInfo.length && null!= citiesInfo[0].getState()) {
       		
   			return citiesInfo[0].getState();

   		} else {

   			errorHandler.throwBadBackendDataError("No City Found");
   			return null; // this will never execute here but just to shutup Eclipse

   		}
    }


	/********************************************************************************************************************
	 * This method attempts to find all of the products for the combination of client id, cell code, and zip code.
	 * It returns an array of products found.
	 * 
	 * @param clientId
	 * @param cell
	 * @param zip
	 * @return an array of products, if found
	 *******************************************************************************************************************/
	@Loggable
    public ProductPlan[] findProductsByClientIdCellZip(String clientId,String cell, String zip) {

        ProductPlan[] productPlans = null;

        String url = productsUrl + '/' + clientId + '/' + cell + '/' + zip + productsUrlExtraParams;
        
		restTemplate.setErrorHandler(new RemoteRestApiResponseErrorHandler(url, "Finding Products"));
       	ResponseEntity<ProductPlan[]> response = restTemplate.getForEntity(url, ProductPlan[].class);

        productPlans = response.getBody();
        	
       	return productPlans;
    }



	/********************************************************************************************************************
	 * This method attempts to retrieve an 'enrollment template'.  A pre-populated enrollment object, based on the given
	 * input parameters.  This template reduces the need to fill in many fields in order to attempt an enrollment.
	 * 
	 * @param params the user-supplied input test parameters (example: product id, client id, cellcode, zip, etc)
	 * @return the enrollment 'template' to be used in a subsequent enrollment attempt (the test)
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 *******************************************************************************************************************/
	@Loggable
    public Enrollment findEnrollmentByProductClientIdCellZip(TestParams params) throws JsonParseException, JsonMappingException, IOException {

       	Enrollment enrollment = null;

       	if (null != params && null != params.getProdGenSeq() && !params.getProdGenSeq().isEmpty()) {

       		String url = enrollmentUrl + '/' + params.getProdGenSeq() + '/' + params.getClientId() + '/' + params.getCellCode() + '/' + params.getZip() + enrollmentUrlExtraParams;

       		restTemplate.setErrorHandler(new RemoteRestApiResponseErrorHandler(url, "Finding Enrollment Template"));
       		ResponseEntity<Enrollment> response = restTemplate.getForEntity(url, Enrollment.class);

       		enrollment = response.getBody();
        	
       	}

		return enrollment;

    }
 
	/********************************************************************************************************************
	 * This method is called just prior to an enrollment attempt (the test). By this time, the enrollment object should 
	 * have all of the user input parameters added.  Without this call, the enrollment attempt could fail because the
	 * pricing data will be incorrect.  So this is a convenience method to calculate and set the correct pricing
	 * information in the enrollment request.
	 * 
	 * @param enrollment
	 * @return enrollment pricing data
	 *******************************************************************************************************************/
	@Loggable
    public EnrollmentPricing getEnrollmentCalculatedPricing(Enrollment enrollment) {

		EnrollmentPricing pricing = null;
		
		HttpEntity<Enrollment> requestBody = new HttpEntity<>(enrollment);
 
		restTemplate.setErrorHandler(new RemoteRestApiResponseErrorHandler(calcPricingUrl, enrollment));
		ResponseEntity<EnrollmentPricing> response = restTemplate .postForEntity(calcPricingUrl, requestBody, EnrollmentPricing.class);

		pricing = response.getBody();
    	
		return pricing;
    }


	/********************************************************************************************************************
	 * This is the main or key method for the entire application. It is the one that performs the enrollment test.
	 * 
	 * By the time this method is called, the enrollment request object should be completely filled with all of the
	 * required information.
	 * 
	 * @param enrollment
	 * @return the result(s) of the enrollment attempt.  Either contract information, or the errors / reasons for failure
	 *******************************************************************************************************************/
	@Loggable
    public EnrollmentResult attemptAnEnrollment(Enrollment enrollmentRequest) {


		EnrollmentResult enResult = null;

		HttpEntity<Enrollment> request = new HttpEntity<>(enrollmentRequest);
 
		restTemplate.setErrorHandler(new RemoteRestApiResponseErrorHandler(enrollmentUrl, enrollmentRequest));
		ResponseEntity<EnrollmentResult> response = restTemplate .postForEntity(enrollmentUrl, request, EnrollmentResult.class);

		enResult = response.getBody();
		
		return enResult;
 
    }

 

	/********************************************************************************************************************
	 * This is an optional method that can be invoked by a user selection at the UI, for each row of data.
	 * That is, for each successful enrollment, one can submit the contract number, and obtain a raw JSON representation
	 * of the contract
	 * 
	 * @param contract
	 * @return the raw JSON representation of the contract
	 *******************************************************************************************************************/
	@Loggable
    public String findContractInfoByContractNumber(String contract) {

    	String json = null;

		String url = contractInfoUrl + '/' + contract;
		
		restTemplate.setErrorHandler(new RemoteRestApiResponseErrorHandler(url, "Contract Info " + contract));
		ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);

		json = response.getBody();
        	
        return json;
    }


}