package com.cinch.automation.testing.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Phone implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -770249277043755861L;

	String phoneNumber;
	String areaCode;
	String extention;

	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	public String getExtention() {
		return extention;
	}
	public void setExtention(String extention) {
		this.extention = extention;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Phone [phoneNumber=");
		builder.append(phoneNumber);
		builder.append(", areaCode=");
		builder.append(areaCode);
		builder.append(", extention=");
		builder.append(extention);
		builder.append("]");
		return builder.toString();
	}


}