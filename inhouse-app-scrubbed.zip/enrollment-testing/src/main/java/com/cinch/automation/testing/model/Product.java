package com.cinch.automation.testing.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Product {

	
    String name;
    String displayName;
    String annualPrice;
    String aggregateCap;
    String deductible;
    String prodGenSeq;
    String productTypeCode;
    String dormantDays;
    String clientId;
    String cellCode;
    String state;
    String taxRate;

    List<DeductibleBuydown> deductibleBuydowns;
    List<BaseCoverage> baseCoverage;
    List<ProductOption> productOptions;
    List<ProductComboOption> productComboOptions;
    
    List<String> categories;
    
    public List<String> getCategories() {
		return categories;
	}
	public void setCategories(List<String> categories) {
		this.categories = categories;
	}
	public List<ProductComboOption> getProductComboOptions() {
		return productComboOptions;
	}
	public void setProductComboOptions(List<ProductComboOption> productComboOptions) {
		this.productComboOptions = productComboOptions;
	}
	List<ProductAdditional> productAdditionals;
    List<BillingTerm> billingTerms;
    
	public List<ProductAdditional> getProductAdditionals() {
		return productAdditionals;
	}
	public void setProductAdditionals(List<ProductAdditional> productAdditionals) {
		this.productAdditionals = productAdditionals;
	}
	public List<ProductOption> getProductOptions() {
		return productOptions;
	}
	public void setProductOptions(List<ProductOption> productOptions) {
		this.productOptions = productOptions;
	}
	public List<BaseCoverage> getBaseCoverage() {
		return baseCoverage;
	}
	public void setBaseCoverage(List<BaseCoverage> baseCoverage) {
		this.baseCoverage = baseCoverage;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}


	public List<DeductibleBuydown> getDeductibleBuydowns() {
		return deductibleBuydowns;
	}
	public void setDeductibleBuydowns(List<DeductibleBuydown> deductibleBuydowns) {
		this.deductibleBuydowns = deductibleBuydowns;
	}

	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public List<BillingTerm> getBillingTerms() {
		return billingTerms;
	}
	public void setBillingTerms(List<BillingTerm> billingTerms) {
		this.billingTerms = billingTerms;
	}
	public String getCellCode() {
		return cellCode;
	}
	public void setCellCode(String cellCode) {
		this.cellCode = cellCode;
	}


	public String getAnnualPrice() {
		return annualPrice;
	}
	public void setAnnualPrice(String annualPrice) {
		this.annualPrice = annualPrice;
	}
	public String getAggregateCap() {
		return aggregateCap;
	}
	public void setAggregateCap(String aggregateCap) {
		this.aggregateCap = aggregateCap;
	}
	public String getDeductible() {
		return deductible;
	}
	public void setDeductible(String deductible) {
		this.deductible = deductible;
	}
	public String getProdGenSeq() {
		return prodGenSeq;
	}
	public void setProdGenSeq(String prodGenSeq) {
		this.prodGenSeq = prodGenSeq;
	}
	public String getProductTypeCode() {
		return productTypeCode;
	}
	public void setProductTypeCode(String productTypeCode) {
		this.productTypeCode = productTypeCode;
	}
	public String getDormantDays() {
		return dormantDays;
	}
	public void setDormantDays(String dormantDays) {
		this.dormantDays = dormantDays;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getTaxRate() {
		return taxRate;
	}
	public void setTaxRate(String taxRate) {
		this.taxRate = taxRate;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Product [name=");
		builder.append(name);
		builder.append(", displayName=");
		builder.append(displayName);
		builder.append(", annualPrice=");
		builder.append(annualPrice);
		builder.append(", aggregateCap=");
		builder.append(aggregateCap);
		builder.append(", deductible=");
		builder.append(deductible);
		builder.append(", prodGenSeq=");
		builder.append(prodGenSeq);
		builder.append(", productTypeCode=");
		builder.append(productTypeCode);
		builder.append(", dormantDays=");
		builder.append(dormantDays);
		builder.append(", clientId=");
		builder.append(clientId);
		builder.append(", cellCode=");
		builder.append(cellCode);
		builder.append(", state=");
		builder.append(state);
		builder.append(", taxRate=");
		builder.append(taxRate);
		builder.append(", deductibleBuydowns=");
		builder.append(deductibleBuydowns);
		builder.append(", baseCoverage=");
		builder.append(baseCoverage);
		builder.append(", productOptions=");
		builder.append(productOptions);
		builder.append(", productComboOptions=");
		builder.append(productComboOptions);
		builder.append(", categories=");
		builder.append(categories);
		builder.append(", productAdditionals=");
		builder.append(productAdditionals);
		builder.append(", billingTerms=");
		builder.append(billingTerms);
		builder.append("]");
		return builder.toString();
	}
	

}