package com.cinch.automation.testing.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CityInformation { //implements Serializable{
	
	//private static final long serialVersionUID = -6230591399753124068L;
	
	private String state;
	private String stateFullName;
	private String city;
	private String cityAliasName;
	private String zipCode;
	private String county;
	private String latitude;
	private String longitude;
	
	public CityInformation(){
		
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStateFullName() {
		return stateFullName;
	}

	public void setStateFullName(String stateFullName) {
		this.stateFullName = stateFullName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCityAliasName() {
		return cityAliasName;
	}

	public void setCityAliasName(String cityAliasName) {
		this.cityAliasName = cityAliasName;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CityInformation [state=");
		builder.append(state);
		builder.append(", stateFullName=");
		builder.append(stateFullName);
		builder.append(", city=");
		builder.append(city);
		builder.append(", cityAliasName=");
		builder.append(cityAliasName);
		builder.append(", zipCode=");
		builder.append(zipCode);
		builder.append(", county=");
		builder.append(county);
		builder.append(", latitude=");
		builder.append(latitude);
		builder.append(", longitude=");
		builder.append(longitude);
		builder.append("]");
		return builder.toString();
	}
	
}
