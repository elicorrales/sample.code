package com.cinch.automation.testing.model.ui.response;

import com.cinch.automation.testing.model.EnrollmentResult;

public class EnrollmentsAjaxResponseBody extends ResponseBody {

    int nextProductToTestIdx;
    int numProductsRemainingToTest;
    
	EnrollmentResult[] enrollmentResults;
	
	
    public int getNextProductToTestIdx() {
		return nextProductToTestIdx;
	}
	public void setNextProductToTestIdx(int nextProductToTestIdx) {
		this.nextProductToTestIdx = nextProductToTestIdx;
	}
	public int getNumProductsRemainingToTest() {
		return numProductsRemainingToTest;
	}
	public void setNumProductsRemainingToTest(int numProductsRemainingToTest) {
		this.numProductsRemainingToTest = numProductsRemainingToTest;
	}
    
	public EnrollmentResult[] getEnrollmentResults() {
		return enrollmentResults;
	}
	public void setEnrollmentResults(EnrollmentResult[] enrollmentResults) {
		this.enrollmentResults = enrollmentResults;
	}
}