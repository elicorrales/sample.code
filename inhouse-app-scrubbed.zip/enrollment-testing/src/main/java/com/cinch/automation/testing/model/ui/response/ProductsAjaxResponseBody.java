package com.cinch.automation.testing.model.ui.response;

import com.cchs.microservice.dto.product.ProductPlan;
import com.cinch.automation.testing.model.Product;

public class ProductsAjaxResponseBody extends ResponseBody {

    private Product[] products;
    private ProductPlan[] productPlans;
 
	public ProductPlan[] getProductPlans() {
		return productPlans;
	}
	public void setProductPlans(ProductPlan[] productPlans) {
		this.productPlans = productPlans;
	}
	public Product[] getProducts() {
		return products;
	}
	public void setProducts(Product[] products) {
		this.products = products;
	}
}