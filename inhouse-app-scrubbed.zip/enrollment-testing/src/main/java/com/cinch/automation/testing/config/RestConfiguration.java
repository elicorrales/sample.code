package com.cinch.automation.testing.config;

import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.security.oauth2.client.DefaultOAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.token.AccessTokenRequest;
import org.springframework.security.oauth2.client.token.DefaultAccessTokenRequest;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;
import org.springframework.web.util.DefaultUriTemplateHandler;

import com.cinch.automation.testing.oauth.EnrollmentRequestInterceptor;
import com.cinch.automation.testing.util.TestingConstants;

@Configuration
@EnableOAuth2Client
public class RestConfiguration implements TestingConstants  {
  @Value("${oauth.access.token.uri}")
  private String accessTokenUri;
  @Value("${oauth.api.key}")
  private String apiKey;
  @Value("${oauth.client.id}")
  private String clientId;
  @Value("${oauth.client.secret}")
  private String clientSecret;
  @Value("${oauth.webservice.base.url}")
  private String baseUrl;
  @Value("${oauth.socket.timeout.seconds}")
  private String socketTimeoutSeconds;
  
  
  public ClientCredentialsResourceDetails resource() {
    ClientCredentialsResourceDetails details = new ClientCredentialsResourceDetails();
      details.setAccessTokenUri(accessTokenUri);
      details.setClientId(clientId);
      details.setClientSecret(clientSecret);
      details.setGrantType("client_credentials");      
      details.setId("enrollment");   
      
      return details;
  }
  
  
  @Bean
  @Qualifier(value="oauthTemplate")
  public OAuth2RestTemplate oauthRestTemplate() {
    ClientCredentialsResourceDetails resourceDetails = this.resource(); // create the resourceDetails (clientId, secret, etc) those fields are stored here!!

    resourceDetails.setGrantType(OauthTokenKeys.GRANT_TYPE_CLIENT_CREDENTIALS);

    AccessTokenRequest atr                          = new DefaultAccessTokenRequest();
    OAuth2RestTemplate oauthTemplate                = new OAuth2RestTemplate(resourceDetails, new DefaultOAuth2ClientContext(atr));
    DefaultUriTemplateHandler templateHandler       = new DefaultUriTemplateHandler();
    HttpComponentsClientHttpRequestFactory factory  = getDefaultClientRequestFactory();
    oauthTemplate.setRequestFactory(new BufferingClientHttpRequestFactory(factory)); // we add a buffering request so the body can be read more than once (eg. if debugging, etc)

    templateHandler.setBaseUrl(baseUrl); // the base URL
    oauthTemplate.setUriTemplateHandler(templateHandler);
    oauthTemplate.getInterceptors().add(new EnrollmentRequestInterceptor(apiKey)); // the interceptor is used for debugging requests
    
    return oauthTemplate;
  } 
  
  
  
  /**
   * Helper method to set timeouts.
   * @return
   */
  private HttpComponentsClientHttpRequestFactory getDefaultClientRequestFactory() {
    HttpComponentsClientHttpRequestFactory factory  = new HttpComponentsClientHttpRequestFactory(HttpClients.createDefault());
    Integer timeoutInMilliseconds                   = Integer.parseInt(socketTimeoutSeconds) * 1000;

    factory.setReadTimeout(timeoutInMilliseconds);
    factory.setConnectionRequestTimeout(timeoutInMilliseconds);
    factory.setConnectTimeout(timeoutInMilliseconds);
    return factory;
  }
}
