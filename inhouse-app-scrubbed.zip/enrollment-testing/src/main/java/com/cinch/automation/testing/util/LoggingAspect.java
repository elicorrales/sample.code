package com.cinch.automation.testing.util;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;


@Component
@Aspect
public class LoggingAspect {

	private String applicationName = "cinchEnrollment";

	private static final String BODY_PARAM_NAME = "body";
	private static final Logger log = LoggerFactory.getLogger(LoggingAspect.class);		

	public static final String REQUEST_RESPONSE_LOGGING_TEMPLATE = "{\"app\": \"%s\", \"method\": \"%s\",\"req\": %s,\"resp\": %s,\"executionTime\": %d}";


    @Autowired
    public void setApplicationName(@Value("${application.name}") String applicationName) { this.applicationName = applicationName; }

	/**
	 * Logs request/response from the controller layer.
	 * @param joinPoint
	 * @return
	 * @throws Throwable
	 */
	@Around("execution(* *(..)) && @annotation(Loggable)")
	public Object logControllerInputOutput(ProceedingJoinPoint joinPoint) throws Throwable {
		Instant start, end;
		Object result;
		String resultString = null;
		Method method       = MethodSignature.class.cast(joinPoint.getSignature()).getMethod();
		ObjectWriter writer = new ObjectMapper().writer();    
		start               = Instant.now();
		try {  	    
			result            = joinPoint.proceed();	//fire the call to the next method
			resultString      = writer.writeValueAsString(result); //write the result of this call using jackson

		} catch (Throwable t) {	    //catch and handle the different exceptions that may be thrown from method invocation
			resultString    = writer.writeValueAsString(t.getMessage());
			throw t;
		}  finally {	    
			end = Instant.now();
			log.info(String.format(REQUEST_RESPONSE_LOGGING_TEMPLATE,  //String.format template.
					applicationName,                                          //Application name (from .properties file)
					method.getName(),                                         //The name of this method
					getMethodParameters(method, joinPoint.getArgs(), writer), //Returns request/response values from this call.
					resultString,
					TimeUnit.NANOSECONDS.toMillis(Duration.between(start, end).getNano())
					));	   
		} 
		return result;	  
	}

	/**
	 * Returns the method parameters of this call as a String.
	 * @param method
	 * @param arguments
	 * @param writer
	 * @return
	 */
	private String getMethodParameters(Method method, Object[] arguments, ObjectWriter writer) {
		List<Parameter> parameters  = Arrays.asList(method.getParameters());
		AtomicInteger atomicInt     = new AtomicInteger();
		String jsonParameters       = null;
		if (null!=parameters && 0!=parameters.size()) {
			try {
				jsonParameters = Optional.ofNullable(parameters)
					.orElseGet(ArrayList::new)
					.stream()
					.map(param -> 
					{
						String key = null, value = null;                                    
						try {
							key   = writer.writeValueAsString(getParameterName(param));                                    
							value = writer.writeValueAsString(arguments[atomicInt.getAndIncrement()]);
						} catch (Exception jpe) {
							log.debug("Object did not convert to json, cause: " + jpe.getMessage());
						}
						return key + ":" + value;
					})
					.reduce((t, u) -> t + "," + u)                            
					.get();
			} catch (Exception e) {
				log.error("Failed to retrieve method parameters for logging, cause: " + e.getMessage(),  e);
			}
			return  "{" + jsonParameters + "}";
		} else {
			return "";
		}

	}

	/**
	 * Returns the name of the parameter. Will first check for annotation presence. If no annotations are present, will return synthetic name.
	 * @param param
	 * @return
	 */
	private String getParameterName(Parameter param) {    
		PathVariable pathVariableAnn = param.getAnnotation(PathVariable.class); // Check if @PathVariable    
		if (pathVariableAnn != null) 
			return StringUtils.isEmpty(pathVariableAnn.name()) ? pathVariableAnn.value() : pathVariableAnn.name();

			RequestParam requestParamAnn = param.getAnnotation(RequestParam.class); // Check if @RequestParameter
			if (requestParamAnn != null)
				return StringUtils.isEmpty(requestParamAnn.name()) ? requestParamAnn.value() :  requestParamAnn.name();

				RequestBody requestBodyParamAnn = param.getAnnotation(RequestBody.class); //Check if @RequestBody
				if (requestBodyParamAnn != null)
					return BODY_PARAM_NAME;

				return param.getName(); // Return synthetic name
	}

}
