//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function fireAjax_LoadApplicationBuildInfo() {
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
    		$.ajax({
    			type: "GET",
    			contentType: "application/json",
    			url: "/buildinfo",
    			cache: false,
    			timeout: 600000,
    			async: true,
    			success: function(data){

    		        var buildTimestamp    = data.buildTimestamp;
    		        var appJavaVersion    = data.appJavaVersion;
    		        var applicationName   = data.applicationName;

    		        var buildVersion      = data.buildVersion;
    		        var appEncoding       = data.appEncoding;
    				
    				if (buildTimestamp) { $('#label-build-timestamp').html(buildTimestamp); }
    				if (appJavaVersion) { $('#label-app-java-version').html(appJavaVersion); }
    				if (applicationName) { $('#label-app-name').html(applicationName); }

    				console.log("AJAX SUCCESS : ", data);

    			},


    			error: function (xhr, status, e) {

    				doNotification('error','Error','While Loading App Build Info');

    				if (4==xhr.readyState) {
    					$('#div-ajax-results').html(xhr.responseText);
            	
    				} else if (0==xhr.readyState) {
    					$('#div-ajax-results').html("Possibly Connection Refused , or Permissions, or Server Down, etc..");
    				}
 
  					$('#div-ajax-results').addClass("p-3");
   					$('#div-ajax-results').addClass("mb-2");
   					$('#div-ajax-results').addClass("bg-danger");
    				$('#div-ajax-results').html(e.responseText);

    				console.log("AJAX ERROR : ", e.responseText);

    			},

    			
    			complete: function(jqXHR,textStatus) {

    				console.log("AJAX COMPLETE : ", textStatus);
    			}
 
    		});
} // end of fire_AjaxLoadApplicationBuildInfo() 



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function fireAjax_LoadCellCodesSelectDropDownOptions() {
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
    		$.ajax({
    			type: "GET",
    			contentType: "application/json",
    			url: "/cellcodes",
    			cache: false,
    			timeout: 600000,
    			async: true,
    			success: function(data) {

    				var cellCodes = data.cellCodes;
    				
    				if (cellCodes && cellCodes.length) {

    					var cellCodeTypeAheadList = [];
    					for (var c=0;c<cellCodes.length;c++) {
    						//cellCodeTypeAheadList.push({name:cellCodes[c].cellCode});
    						cellCodeTypeAheadList.push(cellCodes[c].cellCode);
    						$('#div-all-tfn-hidden').append('<input type="hidden" id="input-hidden-tfn-cell-' + cellCodes[c].cellCode + '" value="' + cellCodes[c].tollFree + '"/>');
   						}
    					$('#cellcode-typeahead').typeahead({source:cellCodeTypeAheadList});

    					var lastCellCode = localStorageGetItem('cellcode-typeahead');
    					$('#cellcode-typeahead').get(0).value = lastCellCode;
    					var tfn = $('#input-hidden-tfn-cell-' + lastCellCode).val();
    					$('#tfn').html(tfn);
    					if (checkForZipCellCodeClientId()) {
    						$('#btn-search-products').prop('disabled',false);
    					}

    				} else {

    					doNotification('error','Error', 'No Cell Codes Found');

    					console.log("ERROR : ", 'No Cell Codes Found');

    					//return;
    				}
    				
    				console.log("AJAX SUCCESS : ", data);

    			},


    			error: function (xhr, status, e) {

    				doNotification('error','Error','During Loading Cell Codes');

    				if (4==xhr.readyState) {
    					$('#div-ajax-results').html(xhr.responseText);
            	
    				} else if (0==xhr.readyState) {
    					$('#div-ajax-results').html("Possibly Connection Refused , or Permissions, or Server Down, etc..");
    				}
 
  					$('#div-ajax-results').addClass("p-3");
   					$('#div-ajax-results').addClass("mb-2");
   					$('#div-ajax-results').addClass("bg-danger");
    				$('#div-ajax-results').html(e.responseText);

    				console.log("AJAX ERROR : ", e.responseText);

    			},

    			
    			complete: function(jqXHR,textStatus) {

    				console.log("AJAX COMPLETE : ", textStatus);
    				
    			}
 
    		});
} // end of function fireCellCodesSelectDropDownOptionsLoad() 








//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function populateProductsDropdown(product) {
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	

	var prodGenSeq  = product.prodGenSeq;
	var name        = product.name;

	globalvar_allProductPlansMap[prodGenSeq] = product;

	$('#products-multi-select-dropdown').append(
        					'<option '
        					+ 'value=\''
        					+ prodGenSeq
        					+ '\'>' 
        					+ prodGenSeq + ' ' + name 
        					+ '</option>');

	
}





//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function fireAjax_SubmitMainProductsSearch() {
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	doNotification(null,null,null);
	
	var clientId = $("#client-id-input").val();
	var cellCode = $("#cellcode-typeahead").val();
	var zip      = $("#zip-input").val();
	
	if (!clientId || !cellCode || !zip || 5 != zip.length) {

		doNotification('error','Error', 'Missing Input(s)');
		console.log("ERROR : ", 'Missing input(s) clientId:[' + clientId +  '], cellCode:[' + cellCode + '], zip:[' + zip + ']');

		$("#btn-search-products").removeClass("btn-primary");
		$("#btn-search-products").removeClass("btn-warning");
		$("#btn-search-products").removeClass("btn-success");
		$("#btn-search-products").addClass("btn-danger");
		$('#payment-type-multi-select-dropdown').prop('disabled',true);
		$('#payment-type-multi-select-dropdown').selectpicker('refresh');

		$('#payment-freq-multi-select-dropdown').prop('disabled',true);
		$('#payment-freq-multi-select-dropdown').selectpicker('refresh');
		$('#industry-code-multi-select-dropdown').prop('disabled',true);
		$('#industry-code-multi-select-dropdown').selectpicker('refresh');

		$('#products-multi-select-dropdown').prop('disabled',true);
		$('#products-multi-select-dropdown').selectpicker('refresh');
		$('#div-products-select-test-form').addClass("collapse");
 
		if (!cellCode) {
			$("#cellcode-typeahead").addClass('alert-danger');
    		$('#cellcode-typeahead').selectpicker('refresh');
		}

		if (!clientId) {
			$("#client-id-input").addClass('alert-danger');
		}

		if (!zip || 5 != zip.length) {
			$("#zip-input").addClass('alert-danger');
		}

		return;
	}

    var searchCriteria = {}
    searchCriteria["clientId"] = clientId;
    searchCriteria["cellCode"] = cellCode;
    searchCriteria["zip"]      = zip;

    $("#btn-search-products").removeClass("btn-success");
    $("#btn-search-products").removeClass("btn-danger");
    $("#btn-search-products").addClass("btn-primary");
    $("#btn-search-products").text('Loading...');
    $('#products-search-form').prop('disabled',true);
    $('#btn-test-enrollments').prop('disabled',true);
	$('#btn-cancel-test').prop('disabled',true);
	$('.div-cchs-pdf').addClass('collapse');
    $("#btn-test-enrollments").removeClass("btn-success");
    $("#btn-test-enrollments").removeClass("btn-warning");
    $("#btn-test-enrollments").removeClass("btn-danger");
    $("#btn-test-enrollments").addClass("btn-primary");
    $('#products-multi-select-dropdown').children().remove();
    $('#products-multi-select-dropdown').prop('disabled',true);
    $('#products-multi-select-dropdown').selectpicker('refresh');
    $('#payment-type-multi-select-dropdown').prop('disabled',true);
    $('#payment-type-multi-select-dropdown').selectpicker('refresh');

    $('#payment-freq-multi-select-dropdown').prop('disabled',true);
    $('#payment-freq-multi-select-dropdown').selectpicker('refresh');
    $('#industry-code-multi-select-dropdown').prop('disabled',true);
    $('#industry-code-multi-select-dropdown').selectpicker('refresh');

    $('#client-id-input').prop('disabled',true);
    $('#cellcode-typeahead').prop('disabled',true);
    $('#cellcode-typeahead').selectpicker('refresh');
    $('#zip-input').prop('disabled',true);
    $("#btn-search-products").prop("disabled", true);
	$('#div-ajax-results').removeClass("p-3");
	$('#div-ajax-results').removeClass("mb-2");
	$('#div-ajax-results').removeClass("bg-danger");
	$('#div-ajax-results').html('');
	$('#table-enrollment-results tbody tr').each(function(i,tableRow) { tableRow.remove(); });
	$('#table-enrollment-errors tbody tr').each(function(i,tableRow) { tableRow.remove(); });
	$('#div-ajax-enrollment-results').addClass("collapse");
	$('#div-ajax-enrollment-errors').addClass("collapse");
	$('#div-collapse-details').addClass("collapse");
	$('#div-products-select-test-form').addClass("collapse");
	$('#div-pdf').addClass('collapse');

	globalvar_displayEnrollmentErrorsTable = false;
	globalvar_displayEnrollmentResultsTable = false;


 
    doNotification('wait',null,'Please Wait..');

    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "/products",
        data: JSON.stringify(searchCriteria),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        async: true,
        success: function (data) {

        	var allProducts = data.productPlans; // reusing API microservices jar
        	
        	if (allProducts && allProducts.length) {


       			$('#client-id-hidden').val(clientId);
       			$('#cell-hidden').val(cellCode);
       			$('#zip-hidden').val(zip);
       			
       			////////////////////////////////////////////////////////////////////////////////////////////////
        		// find the product with the most number of deductible buydowns, to use those for the input selection list
       			////////////////////////////////////////////////////////////////////////////////////////////////
       			var buydownList = null; // this will hold the list of most buydowns
       			var mostBuydowns = 0;//we start assuming no product has any buydowns, so we can only go up from here

        		for (var i=0; i<allProducts.length;i++) {

       				if (allProducts[i].deductibleBuydowns && allProducts[i].deductibleBuydowns.length > mostBuydowns) {
       					buydownList = allProducts[i].deductibleBuydowns; //any given assignment may not be the one till we check all products
       				}
        		}


       			////////////////////////////////////////////////////////////////////////////////////////////////
       			// Populate the Products dropdown
       			////////////////////////////////////////////////////////////////////////////////////////////////
        		for (var i=0; i<allProducts.length;i++) {
        			populateProductsDropdown(allProducts[i]);
        		}

 
 
       			////////////////////////////////////////////////////////////////////////////////////////////////
       			// Re-enable all the widgets 
       			////////////////////////////////////////////////////////////////////////////////////////////////
        		$('#div-products-select-test-form').removeClass("collapse");
        		$('#payment-type-multi-select-dropdown').prop('disabled',false);
        		$('#payment-type-multi-select-dropdown').selectpicker('refresh');
        		$('#payment-freq-multi-select-dropdown').prop('disabled',false);
        		$('#payment-freq-multi-select-dropdown').selectpicker('refresh');
        		$('#industry-code-multi-select-dropdown').prop('disabled',false);
        		$('#industry-code-multi-select-dropdown').selectpicker('refresh');

        		$('#products-multi-select-dropdown').prop('disabled',false);
        		$('#products-multi-select-dropdown').selectpicker('refresh');
        		$('#products-multi-select-dropdown').selectpicker('toggle');

        		
        	// even though the ajax call itself might have been a 'success', that doesn't mean we got back products.
        	// if not, we need to turn the resutl into an error
        	} else {
        		
        		doNotification('error','Error', 'No Products Found');
        		console.log("ERROR : ", 'No Products Found for ' + searchCriteria["clientId"] +  ', ' +searchCriteria["cellCode"] + ', ' +searchCriteria["zip"]);

        		$("#btn-search-products").removeClass("btn-primary");
        		$("#btn-search-products").removeClass("btn-warning");
        		$("#btn-search-products").removeClass("btn-success");
        		$("#btn-search-products").addClass("btn-danger");
        		$('#payment-type-multi-select-dropdown').prop('disabled',true);
        		$('#payment-type-multi-select-dropdown').selectpicker('refresh');

        		$('#payment-freq-multi-select-dropdown').prop('disabled',true);
        		$('#payment-freq-multi-select-dropdown').selectpicker('refresh');
        		$('#industry-code-multi-select-dropdown').prop('disabled',true);
        		$('#industry-code-multi-select-dropdown').selectpicker('refresh');

        		$('#products-multi-select-dropdown').prop('disabled',true);
        		$('#products-multi-select-dropdown').selectpicker('refresh');

        		$('#div-products-select-test-form').addClass("collapse");
 
        		return;
        	}
        	
            doNotification('success','Success', 'Found Products');
            console.log("SUCCESS : ", data);
            $('#div-ajax-results').removeClass("p-3");
            $('#div-ajax-results').removeClass("mb-2");
            $('#div-ajax-results').removeClass("bg-danger");
            $('#div-ajax-results').html('');
            $("#btn-search-products").removeClass("btn-primary");
            $("#btn-search-products").removeClass("btn-warning");
            $("#btn-search-products").removeClass("btn-danger");
            $("#btn-search-products").addClass("btn-success");
        },
        
        
    			
    	error: function (xhr, status, e) {
        	doNotification('error','Error','In Finding Products');
            console.log("ERROR : ", e.responseText);
            $('#div-ajax-results').addClass("p-3");
            $('#div-ajax-results').addClass("mb-2");
            $('#div-ajax-results').addClass("bg-danger");

			if (4==xhr.readyState) {
				$('#div-ajax-results').html(xhr.responseText);
            	
			} else if (0==xhr.readyState) {
				$('#div-ajax-results').html("Possibly Connection Refused , or Permissions, or Server Down, etc..");
			}

            $("#btn-search-products").removeClass("btn-primary");
            $("#btn-search-products").removeClass("btn-warning");
            $("#btn-search-products").removeClass("btn-success");
            $("#btn-search-products").addClass("btn-danger");
            $('#payment-type-multi-select-dropdown').prop('disabled',true);
            $('#payment-type-multi-select-dropdown').selectpicker('refresh');

            $('#payment-freq-multi-select-dropdown').prop('disabled',true);
            $('#payment-freq-multi-select-dropdown').selectpicker('refresh');
            $('#industry-code-multi-select-dropdown').prop('disabled',true);
            $('#industry-code-multi-select-dropdown').selectpicker('refresh');

            $('#products-multi-select-dropdown').prop('disabled',true);
            $('#products-multi-select-dropdown').selectpicker('refresh');
       		$('#div-products-select-test-form').addClass("collapse");

        }
 
        ,
        complete: function(jqXHR,textStatus) {
            console.log("COMPLETE : ", textStatus);
        	$('#products-search-form').prop('disabled',false);
            $("#btn-search-products").prop("disabled", false);
            $("#btn-search-products").text('Search');
            $('#client-id-input').prop('disabled',false);
            $('#cellcode-typeahead').prop('disabled',false);
            $('#cellcode-typeahead').selectpicker('refresh');
            $('#zip-input').prop('disabled',false);
        }
 
    });

} // end of function fireAjax_SubmitMainProductsSearch() 


/*
 * this function is first called by function fireAjax_SubmitMainProductsTest() 
 * and then can subsequently call itself
 */
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var submitProductsForTestingAjaxFunction  = function(isFirstTestRun) {
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	var nextIdxToTest  = $('#next-product-to-test-idx-hidden').val();

	var progressNow = Math.round((nextIdxToTest*100)/globalvar_paramsForEachIndividualTest.length);

	doNotification('wait','Please Wait... ', 'Testing Enrollments... ', progressNow);
	
	var formData = {
			'testList':globalvar_paramsForEachIndividualTest,
			'nextIdxToTest':nextIdxToTest
	};
	
	var currentAjaxCallReturnedSuccess = false;


	$.ajax({
  			type: "POST",
   			contentType: "application/json",
   			url: "/enrollments",
   			data: JSON.stringify(formData),
   			dataType: 'json',
   			cache: false,
   			timeout: 600000,
   			async: true,
   			
   		
   			success: function(data) {

    				currentAjaxCallReturnedSuccess = true;
    				
    				if (data && data.enrollmentResults && data.enrollmentResults.length) {
    					
    				
    					//add product info to make it easier when displaying details
    					$.each(data.enrollmentResults,function(i,enrRes) {
    						if (enrRes.enrollment && enrRes.enrollment.productId) {
    							enrRes.productPlan = globalvar_allProductPlansMap[enrRes.enrollment.productId];
    						}
   						});
    					
    					globalvar_enrollmentResults = data.enrollmentResults;
    				
    					nextIdxToTest = data.nextProductToTestIdx;
    					$('#next-product-to-test-idx-hidden').val(nextIdxToTest);
    				
    					var testListLen = globalvar_paramsForEachIndividualTest.length;

    					if (nextIdxToTest + 1 >= testListLen ) { // are we done going through the entire test list?

    						$('#next-product-to-test-idx-hidden').val(0);
 
    						doNotification('success','Success', 'Tested Enrollments');

    						globalvar_enrollmentResults.sort(compareProductIds);
 
    						$.each(globalvar_enrollmentResults,showEnrollmentResult);

							$("#btn-test-enrollments").removeClass("btn-primary");
							$("#btn-test-enrollments").removeClass("btn-warning");
							$("#btn-test-enrollments").removeClass("btn-danger");
							$("#btn-test-enrollments").addClass("btn-success");
    						$('#buydown-select').prop('disabled',false);
    						$('#products-multi-select-dropdown').prop('disabled',false);
    						$('#products-multi-select-dropdown').selectpicker('refresh');
    						$('#payment-type-multi-select-dropdown').prop('disabled',false);
    						$('#payment-type-multi-select-dropdown').selectpicker('refresh');

    						$('#payment-freq-multi-select-dropdown').prop('disabled',false);
    						$('#payment-freq-multi-select-dropdown').selectpicker('refresh');
    						$('#industry-code-multi-select-dropdown').prop('disabled',false);
    						$('#industry-code-multi-select-dropdown').selectpicker('refresh');

							$('#btn-test-enrollments').text('Test');
							$("#btn-test-enrollments").prop("disabled", false);
							$('#btn-cancel-test').prop('disabled',true);
							$('.div-cchs-pdf').removeClass('collapse');


							$('#products-search-form').prop('disabled',false);
							$("#btn-search-products").prop("disabled", false);
							$('#client-id-input').prop('disabled',false);
							$('#cellcode-typeahead').prop('disabled',false);
							$('#cellcode-typeahead').selectpicker('refresh');
							$('#zip-input').prop('disabled',false);

							if (globalvar_displayEnrollmentResultsTable) $('#div-ajax-enrollment-results').removeClass("collapse");
							if (globalvar_displayEnrollmentErrorsTable) $('#div-ajax-enrollment-errors').removeClass("collapse");

    					} else  { //we are still going through the list - we're not done

 
    						doNotification('wait','Please Wait... ', 'Testing Enrollments... ');

    						$.each(globalvar_enrollmentResults,function(i,result) {
    							showEnrollmentResult(i,result);
    						});

    						$('#buydown-select').prop('disabled',true);
    						$('#products-multi-select-dropdown').prop('disabled',true);
    						$('#products-multi-select-dropdown').selectpicker('refresh');
    						$('#payment-type-multi-select-dropdown').prop('disabled',true);
    						$('#payment-type-multi-select-dropdown').selectpicker('refresh');

    						$('#payment-freq-multi-select-dropdown').prop('disabled',true);
    						$('#payment-freq-multi-select-dropdown').selectpicker('refresh');
    						$('#industry-code-multi-select-dropdown').prop('disabled',true);
    						$('#industry-code-multi-select-dropdown').selectpicker('refresh');

							$("#btn-test-enrollments").removeClass("btn-success");
							$("#btn-test-enrollments").removeClass("btn-warning");
							$("#btn-test-enrollments").removeClass("btn-danger");
							$("#btn-test-enrollments").addClass("btn-primary");
							$('#btn-test-enrollments').text('Testing...');
							$("#btn-test-enrollments").prop("disabled", true);
							$('#btn-cancel-test').prop('disabled',false);
							$('.div-cchs-pdf').addClass('collapse');
							if (globalvar_displayEnrollmentResultsTable) $('#div-ajax-enrollment-results').removeClass("collapse");
							if (globalvar_displayEnrollmentErrorsTable) $('#div-ajax-enrollment-errors').removeClass("collapse");

    					}
    				

    				} else {

    					doNotification('error','Error','No Enrollment Results');
    					
    					
    				}

   					console.log("AJAX SUCCESS : ", data);
    			}

    			,


    			error: function (xhr, status, e) {
  
    				doNotification('error','Error',null);
  					$('#div-ajax-results').addClass("p-3");
   					$('#div-ajax-results').addClass("mb-2");
   					$('#div-ajax-results').addClass("bg-danger");
    				if (4==xhr.readyState) {
    					$('#div-ajax-results').html(xhr.responseText);
            	
    				} else if (0==xhr.readyState) {
    					$('#div-ajax-results').html("Possibly Connection Refused , or Permissions, or Server Down, etc..");
    				}
 
    				$("#btn-test-enrollments").removeClass("btn-primary");
    				$("#btn-test-enrollments").removeClass("btn-warning");
    				$("#btn-test-enrollments").removeClass("btn-success");
    				$("#btn-test-enrollments").addClass("btn-danger");
    				$("#btn-test-enrollments").prop("disabled", false);
   					$('#btn-cancel-test').prop('disabled',true);
					$('.div-cchs-pdf').removeClass('collapse');

    				$("#btn-test-enrollments").text('Test');
 
    				console.log("AJAX ERROR : ", xhr.responseText);
    			}

    			,


    			complete: function(xhr,textStatus) {
        	
   					var testListLen = globalvar_paramsForEachIndividualTest.length;

   					if (globalvar_userRequestedCancelTest) {
 
   							globalvar_userRequestedCancelTest = false;
   							
    						doNotification('warning','Note', 'You Canceled Testing');

    						$('#buydown-select').prop('disabled',false);
    						$('#products-multi-select-dropdown').prop('disabled',false);
    						$('#products-multi-select-dropdown').selectpicker('refresh');
    						$('#payment-type-multi-select-dropdown').prop('disabled',false);
    						$('#payment-type-multi-select-dropdown').selectpicker('refresh');
    						$('#payment-freq-multi-select-dropdown').prop('disabled',false);
    						$('#payment-freq-multi-select-dropdown').selectpicker('refresh');
    						$('#industry-code-multi-select-dropdown').prop('disabled',false);
    						$('#industry-code-multi-select-dropdown').selectpicker('refresh');

							$("#btn-test-enrollments").removeClass("btn-warning");
							$("#btn-test-enrollments").removeClass("btn-danger");
							$("#btn-test-enrollments").removeClass("btn-success");
							$("#btn-test-enrollments").addClass("btn-primary");
							$('#btn-test-enrollments').text('Test');
							$("#btn-test-enrollments").prop("disabled", false);
							$("#btn-cancel-test").prop("disabled", true);
							$('.div-cchs-pdf').removeClass('collapse');

							$('#products-search-form').prop('disabled',false);
							$("#btn-search-products").prop("disabled", false);
							$('#client-id-input').prop('disabled',false);
							$('#cellcode-typeahead').prop('disabled',false);
							$('#cellcode-typeahead').selectpicker('refresh');
							$('#zip-input').prop('disabled',false);

    					
    						console.log("AJAX CALLS CANCELED ");


   					} else if (currentAjaxCallReturnedSuccess && nextIdxToTest + 1 < testListLen ) {

    					console.log("AJAX CALLS CONTINUING : MAYBE ...");

   						submitProductsForTestingAjaxFunction();

   					} else {
    					
    						$('#div-pdf').removeClass('collapse');

    						if (currentAjaxCallReturnedSuccess) {
    						
    							doNotification('success','Success', 'Tested Enrollments');

								$("#btn-test-enrollments").removeClass("btn-primary");
								$("#btn-test-enrollments").removeClass("btn-warning");
								$("#btn-test-enrollments").removeClass("btn-danger");
								$("#btn-test-enrollments").addClass("btn-success");
								$('#btn-test-enrollments').text('Test');
								$("#btn-test-enrollments").prop("disabled", false);
								$('#btn-cancel-test').prop('disabled',true);
								$('.div-cchs-pdf').removeClass('collapse');


    						}
    					
							$('#products-search-form').prop('disabled',false);
							$("#btn-search-products").prop("disabled", false);
							$('#client-id-input').prop('disabled',false);
							$('#cellcode-typeahead').prop('disabled',false);
							$('#cellcode-typeahead').selectpicker('refresh');
							$('#zip-input').prop('disabled',false);

   							$('#buydown-select').prop('disabled',false);
   							$('#products-multi-select-dropdown').prop('disabled',false);
   							$('#products-multi-select-dropdown').selectpicker('refresh');
   							$('#payment-type-multi-select-dropdown').prop('disabled',false);
   							$('#payment-type-multi-select-dropdown').selectpicker('refresh');
   							$('#payment-freq-multi-select-dropdown').prop('disabled',false);
   							$('#payment-freq-multi-select-dropdown').selectpicker('refresh');
   							$('#industry-code-multi-select-dropdown').prop('disabled',false);
   							$('#industry-code-multi-select-dropdown').selectpicker('refresh');

    						console.log("AJAX CALLS DONE ");

    				}

    				console.log("AJAX COMPLETE : ", textStatus);

    			}

	});

}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function loadTestListBasedOnSelectedParameters() {
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	globalvar_paramsForEachIndividualTest = [];
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////
	//grab all the inputs -------------------------------------------------------------------------------------------
	//////////////////////////////////////////////////////////////////////////////////////////////////////////

	var clientId = $('#client-id-hidden').val();
	var cellCode = $('#cell-hidden').val();
	var zip      = $('#zip-hidden').val();

	var prodComboOptions = [];
	var selectedComboOptions   = $('#product-combo-options-select-dropdown').val();
	if (selectedComboOptions && selectedComboOptions.length) {
		for (var i=0;i<selectedComboOptions.length;i++) {
			var cOption = JSON.parse(selectedComboOptions[i]);
			cOption.quantitySelected = 1;
			prodComboOptions.push(cOption);
		}
	}
	
	var prodOptions = [];
	var selectedOptions   = $('#product-options-select-dropdown').val();
	if (selectedOptions && selectedOptions.length) {
		for (var i=0;i<selectedOptions.length;i++) {
			var cOption = JSON.parse(selectedOptions[i]);
			cOption.quantitySelected = 1;
			prodOptions.push(cOption);
		}
	}
	
	
	var prodAdditionals = [];
	var selectedAdditionals   = $('#product-additionals-select-dropdown').val();
	if (selectedAdditionals && selectedAdditionals.length) {
		for (var i=0;i<selectedAdditionals.length;i++) {
			var cAdditional = JSON.parse(selectedAdditionals[i]);
			cAdditional.quantitySelected = 1;
			prodAdditionals.push(cAdditional);
		}
	}
	
	
	var pymtType = $('#payment-type-multi-select-dropdown').val();
	var pymtFreqs = $('#payment-freq-multi-select-dropdown').val();
	var indCodes  = $('#industry-code-multi-select-dropdown').val();
	var enrDate   = $('#enrollment-date-datepicker').val();
	var selectedProductIds = $('#products-multi-select-dropdown').val();
	

	//////////////////////////////////////////////////////////////////////////////////////////////////////////
	//load the test list, iterating through all the input combinations -----------------------------------------------
	//////////////////////////////////////////////////////////////////////////////////////////////////////////
	for (var pidx=0;pidx<selectedProductIds.length;pidx++) {
		for (var ptidx=0;ptidx<pymtType.length;ptidx++) {
			for (var pfidx=0;pfidx<pymtFreqs.length;pfidx++) {
				for (var icidx=0;icidx<indCodes.length;icidx++) {
					if (useDefaultDeductible()) {
						
						var inputParams = {
									'clientId':clientId,
									'cellCode':cellCode,
									'zip':zip,
									'pymtType':pymtType[ptidx],
									'pymtFreq':pymtFreqs[pfidx],
									'indCode':indCodes[icidx],
									'enrDate':enrDate,
									'prodGenSeq':selectedProductIds[pidx]
						};
						if (selectedProductIds.length<2) {
							if (prodComboOptions) { inputParams['comboOptions'] = prodComboOptions; }
							if (prodOptions) { inputParams['options'] = prodOptions; }
							if (prodAdditionals) { inputParams['additionals'] = prodAdditionals; }
						}
						globalvar_paramsForEachIndividualTest.push(inputParams);
						

					} else { // test with all deductibles , INCLUDING the default case (above)
						
						var product = globalvar_allProductPlansMap[selectedProductIds[pidx]];
						var buydowns = product.deductibleBuydowns;
						for (var bdidx=0;bdidx<buydowns.length;bdidx++) {
							var buydown = buydowns[bdidx];
							var inputParams = {
									'clientId':clientId,
									'cellCode':cellCode,
									'zip':zip,
									'pymtType':pymtType[ptidx],
									'pymtFreq':pymtFreqs[pfidx],
									'indCode':indCodes[icidx],
									'enrDate':enrDate,
									'prodGenSeq':selectedProductIds[pidx]
							};
							inputParams['newDeduct']  = buydown['newDeductible'];
							inputParams['buydwnCost'] = buydown['buydownCost'];
							if (selectedProductIds.length<2) {
								if (prodComboOptions) { inputParams['comboOptions'] = prodComboOptions; }
								if (prodOptions) { inputParams['options'] = prodOptions; }
								if (prodAdditionals) { inputParams['additionals'] = prodAdditionals; }
							}
							globalvar_paramsForEachIndividualTest.push(inputParams);

						}
						
					}
				}
			}
		}
	}
}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function fireAjax_SubmitMainProductsTest() {
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
		doNotification('wait',null,'Please Wait..');

   		globalvar_enrollmentResultsTableRowIdx = 0;

   		$('#div-pdf').addClass('collapse');

    	if ($('#products-multi-select-dropdown') && $('#products-multi-select-dropdown').val() && $('#products-multi-select-dropdown').val() != '') {
    		
    		$('#products-search-form').prop('disabled',true);
    		$('#buydown-select').prop('disabled',true);
    		$('#payment-type-multi-select-dropdown').prop('disabled',true);
    		$('#payment-type-multi-select-dropdown').selectpicker('refresh');

    		$('#payment-freq-multi-select-dropdown').prop('disabled',true);
    		$('#payment-freq-multi-select-dropdown').selectpicker('refresh');
    		$('#industry-code-multi-select-dropdown').prop('disabled',true);
    		$('#industry-code-multi-select-dropdown').selectpicker('refresh');

    		$('#products-multi-select-dropdown').prop('disabled',true);
    		$('#products-multi-select-dropdown').click();
    		$('#products-multi-select-dropdown').selectpicker('refresh');
    		$('#client-id-input').prop('disabled',true);
    		$('#cellcode-typeahead').prop('disabled',true);
    		$('#cellcode-typeahead').selectpicker('refresh');
    		$('#zip-input').prop('disabled',true);
    		$("#btn-search-products").prop("disabled", true);
    		$('#div-ajax-results').removeClass("p-3");
    		$('#div-ajax-results').removeClass("mb-2");
    		$('#div-ajax-results').removeClass("bg-danger");
    		$('#div-ajax-results').html('');
   			$('#btn-test-enrollments').prop('disabled',true);
   			$('#btn-cancel-test').prop('disabled',false);
   			$('.div-cchs-pdf').addClass('collapse');
   			$('#btn-test-enrollments').text('Testing...');
   			$("#btn-test-enrollments").removeClass("btn-success");
   			$("#btn-test-enrollments").removeClass("btn-warning");
   			$("#btn-test-enrollments").removeClass("btn-danger");
   			$("#btn-test-enrollments").addClass("btn-primary");
    		$("#btn-search-products").removeClass("btn-success");
    		$("#btn-search-products").removeClass("btn-danger");
    		$("#btn-search-products").addClass("btn-primary");
    		$('#table-enrollment-results tbody tr').each(function(i,tableRow) { tableRow.remove(); });
    		$('#table-enrollment-errors tbody tr').each(function(i,tableRow) { tableRow.remove(); });
    		$('#div-ajax-enrollment-results').addClass("collapse");
    		$('#div-ajax-enrollment-errors').addClass("collapse");
    		$('#div-collapse-details').addClass("collapse");
			$('#products-multi-select-dropdown').selectpicker('setStyle','btn-default');
			$("#btn-cancel-test").prop("disabled", false);
    		globalvar_displayEnrollmentErrorsTable = false;
    		globalvar_displayEnrollmentResultsTable = false;

    		loadTestListBasedOnSelectedParameters(); // load the test list
 
    		$('#next-product-to-test-idx-hidden').val('0');//start at the beginning - the first item on the test list

   			submitProductsForTestingAjaxFunction(); // submit the entire test list, let server decide how many to test. it will update the index into the list , for next go-round

    	} else {
    		
    		doNotification('error',null,'Choose Products');
    		$("#btn-test-enrollments").addClass("btn-warning");
    		$("#btn-search-products").removeClass("btn-success");
    		$("#btn-search-products").removeClass("btn-danger");
    		$("#btn-search-products").addClass("btn-primary");

    	}

} // end of function fireAjax_SubmitMainProductsTest() 



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function fireAjax_SubmitMainContractInfoSearch(contract) {
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	$('#div-ajax-results').removeClass("p-3");
	$('#div-ajax-results').removeClass("mb-2");
	$('#div-ajax-results').removeClass("bg-danger");
	$('#div-ajax-results').html('');

    doNotification('wait',null,'Please Wait..');

    $.ajax({
        type: "GET",
        contentType: "application/json",
        url: "/contractinfo/" + contract,
        cache: false,
        timeout: 600000,
        async: true,
        success: function (data) {

        	if (data && data.result && data.result.length) {

        		doNotification('alert-info','Info For Contract',contract);
        		$('#div-ajax-enrollment-results').addClass("collapse");
        		$('#div-ajax-enrollment-errors').addClass("collapse");
        		$('#div-all-input-forms').addClass("collapse");
        		$('#div-contract-info').removeClass("collapse");

        		var jData = JSON.parse(data.result);
        		var fmtJson = JSON.stringify(jData,null,'\t');
        		$('#div-contract-info-content').html('<pre>' + fmtJson + '</pre>');

        		$('#payment-type-multi-select-dropdown').prop('disabled',false);
        		$('#payment-type-multi-select-dropdown').selectpicker('refresh');

        		$('#payment-freq-multi-select-dropdown').prop('disabled',false);
        		$('#payment-freq-multi-select-dropdown').selectpicker('refresh');
        		$('#industry-code-multi-select-dropdown').prop('disabled',false);
        		$('#industry-code-multi-select-dropdown').selectpicker('refresh');

        		$('#products-multi-select-dropdown').prop('disabled',false);
        		$('#products-multi-select-dropdown').selectpicker('refresh');
        		$('#btn-test-enrollments').prop('disabled',false);
				$('#btn-cancel-test').prop('disabled',true);
				$('.div-cchs-pdf').addClass('collapse');


        		doNotification('success','Success', 'Found Info For Contract ' + contract);

        	// even though the ajax call itself might have been a 'success', that doesn't mean we got back contract info.
        	// if not, we need to turn the resutl into an error
        	} else {
        		
        		doNotification('error','Error', 'No Contract Info Found');
        		console.log("ERROR : ", 'No Info Found For Contract ' + contract);

        		//return;
        	}
        	
            console.log("AJAX SUCCESS : ", data);
        }

    	,
        error: function (xhr, status, e) {
        	doNotification('error','Error','In Finding Info For Contract ' + contract);
            $('#div-ajax-results').addClass("p-3");
            $('#div-ajax-results').addClass("mb-2");
            $('#div-ajax-results').addClass("bg-danger");

            if (4==xhr.readyState) {
            	$('#div-ajax-results').html(xhr.responseText);
            	
            } else if (0==xhr.readyState) {
            	$('#div-ajax-results').html("Possibly Connection Refused , or Permissions, or Server Down, etc..");
            }
 
            console.log("AJAX ERROR : ", xhr.responseText);
        }

        ,
        complete: function(jqXHR,textStatus) {
            console.log("AJAX COMPLETE : ", textStatus);
        }
 
    });


} // end of fireAjax_SubmitMainContractInfoSearch(contract) 