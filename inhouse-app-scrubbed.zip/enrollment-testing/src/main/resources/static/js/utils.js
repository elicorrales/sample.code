///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function useDefaultDeductible() {
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	var whichDeductibleChoice  = $("input[name='buydown-select-group']:checked")[0].value;
	if ('DEF' == whichDeductibleChoice) {
		return true;
	} else {
		return false;
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function doDialog(dialogId, isModal) {
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	var winWidth = $(window).width();
	var winHeight = $(window).height();
	
	var diagWidth = winWidth * 0.4;
	var diagHeight = winHeight * 0.8;
	
	var diagMaxWidth = winWidth * 0.9;
	var diagMaxHeight = winHeight * 0.9;

	var diagMinWidth = 300; //winWidth * 0.2;
	var diagMinHeight = 300; //winHeight * 0.2;

	$(dialogId).dialog({
		resizable : true,
		minHeight: diagMinHeight,
		maxHeight: diagMaxHeight,
		minWidth: diagMinWidth,
		maxWidth: diagMaxWidth,
		height: diagHeight,
		width: diagWidth,
		modal: isModal,
		dialogClass: 'no-close',
		buttons: {
			"Close": function() { $(this).dialog("close"); },
			"Close All": function() { 

				
				if (globalvar_createdDialogIdsMap) {
					
					convertDialogIdsMapToArray();

					if (globalvar_createdDialogIdsArray && globalvar_createdDialogIdsArray.length) {
						for(var i=0;i<globalvar_createdDialogIdsArray.length;i++) {
							try {
								//$(globalvar_createdDialogIdsArray[i]).dialog('destroy').remove();
								$(globalvar_createdDialogIdsArray[i]).dialog('destroy');
								$(globalvar_createdDialogIdsArray[i]).addClass('collapse');
							} catch (error) {
								console.error(error);
							}
						}
					}
					createdDialogIds = [];
				}
			}
		}
	});

	globalvar_createdDialogIdsMap[dialogId] = dialogId;
}






function getCurrentTime() {
	return new Date().getTime()/1000 | 0;
}


// pre-pended keys to make it easy to clear them without clearing anything else
function localStorageSetItem(key,item) {
	
	if (window.localStorage) {
		window.localStorage.setItem('cchs-enr-test-' + key,item);
	}
}

// pre-pended keys to make it easy to clear them without clearing anything else
function localStorageGetItem(key) {
	
	if (window.localStorage) {
		return window.localStorage.getItem('cchs-enr-test-' + key);
	}
	
}

// pre-pended keys to make it easy to clear them without clearing anything else
function localStorageClearItems() {
	
	
	if (window.localStorage) {
		var myKeys = [];
		for (var i=0;i<window.localStorage.length;i++) {
			var myKey = window.localStorage.key(i);
			if (myKey.startsWith('cchs-enr-test')) {
				myKeys.push(myKey);
			}
		}
		
		for (var i=0;i<myKeys.length;i++) {
			window.localStorage.removeItem(myKeys[i]);
		}
	}
}



function doNotification(type,title,message,progressValueNow) {
		
	$('#notifications').removeClass('alert-success');
	$('#notifications').removeClass('alert-info');
	$('#notifications').removeClass('alert-warning');
	$('#notifications').removeClass('alert-danger');
	$('#notifications').html('');
	if (type) {

		var notifyHtml;
		
		if (title && message) {
			notifyHtml = '<strong>' + title + '</strong>' + ' : ' + message;
		} else if (title) {
			notifyHtml = '<strong>' + title + '</strong>';
		} else {
			notifyHtml = '<strong>' + message + '</strong>';
		}

		if ('wait' == type) {

			$('#notifications').addClass('alert-info');
			
			if (progressValueNow) {
				notifyHtml += '&nbsp&nbsp'
						+ '<div class="progress">'
						+ '    <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="'
						+ progressValueNow
						+ '" aria-valuemin="0" aria-valuemax="100" style="width: '
						+ progressValueNow
						+ '%">'
						+ progressValueNow
						+ '%</div>'
						+ '</div>'
						;
			} else {
				notifyHtml += '&nbsp&nbsp'
						+ '<span class="glyphicon glyphicon-refresh glyphicon-refresh-animate"></span>'
						;
			}
			
		} else if ('success' == type) {
			$('#notifications').addClass('alert-success');
			
		} else if ('error' == type) {
			$('#notifications').addClass('alert-danger');
			
		} else if ('warning' == type) {
			$('#notifications').addClass('alert-warning');

		} else {

			if (type) $('#notifications').addClass(type);
		}


		$('#notifications').html(notifyHtml);

	}
};


function checkForZipCellCodeClientId() {
	
		var zip = $("#zip-input").val();
		if (!zip || 5 != zip.length || !$.isNumeric(zip)) {
			return false
		}

		var cellCode = $("#cellcode-typeahead").val();
		if (!cellCode) {
			return false;
		}

		var clientId = $("#client-id-input").val();
		if (!clientId) {
			return false
		}
		
		return true;
}



function compareProductIds(a,b) {
	if (!a.productPlan && b.productPlan) {
		return -1;
	} else if (a.productPlan && !b.productPlan) {
		return 1;
	} else if (!a.productPlan && !b.productPlan) {
		return 0;
	} else if (a.productPlan.prodGenSeq < b.productPlan.prodGenSeq) {
		return -1;
	} else if (a.productPlan.prodGenSeq > b.productPlan.prodGenSeq) {
		return 1;
	} else {
		return 0;
	}
}





