/****************************************************************************************************************
 * This application was grown organically.
 * 
 * This JS file is the main file backing the index.html file.
 *
 * - actual requests to back-end services were moved to java-world (rest server that handles the ajax calls)
 *   to get around browsers' blocks due to cross-site requests
 * 
 * - This is a SPA (single-page app).  All interactions after the initial loading of index.jsp are done via
 *   ajax calls.
 *   
 *   (05/14/2018) - there are four front-end ajax calls:
 *   - cellcodes - (as part of initial page-load 
 *   - products - when user clicks 'search' (initial form)
 *   - enrollment - when user clicks 'test' (2nd generated form)
 *   - contractinfo - when user optionally clicks one of the results row links
 *   
 * - Testing a product means selecting a product, a buydown, a payment type, and a payment frequency
 *   from the drop-down list in the 2nd form. 
 *   
 * - A newer feature (organic) added late is to test using all buydowns. As such, it seemed easer to programmatically
 *   'change' / select each of the available buydown options in the dropdown list and submit as if user
 *   had selected them in turn.
 *   
 *   
 *   The typical code flow is :   index.html --> main.js --> ajaxfuncs.js --> enrolldisp.js --> index.html
 ***************************************************************************************************************/

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function viewSelectedDeductibles() {
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	var selectedProductIds = $('#products-multi-select-dropdown').val();
	if (!selectedProductIds || !selectedProductIds.length) {
		return;
	}

/*
 * buydown.length must be greater than 1 to have true buydowns, since backend includes the default into the buydown list.
 */
	
	
	var selectedDeductiblesHtml = '';
	
	for (var pidx=0;pidx<selectedProductIds.length;pidx++) {
		
		var product = globalvar_allProductPlansMap[selectedProductIds[pidx]];
		var buydowns = product.deductibleBuydowns;

		if (useDefaultDeductible()) {
						
			selectedDeductiblesHtml +=
					'<tr>'
					+ '<td>Default</td>'
					+ '<td>' + product.prodGenSeq + '</td>'
					+ '<td>' + (buydowns?buydowns.length:'N/A') + '</td>'
					+ '<td>' + product.deductible + '</td>'
					+ '<td>' + (buydowns && buydowns.length>1?0:'N/A') + '</td>'
					+ '</tr>';

		} else { // test with all deductibles , INCLUDING the default case (above)
		

			for (var bdidx=0; bdidx<buydowns.length;bdidx++) {
				var buydown = buydowns[bdidx];
				var deductible = buydown['newDeductible'];
				var cost = buydown['buydownCost'];
				if (!cost && buydowns.length <2) {
					cost = 'N/A';
				}
				selectedDeductiblesHtml +=
					'<tr>'
					+ '<td class="col-md-2">All</td>'
					+ '<td class="col-md-2">' + product.prodGenSeq + '</td>'
					+ '<td class="col-md-2">' + (buydowns.length) + '</td>'
					+ '<td class="col-md-2">' + deductible + '</td>'
					+ '<td class="col-md-2">' + cost + '</td>'
					+ '</tr>';
			}

		}
	}
	
	var dialogHtml = 
		 '<div class="w-75">'
			+ '<table class="table table-striped table-bordered table-hover">'
				+ '<thead>'
					+ '<tr>'
						+ '<th>Enroll</th>'
						+ '<th>Product Id</th>'
						+ '<th>Num Buydowns</th>'
						+ '<th>Deductible</th>'
						+ '<th>Buydown Cost</th>'
					+ '</tr>'
				+ '</thead>'
				+ '<tbody>'
					+ selectedDeductiblesHtml
				+ '</tbody>'
			+ '</table>'
		+ '</div>';

	var dialogId = '#div-dialog-view-selected-deductibles';
	$(dialogId).html( dialogHtml );
	doDialog(dialogId,true); //true - isModal
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function populateProductComboOptionsDropdown(comboOptionsList) {
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	if (comboOptionsList && comboOptionsList.length) {

		$('#product-combo-options-select-dropdown').children().remove();
		$('#div-product-combo-options').removeClass('collapse');
		$('#product-combo-options-select-dropdown').selectpicker('refresh');

		for (var i=0; i<comboOptionsList.length;i++) {

			var comboOption = comboOptionsList[i];
			var comboItemId  = comboOption.comboItemId;
			var description  = comboOption.description;
			var cost    = comboOption.cost;

			$('#product-combo-options-select-dropdown').append(
        						'<option '
        						+ 'value=\''
        						+ JSON.stringify(comboOption)
        						+ '\'>' 
        						+ 'Id: ' + comboItemId + ', &nbsp Cost:' + cost + ', &nbsp Desc: ' + description
        						+ '</option>');
		}

		$('#product-combo-options-select-dropdown').selectpicker('refresh');

	} else {
		$('#div-product-combo-options').addClass('collapse');
	}
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function populateProductOptionsDropdown(optionsList) {
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	if (optionsList && optionsList.length) {

		$('#product-options-select-dropdown').children().remove();
		$('#div-product-options').removeClass('collapse');
		$('#product-options-select-dropdown').selectpicker('refresh');

		for (var i=0; i<optionsList.length;i++) {

			var option = optionsList[i];
			var categoryId  = option.categoryId;
			var description  = option.description;
			var cost    = option.cost;

			$('#product-options-select-dropdown').append(
        						'<option '
        						+ 'value=\''
        						+ JSON.stringify(option)
        						+ '\'>' 
        						+ 'Id: ' + categoryId + ', &nbsp Cost:' + cost + ', &nbsp Desc: ' + description
        						+ '</option>');
		}

		$('#product-options-select-dropdown').selectpicker('refresh');

	} else {
		$('#div-product-options').addClass('collapse');
	}
}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function populateProductAdditionalsDropdown(additionalsList) {
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	if (additionalsList && additionalsList.length) {

		$('#product-additionals-select-dropdown').children().remove();
		$('#div-product-additionals').removeClass('collapse');
		$('#product-additionals-select-dropdown').selectpicker('refresh');

		for (var i=0; i<additionalsList.length;i++) {

			var additional = additionalsList[i];
			var categoryId  = additional.categoryId;
			var description  = additional.description;
			var cost    = additional.costPerAdditionalItem;

			$('#product-additionals-select-dropdown').append(
        						'<option '
        						+ 'value=\''
        						+ JSON.stringify(additional)
        						+ '\'>' 
        						+ 'Id: ' + categoryId + ', &nbsp Cost:' + cost + ', &nbsp Desc: ' + description
        						+ '</option>');
		}

		$('#product-additionals-select-dropdown').selectpicker('refresh');

	} else {
		$('#div-product-additionals').addClass('collapse');
	}

}





//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$(document).ready(function () {
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	$('#div-products-select-test-form').addClass("collapse");
	$('.div-cchs-pdf').addClass('collapse',true);
	

	$('#products-search-form').prop('disabled',true);

	fireAjax_LoadApplicationBuildInfo();
	


	$('#products-search-form').prop('disabled',false);
	
    $("#products-search-form").submit(function (event) {

		$('#product-combo-options-select-dropdown').children().remove();
		$('#product-combo-options-select-dropdown').selectpicker('refresh');

		$('#product-options-select-dropdown').children().remove();
		$('#product-options-select-dropdown').selectpicker('refresh');

        event.preventDefault();
        fireAjax_SubmitMainProductsSearch();

    });

    $('#products-select-test-form').on('submit', function(event) {
    	
    	event.preventDefault();
        fireAjax_SubmitMainProductsTest();
    });
    		



	$('#div-ajax-results').removeClass("p-3");
	$('#div-ajax-results').removeClass("mb-2");
	$('#div-ajax-results').removeClass("bg-danger");
	$('#div-ajax-results').html('');
	$('#table-enrollment-results tbody tr').each(function(i,tableRow) { tableRow.remove(); });
	$('#table-enrollment-errors tbody tr').each(function(i,tableRow) { tableRow.remove(); });


	$('#div-products-select-test-form').addClass("collapse");

	$('#btn-test-enrollments').prop('disabled',true);
	$('.div-cchs-pdf').addClass('collapse');
	$('#div-ajax-enrollment-results').addClass("collapse");
	$('#div-ajax-enrollment-errors').addClass("collapse");
	$('#div-contract-info').addClass("collapse");


	$('#btn-collapse-contract-info-top').on('click',function() {

		$('#div-all-input-forms').removeClass("collapse");
		$('#div-contract-info').addClass("collapse");
		$('#div-ajax-enrollment-results').removeClass("collapse");
		if (globalvar_displayEnrollmentErrorsTable) $('#div-ajax-enrollment-errors').removeClass("collapse");
		$('.div-cchs-pdf').removeClass('collapse');
		doNotification(null,null,null);
		$("#btn-test-enrollments").removeClass("btn-success");
		$("#btn-test-enrollments").removeClass("btn-warning");
		$("#btn-test-enrollments").removeClass("btn-danger");
		$("#btn-test-enrollments").addClass("btn-primary");
	});

	$('#btn-collapse-contract-info-bottom').on('click',function() {

		$('#div-all-input-forms').removeClass("collapse");
		$('#div-contract-info').addClass("collapse");
		$('#div-ajax-enrollment-results').removeClass("collapse");
		if (globalvar_displayEnrollmentErrorsTable) $('#div-ajax-enrollment-errors').removeClass("collapse");
		$('.div-cchs-pdf').removeClass('collapse');
		doNotification(null,null,null);
		$("#btn-test-enrollments").removeClass("btn-success");
		$("#btn-test-enrollments").removeClass("btn-warning");
		$("#btn-test-enrollments").removeClass("btn-danger");
		$("#btn-test-enrollments").addClass("btn-primary");
	});
	
	
	
	
	$('.btn-cchs-pdf').on('click',function() {

		doNotification(null,null,null);
		
		$('#div-ajax-enrollment-errors,#div-ajax-enrollment-results').printThis();

	});
	

	globalvar_displayEnrollmentErrorsTable = false;
	globalvar_displayEnrollmentResultsTable = false;


	/*********************************************************************************************************
	* initialize zip-input
	* *******************************************************************************************************/
	$("#zip-input").val(localStorageGetItem('zip-input'));
	$("#zip-input").on('change',function() {
		var zip = $('#zip-input').val();
		if (zip && 5 == zip.length && $.isNumeric(zip)) {
			localStorageSetItem('zip-input',zip);
		}
	});
	$("#zip-input").on('keydown',function() {
	
		var zip = $("#zip-input").val();
		if (zip && 5 == zip.length) { return; }
	});
	$("#zip-input").on('keyup',function() {
		doNotification('warning','Note','You Changed Zip Code');
		$("#zip-input").removeClass('alert-danger');
		$("#btn-search-products").removeClass("btn-success");
		$("#btn-search-products").removeClass("btn-danger");
		$("#btn-search-products").addClass("btn-primary");
		$('#div-products-select-test-form').addClass("collapse");
		$('#div-ajax-enrollment-results').addClass("collapse");
		$('#div-ajax-enrollment-errors').addClass("collapse");
    	$('.div-cchs-pdf').addClass('collapse');

		var zip = $("#zip-input").val();
		if (!zip || 5 != zip.length || !$.isNumeric(zip)) {
			$("#zip-input").addClass('alert-danger');
		} else {
			$("#zip-input").removeClass('alert-danger');
		}
		if (!checkForZipCellCodeClientId()) {
			$('#btn-search-products').prop('disabled',true);
		} else {
			$('#btn-search-products').prop('disabled',false);
		}
	});


	
	
	/*********************************************************************************************************
	* initialize cellcode-typeahead
	* *******************************************************************************************************/
	$("#cellcode-typeahead").on('change',function() {
		
			var cellCode = $('#cellcode-typeahead').val();
			if (cellCode) {
				localStorageSetItem('cellcode-typeahead',cellCode);
				var tfn = $('#input-hidden-tfn-cell-' + cellCode).val();
				if (tfn) {
					$('#tfn').html(tfn);
				} else {
					$('#tfn').html('000-000-0000');
				}
			} else {
				$('#tfn').html('000-000-0000');
			}
	});
	$("#cellcode-typeahead").on('keyup',function() {
			doNotification('warning','Note','You Changed Client Id');
			$("#btn-search-products").removeClass("btn-success");
			$("#btn-search-products").removeClass("btn-danger");
			$("#btn-search-products").addClass("btn-primary");
			$('#div-products-select-test-form').addClass("collapse");
			$('#div-ajax-enrollment-results').addClass("collapse");
			$('#div-ajax-enrollment-errors').addClass("collapse");
			$('.div-cchs-pdf').addClass('collapse');

			var cellCode = $("#cellcode-typeahead").val();
			if (!cellCode) {
				$("#cellcode-typeahead").addClass('alert-danger');
			} else {
				$("#cellcode-typeahead").removeClass('alert-danger');
			}
			if (!checkForZipCellCodeClientId()) {
				$('#btn-search-products').prop('disabled',true);
			} else {
				$('#btn-search-products').prop('disabled',false);
			}
	});
	fireAjax_LoadCellCodesSelectDropDownOptions();

	
	/*********************************************************************************************************
	* initialize client-id-input
	* *******************************************************************************************************/
	$("#client-id-input").val(localStorageGetItem('client-id-input'));
	$("#client-id-input").on('change',function() {
		var clientId = $('#client-id-input').val();
		if (clientId) {
			localStorageSetItem('client-id-input',clientId);
		}
	});
	$("#client-id-input").on('keyup',function() {
		doNotification('warning','Note','You Changed Client Id');
		$("#client-id-input").removeClass('alert-danger');
		$("#btn-search-products").removeClass("btn-success");
		$("#btn-search-products").removeClass("btn-danger");
		$("#btn-search-products").addClass("btn-primary");
		$('#div-products-select-test-form').addClass("collapse");
		$('#div-ajax-enrollment-results').addClass("collapse");
		$('#div-ajax-enrollment-errors').addClass("collapse");
		$('.div-cchs-pdf').addClass('collapse');

		var clientId = $("#client-id-input").val();
		if (!clientId) {
			$("#client-id-input").addClass('alert-danger');
		} else {
			$("#client-id-input").removeClass('alert-danger');
			localStorageSetItem('client-id-input',clientId);
		}
		if (!checkForZipCellCodeClientId()) {
			$('#btn-search-products').prop('disabled',true);
		} else {
			$('#btn-search-products').prop('disabled',false);
		}
	});

	
	/*********************************************************************************************************
	* initialize buydown-select-
	* *******************************************************************************************************/
	var deductible = localStorageGetItem('buydown-select');

	if ('DEF' == deductible) {
		
		$('#buydown-select-def').prop('checked',true);
		$('#buydown-select-all').prop('checked',false);

	} else {
		
		$('#buydown-select-def').prop('checked',false);
		$('#buydown-select-all').prop('checked',true);
	}

	$('#buydown-select-def').on('change',function() {
		var deductible = $("input[name='buydown-select-group']:checked")[0].value;
		localStorageSetItem('buydown-select',deductible);
		doNotification('warning','Note','You Changed Deductible');
		$("#btn-search-products").removeClass("btn-success");
		$("#btn-search-products").removeClass("btn-danger");
		$("#btn-search-products").addClass("btn-primary");
		$("#btn-test-enrollments").removeClass("btn-success");
		$("#btn-test-enrollments").removeClass("btn-warning");
		$("#btn-test-enrollments").removeClass("btn-danger");
		$("#btn-test-enrollments").addClass("btn-primary");
		$('#div-ajax-enrollment-results').addClass("collapse");
		$('#div-ajax-enrollment-errors').addClass("collapse");
		$('#next-product-to-test-idx-hidden').val('0');
		$('.div-cchs-pdf').addClass('collapse');
		var paytype = $('#payment-type-multi-select-dropdown').val();
		var payfreq = $('#payment-freq-multi-select-dropdown').val();
		var indCode = $('#industry-code-multi-select-dropdown').val();
		var enrDate = $('#enrollment-date-datepicker').val();
		var products = $('#products-multi-select-dropdown').val();
		if (!products || !products.length || !paytype || !paytype.length || !payfreq || !payfreq.length || !indCode || !indCode.length) {
			$('#btn-test-enrollments').prop('disabled',true);
			$('.div-cchs-pdf').addClass('collapse',true);
		} else {
			$('#btn-test-enrollments').prop('disabled',false);
		}
	});

	$('#buydown-select-all').on('change',function() {
		var deductible = $("input[name='buydown-select-group']:checked")[0].value;
		localStorageSetItem('buydown-select',deductible);
		doNotification('warning','Note','You Changed Deductible');
		$("#btn-search-products").removeClass("btn-success");
		$("#btn-search-products").removeClass("btn-danger");
		$("#btn-search-products").addClass("btn-primary");
		$("#btn-test-enrollments").removeClass("btn-success");
		$("#btn-test-enrollments").removeClass("btn-warning");
		$("#btn-test-enrollments").removeClass("btn-danger");
		$("#btn-test-enrollments").addClass("btn-primary");
		$('#div-ajax-enrollment-results').addClass("collapse");
		$('#div-ajax-enrollment-errors').addClass("collapse");
		$('#next-product-to-test-idx-hidden').val('0');
		$('.div-cchs-pdf').addClass('collapse');
		var paytype = $('#payment-type-multi-select-dropdown').val();
		var payfreq = $('#payment-freq-multi-select-dropdown').val();
		var indCode = $('#industry-code-multi-select-dropdown').val();
		var enrDate = $('#enrollment-date-datepicker').val();
		var products = $('#products-multi-select-dropdown').val();
		if (!products || !products.length || !paytype || !paytype.length || !payfreq || !payfreq.length || !indCode || !indCode.length) {
			$('#btn-test-enrollments').prop('disabled',true);
			$('.div-cchs-pdf').addClass('collapse',true);
		} else {
			$('#btn-test-enrollments').prop('disabled',false);
		}
	});



	
	
	
	
	
	
	/*********************************************************************************************************
	* initialize payment-type-multi-select-dropdown
	* *******************************************************************************************************/
	$('#payment-type-multi-select-dropdown').selectpicker({noneSelectedText: 'Select Payment Type(s) '});
	var pymtTypeMultiSelectedString = localStorageGetItem('payment-type-multi-select-dropdown');
	var pymtTypeMultiSelectedArray = ('undefined'!=pymtTypeMultiSelectedString?JSON.parse(pymtTypeMultiSelectedString):null);
	if (pymtTypeMultiSelectedArray) { $('#payment-type-multi-select-dropdown').selectpicker('val', pymtTypeMultiSelectedArray ); }
	$('#payment-type-multi-select-dropdown').on('change',function() {
		doNotification('warning','Note','You Changed Payment Type');
		$("#btn-search-products").removeClass("btn-success");
		$("#btn-search-products").removeClass("btn-danger");
		$("#btn-search-products").addClass("btn-primary");
		$("#btn-test-enrollments").removeClass("btn-success");
		$("#btn-test-enrollments").removeClass("btn-warning");
		$("#btn-test-enrollments").removeClass("btn-danger");
		$("#btn-test-enrollments").addClass("btn-primary");
		$('#div-ajax-enrollment-results').addClass("collapse");
		$('#div-ajax-enrollment-errors').addClass("collapse");
		$('#next-product-to-test-idx-hidden').val('0');
		$('.div-cchs-pdf').addClass('collapse');
		var paytype = $('#payment-type-multi-select-dropdown').val();
		var payfreq = $('#payment-freq-multi-select-dropdown').val();
		var indCode = $('#industry-code-multi-select-dropdown').val();
		var enrDate = $('#enrollment-date-datepicker').val();
		var products = $('#products-multi-select-dropdown').val();
		var payTypeString = JSON.stringify(paytype);
		localStorageSetItem('payment-type-multi-select-dropdown',payTypeString);
		if (!products || !products.length || !paytype || !paytype.length || !payfreq || !payfreq.length || !indCode || !indCode.length) {
			$('#btn-test-enrollments').prop('disabled',true);
			$('.div-cchs-pdf').addClass('collapse',true);
		} else {
			$('#btn-test-enrollments').prop('disabled',false);
		}
	});


	/*********************************************************************************************************
	* initialize payment-freq-multi-select-dropdown
	* *******************************************************************************************************/
	$('#payment-freq-multi-select-dropdown').selectpicker({noneSelectedText: 'Select Payment Frequency(ies) '});
	var pymtFreqMultiSelectedString = localStorageGetItem('payment-freq-multi-select-dropdown');
	var pymtFreqMultiSelectedArray = ('undefined'!=pymtFreqMultiSelectedString?JSON.parse(pymtFreqMultiSelectedString):null);
	if (pymtFreqMultiSelectedArray) { $('#payment-freq-multi-select-dropdown').selectpicker('val', pymtFreqMultiSelectedArray ); }
	$('#payment-freq-multi-select-dropdown').on('change',function() {
		doNotification('warning','Note','You Changed Payment Frequency');
		$("#btn-search-products").removeClass("btn-success");
		$("#btn-search-products").removeClass("btn-danger");
		$("#btn-search-products").addClass("btn-primary");
		$("#btn-test-enrollments").removeClass("btn-success");
		$("#btn-test-enrollments").removeClass("btn-warning");
		$("#btn-test-enrollments").removeClass("btn-danger");
		$("#btn-test-enrollments").addClass("btn-primary");
		$('#div-ajax-enrollment-results').addClass("collapse");
		$('#div-ajax-enrollment-errors').addClass("collapse");
		$('#next-product-to-test-idx-hidden').val('0');
		$('.div-cchs-pdf').addClass('collapse');
		var paytype = $('#payment-type-multi-select-dropdown').val();
		var payfreq = $('#payment-freq-multi-select-dropdown').val();
		var indCode = $('#industry-code-multi-select-dropdown').val();
		var enrDate = $('#enrollment-date-datepicker').val();
		var products = $('#products-multi-select-dropdown').val();
		var payFreqString = JSON.stringify(payfreq);
		localStorageSetItem('payment-freq-multi-select-dropdown',payFreqString);
		if (!products || !products.length || !paytype || !paytype.length || !payfreq || !payfreq.length || !indCode || !indCode.length) {
			$('#btn-test-enrollments').prop('disabled',true);
			$('.div-cchs-pdf').addClass('collapse',true);
		} else {
			$('#btn-test-enrollments').prop('disabled',false);
		}
	});

	
	/*********************************************************************************************************
	* initialize industry-code-multi-select-dropdown
	* *******************************************************************************************************/
	$('#industry-code-multi-select-dropdown').selectpicker({noneSelectedText: 'Select Industry Code(s)'});
	var indCodeMultiSelectedString = localStorageGetItem('industry-code-multi-select-dropdown');
	var indCodeMultiSelectedArray = ('undefined'!=indCodeMultiSelectedString?JSON.parse(indCodeMultiSelectedString):null);
	if (indCodeMultiSelectedArray) { $('#industry-code-multi-select-dropdown').selectpicker('val', indCodeMultiSelectedArray ); }
	$('#industry-code-multi-select-dropdown').selectpicker('val', indCodeMultiSelectedArray );
	$('#industry-code-multi-select-dropdown').on('change',function() {
		doNotification('warning','Note','You Changed Industry Code');
		$("#btn-search-products").removeClass("btn-success");
		$("#btn-search-products").removeClass("btn-danger");
		$("#btn-search-products").addClass("btn-primary");
		$("#btn-test-enrollments").removeClass("btn-success");
		$("#btn-test-enrollments").removeClass("btn-warning");
		$("#btn-test-enrollments").removeClass("btn-danger");
		$("#btn-test-enrollments").addClass("btn-primary");
		$('#div-ajax-enrollment-results').addClass("collapse");
		$('#div-ajax-enrollment-errors').addClass("collapse");
		$('#next-product-to-test-idx-hidden').val('0');
		$('.div-cchs-pdf').addClass('collapse');
		var paytype = $('#payment-type-multi-select-dropdown').val();
		var payfreq = $('#payment-freq-multi-select-dropdown').val();
		var indCode = $('#industry-code-multi-select-dropdown').val();
		var enrDate = $('#enrollment-date-datepicker').val();
		var products = $('#products-multi-select-dropdown').val();
		var indCodeString = JSON.stringify(indCode);
		localStorageSetItem('industry-code-multi-select-dropdown',indCodeString);
		if (!products || !products.length || !paytype || !paytype.length || !payfreq || !payfreq.length || !indCode || !indCode.length) {
			$('#btn-test-enrollments').prop('disabled',true);
			$('.div-cchs-pdf').addClass('collapse',true);
		} else {
			$('#btn-test-enrollments').prop('disabled',false);
		}
	});

	
	/*********************************************************************************************************
	* initialize enrollment-date-datepicker
	* *******************************************************************************************************/
	var enrollmentDateString = localStorageGetItem('enrollment-date-datepicker');
	if (enrollmentDateString) { $('#enrollment-date-datepicker').attr('value', enrollmentDateString ); }
	var options = {

			format: 'yyyy-mm-dd',
			todayHighlight: true,
			autoClose: true
	};
	$('#enrollment-date-datepicker').datepicker(options);
	$('#enrollment-date-datepicker').on('change',function() {
		doNotification('warning','Note','You Changed Enrollment Date');
		$("#btn-search-products").removeClass("btn-success");
		$("#btn-search-products").removeClass("btn-danger");
		$("#btn-search-products").addClass("btn-primary");
		$("#btn-test-enrollments").removeClass("btn-success");
		$("#btn-test-enrollments").removeClass("btn-warning");
		$("#btn-test-enrollments").removeClass("btn-danger");
		$("#btn-test-enrollments").addClass("btn-primary");
		$('#div-ajax-enrollment-results').addClass("collapse");
		$('#div-ajax-enrollment-errors').addClass("collapse");
		$('#next-product-to-test-idx-hidden').val('0');
		$('.div-cchs-pdf').addClass('collapse');
		var paytype = $('#payment-type-multi-select-dropdown').val();
		var payfreq = $('#payment-freq-multi-select-dropdown').val();
		var indCode = $('#industry-code-multi-select-dropdown').val();
		var enrDate = $('#enrollment-date-datepicker').val();
		var products = $('#products-multi-select-dropdown').val();
		localStorageSetItem('enrollment-date-datepicker',enrDate);
		if (!products || !products.length || !paytype || !paytype.length || !payfreq || !payfreq.length || !indCode || !indCode.length) {
			$('#btn-test-enrollments').prop('disabled',true);
		} else {
			$('#btn-test-enrollments').prop('disabled',false);
		}
	});
	
	
	
	/*********************************************************************************************************
	* initialize products-multi-select-dropdown
	* *******************************************************************************************************/
	$('#products-multi-select-dropdown').val(localStorageGetItem('products-multi-select-dropdown'));
    $('#products-multi-select-dropdown').selectpicker({ noneSelectedText: 'Select Product(s}' });
    $('#products-multi-select-dropdown').prop('disabled',true);
    $('#products-multi-select-dropdown').selectpicker('refresh');
	$('#products-multi-select-dropdown').on('change',function() {
		doNotification('warning','Note','You Changed Product Selection');
		$("#btn-search-products").removeClass("btn-success");
		$("#btn-search-products").removeClass("btn-danger");
		$("#btn-search-products").addClass("btn-primary");
		$("#btn-test-enrollments").removeClass("btn-success");
		$("#btn-test-enrollments").removeClass("btn-warning");
		$("#btn-test-enrollments").removeClass("btn-danger");
		$("#btn-test-enrollments").addClass("btn-primary");
		$('#div-ajax-enrollment-results').addClass("collapse");
		$('#div-ajax-enrollment-errors').addClass("collapse");
		$('#next-product-to-test-idx-hidden').val('0');
		$('.div-cchs-pdf').addClass('collapse');
		var paytype = $('#payment-type-multi-select-dropdown').val();
		var payfreq = $('#payment-freq-multi-select-dropdown').val();
		var indCode = $('#industry-code-multi-select-dropdown').val();
		var enrDate = $('#enrollment-date-datepicker').val();
		var products = $('#products-multi-select-dropdown').val();
		if (!products || !products.length) {
			$('#btn-view-selected-deductibles').prop('disabled',true);
		} else {
			$('#btn-view-selected-deductibles').prop('disabled',false);
		}
		if (!products || !products.length || !paytype || !paytype.length || !payfreq || !payfreq.length || !indCode || !indCode.length) {
			$('#btn-test-enrollments').prop('disabled',true);
		} else {
			$('#btn-test-enrollments').prop('disabled',false);
		}
		
		// product combo options, product options, and add ons, are only available as test-input selections
		// when dealing with a single product to test, and not when selecting multiple products to test.
		if ((products && products.length>1) || !products || products.length<1) {
			$('#div-product-level-inputs').addClass('collapse');
			$('#product-combo-options-select-dropdown').prop('disabled',true);
			$('#product-combo-options-select-dropdown').selectpicker('refresh');
			$('#product-options-select-dropdown').prop('disabled',true);
			$('#product-options-select-dropdown').selectpicker('refresh');
		} else {
			$('#div-product-level-inputs').removeClass('collapse');
			$('#product-combo-options-select-dropdown').prop('disabled',false);
			$('#product-combo-options-select-dropdown').selectpicker('refresh');
			$('#product-options-select-dropdown').prop('disabled',false);
			$('#product-options-select-dropdown').selectpicker('refresh');
		}

		//once user has selected only 1 product, we need to then populate the extra drop down lists
		if (products && 1==products.length) {
			populateProductComboOptionsDropdown(globalvar_allProductPlansMap[products[0]].productComboOptions);
			populateProductOptionsDropdown(globalvar_allProductPlansMap[products[0]].productOptions);
			populateProductAdditionalsDropdown(globalvar_allProductPlansMap[products[0]].productAdditionals);
		}

	});

	
	/*********************************************************************************************************
	* initialize product-level inputs - they should be invisible to start with (since there are no products
	* selected)
	* *******************************************************************************************************/
	$('#div-product-level-inputs').addClass('collapse');
	
	/*********************************************************************************************************
	* initialize product-combo-options-select-dropdown
	* *******************************************************************************************************/
	$('#product-combo-options-select-dropdown').selectpicker({noneSelectedText: 'Select A Product Combo Option'});
    $('#product-combo-options-select-dropdown').selectpicker('refresh');
	$('#product-combo-options-select-dropdown').on('change',function() {
		doNotification('warning','Note','You Changed Product Combo Option');
		$("#btn-search-products").removeClass("btn-success");
		$("#btn-search-products").removeClass("btn-danger");
		$("#btn-search-products").addClass("btn-primary");
		$("#btn-test-enrollments").removeClass("btn-success");
		$("#btn-test-enrollments").removeClass("btn-warning");
		$("#btn-test-enrollments").removeClass("btn-danger");
		$("#btn-test-enrollments").addClass("btn-primary");
		$('#div-ajax-enrollment-results').addClass("collapse");
		$('#div-ajax-enrollment-errors').addClass("collapse");
		$('#product-combo-options-select-dropdown').removeClass('alert-danger');
		$('#product-combo-options-select-dropdown').selectpicker('refresh');
		$('#next-product-to-test-idx-hidden').val('0');
		$('.div-cchs-pdf').addClass('collapse');
		var comboOpt = $('#product-combo-options-select-dropdown').val();
		var paytype = $('#payment-type-multi-select-dropdown').val();
		var payfreq = $('#payment-freq-multi-select-dropdown').val();
		var indCode = $('#industry-code-multi-select-dropdown').val();
		var products = $('#products-multi-select-dropdown').val();
		if (!products || !products.length || !paytype || !paytype.length || !payfreq || !payfreq.length || !indCode || !indCode.length) {
			$('#btn-test-enrollments').prop('disabled',true);
		} else {
			$('#btn-test-enrollments').prop('disabled',false);
		}

	});


	
	
	/*********************************************************************************************************
	* initialize product-options-select-dropdown
	* *******************************************************************************************************/
	$('#product-options-select-dropdown').selectpicker({noneSelectedText: 'Select A Product Option'});
    $('#product-options-select-dropdown').selectpicker('refresh');
	$('#product-options-select-dropdown').on('change',function() {
		doNotification('warning','Note','You Changed Product Option');
		$("#btn-search-products").removeClass("btn-success");
		$("#btn-search-products").removeClass("btn-danger");
		$("#btn-search-products").addClass("btn-primary");
		$("#btn-test-enrollments").removeClass("btn-success");
		$("#btn-test-enrollments").removeClass("btn-warning");
		$("#btn-test-enrollments").removeClass("btn-danger");
		$("#btn-test-enrollments").addClass("btn-primary");
		$('#div-ajax-enrollment-results').addClass("collapse");
		$('#div-ajax-enrollment-errors').addClass("collapse");
		$('#product-options-select-dropdown').removeClass('alert-danger');
		$('#product-options-select-dropdown').selectpicker('refresh');
		$('#next-product-to-test-idx-hidden').val('0');
		$('.div-cchs-pdf').addClass('collapse');
		var options = $('#product-options-select-dropdown').val();
		var paytype = $('#payment-type-multi-select-dropdown').val();
		var payfreq = $('#payment-freq-multi-select-dropdown').val();
		var indCode = $('#industry-code-multi-select-dropdown').val();
		var products = $('#products-multi-select-dropdown').val();
		if (!products || !products.length || !paytype || !paytype.length || !payfreq || !payfreq.length || !indCode || !indCode.length) {
			$('#btn-test-enrollments').prop('disabled',true);
		} else {
			$('#btn-test-enrollments').prop('disabled',false);
		}
	});


	/*********************************************************************************************************
	* initialize btn-view-selected-deductibles
	* *******************************************************************************************************/
	$('#btn-view-selected-deductibles').prop('disabled',true);
	$('#btn-view-selected-deductibles').on('click',function() {
		
		viewSelectedDeductibles();
	});
	
	
	
	$('#btn-clear-inputs').on('click',function() {
		localStorageClearItems();
		location.reload();
	});
	
	$('#btn-cancel-test').prop('disabled',true);
	$('#btn-cancel-test').on('click',function() {
		globalvar_userRequestedCancelTest = true;
	});
	
	
});
