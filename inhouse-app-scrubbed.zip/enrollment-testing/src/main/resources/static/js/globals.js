var globalvar_displayEnrollmentErrorsTable = false;
var globalvar_displayEnrollmentResultsTable = false;
var globalvar_allProductPlansMap = {};
var globalvar_enrollmentResults = null;

var globalvar_enrollmentResultsTableRowIdx = 0;
var globalvar_createdDialogIdsMap = {}; // used to destroy all created dialogs at once
var globalvar_createdDialogIdsArray; // used to destroy all created dialogs at once


var globalvar_paramsForEachIndividualTest = [];

var globalvar_userRequestedCancelTest = false;