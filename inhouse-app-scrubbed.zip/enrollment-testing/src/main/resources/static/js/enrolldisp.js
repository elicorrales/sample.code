///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function enrollmentDetails(tableRowIdx, result) {
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	var error = null;
	var debugMessage = null;
	var validationErrors = null;
	try {
		error = JSON.parse(result.errorMessage);
		debugMessage = (error?error.debugMessage:null);
		validationErrors = (error?error.validationErrors:null);
	} catch (err) {
		error = err;
	}

	var detailsHtml = '<div class="w-75">';

	if (validationErrors) {
		
			detailsHtml += ''
			    + '<div>'
			    + '<table class="table table-bordered table-hover">'
			    + (debugMessage?'<tr class="alert-danger"><td class="col-md-2">Debug Msg:</td><td class="col-md-10">' + debugMessage + '</td></tr>':'');
			$.each(validationErrors,function(i,vError) {
				detailsHtml += ''
				+ '<tr class="alert-danger"><td class="col-md-2">Field:</td><td class="col-md-10">' + vError.field + '</td></tr>'
				+ '<tr class="alert-danger"><td class="col-md-2">Rejected Value:</td><td class="col-md-10">' + vError.rejectedValue + '</td></tr>'
				+ '<tr class="alert-danger"><td class="col-md-2">Message:</td><td class="col-md-10">' + vError.message + '</td></tr>';
			});
				detailsHtml += ''
				+ '</table></div>';

			detailsHtml += "<p/>";
			
	} else if (error) {
		
			detailsHtml += ''
			    + '<div>'
			    + '<table class="table table-bordered table-hover">'
			    + (debugMessage?'<tr class="alert-danger"><td class="col-md-2">Debug Msg:</td><td class="col-md-10">' + debugMessage + '</td></tr>':'')
				+ '<tr class="alert-danger"><td class="col-md-2">Error:</td><td class="col-md-10">' + JSON.stringify(error) + '</td></tr>'
				+ '</table></div>';

			detailsHtml += "<p/>";
			
	}


	if (result.productPlan) {

			detailsHtml += '<button type="button" class="btn btn-info btn-md btn-block" data-toggle="collapse" data-target="#div-tbl-enr-res-prd-det-' + tableRowIdx + '">Product</button>'
			    + '<div id="div-tbl-enr-res-prd-det-' + tableRowIdx + '" class="collapse">'
			    + '<table class="table table-bordered table-hover">'
				+ '<tr><td class="col-md-2">Product Id:</td><td class="col-md-10">' + result.productPlan.prodGenSeq + '</td></tr>'
				+ '<tr><td class="col-md-2">Product Type:</td><td class="col-md-10">' + result.productPlan.productTypeCode + '</td></tr>'
				+ '<tr><td class="col-md-2">Product Name:</td><td class="col-md-10">' + result.productPlan.name + '</td></tr>'
				+ '<tr><td class="col-md-2">Annual Price:</td><td class="col-md-10">' + result.productPlan.annualPrice + '</td></tr>'
				+ '<tr><td class="col-md-2">Deductible:</td><td class="col-md-10">' + result.productPlan.deductible + '</td></tr>'
				+ '<tr><td class="col-md-2">Dormant Days:</td><td class="col-md-10">' + result.productPlan.dormantDays + '</td></tr>'
				+ '<tr><td class="col-md-2">Client Id:</td><td class="col-md-10">' + result.productPlan.clientId + '</td></tr>'
				+ '<tr><td class="col-md-2">Cell Code:</td><td class="col-md-10">' + result.productPlan.cellCode + '</td></tr>'
				+ '<tr><td class="col-md-2">State:</td><td class="col-md-10">' + result.productPlan.state + '</td></tr>'
				+ '<tr><td class="col-md-2">Tax Rate:</td><td class="col-md-10">' + result.productPlan.taxRate + '</td></tr>'
				+ '<tr><td class="col-md-2">Aggr Cap:</td><td class="col-md-10">' + result.productPlan.aggregateCap + '</td></tr>'
				+ '<tr><td class="col-md-2">Client Id:</td><td class="col-md-10">' + result.productPlan.clientId + '</td></tr>'
				+ '</table></div>';

			detailsHtml += "<p/>";
			
			if (result.productPlan.baseCoverage) {
				detailsHtml += '<button type="button" class="btn btn-info btn-block" data-toggle="collapse" data-target="#div-tbl-enr-res-prd-base-' + tableRowIdx + '">Product : Base Coverage</button>'
				+ '<div id="div-tbl-enr-res-prd-base-' + tableRowIdx + '" class="collapse">'
				+ '<table class="table table-bordered table-hover">';
				for (var i=0; i < result.productPlan.baseCoverage.length; i++) {
					detailsHtml += '<tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"></td></tr>'
					+ '<tr><td class="col-md-2">Category Id:</td><td class="col-md-10">' + result.productPlan.baseCoverage[i].categoryId + '</td></tr>'
					+ '<tr><td class="col-md-2">Description:</td><td class="col-md-10">' + result.productPlan.baseCoverage[i].description + '</td></tr>'
					+ '<tr><td class="col-md-2">Qty Covered By Default:</td><td class="col-md-10">' + result.productPlan.baseCoverage[i].quantityCoveredByDefault + '</td></tr>'
					+ '<tr><td class="col-md-2">Max Additional Qty:</td><td class="col-md-10">' + result.productPlan.baseCoverage[i].maxAdditionalQuantity + '</td></tr>';
				}
				detailsHtml += '</table></div>';
			} else {
				detailsHtml += '<table class="table table-bordered table-hover"><tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"><h4>Product : No Base Coverage</h4></td></tr>'
					+ '<tr><td class="col-md-2" colspan="2" border="0"></td></tr></table>';
			}

			detailsHtml += "<p/>";

			if (result.productPlan.billingTerms) {

				detailsHtml += '<button type="button" class="btn btn-info btn-block" data-toggle="collapse" data-target="#div-tbl-enr-res-prd-bill-' + tableRowIdx + '">Product : Billing Terms</button>'
				+ '<div id="div-tbl-enr-res-prd-bill-' + tableRowIdx + '" class="collapse">'
				+ '<table class="table table-bordered table-hover">';

				for (var i=0; i < result.productPlan.billingTerms.length; i++) {
					detailsHtml += '<tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"></td></tr>'
					+ '<tr><td class="col-md-2">Billg Mech Code:</td><td class="col-md-10">' + result.productPlan.billingTerms[i].billingMechanismCode + '</td></tr>'
					+ '<tr><td class="col-md-2">Description:</td><td class="col-md-10">' + result.productPlan.billingTerms[i].description + '</td></tr>'
					+ '<tr><td class="col-md-2">Enrllmt Type:</td><td class="col-md-10">' + result.productPlan.billingTerms[i].enrollmentType + '</td></tr>'
					+ '<tr><td class="col-md-2">Industry Code:</td><td class="col-md-10">' + result.productPlan.billingTerms[i].industryCode + '</td></tr>'
					+ '<tr><td class="col-md-2">Pymt Frequency:</td><td class="col-md-10">' + result.productPlan.billingTerms[i].paymentFrequency + '</td></tr>'
					+ '<tr><td class="col-md-2">Pymt Frequency:</td><td class="col-md-10">' + result.productPlan.billingTerms[i].industryCode + '</td></tr>'
					+ '<tr><td class="col-md-2">Pymt Plan Id:</td><td class="col-md-10">' + result.productPlan.billingTerms[i].paymentPlanId + '</td></tr>';
				}
				detailsHtml += '</table></div>';
				
			} else {
				detailsHtml += '<table class="table table-bordered table-hover"><tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"><h4>Product : No Billing Terms</h4></td></tr>'
					+ '<tr><td class="col-md-2" colspan="2" border="0"></td></tr></table>';
			}


			detailsHtml += "<p/>";

			if (result.productPlan.categories) {

				detailsHtml += '<button type="button" class="btn btn-info btn-block" data-toggle="collapse" data-target="#div-tbl-enr-res-prd-cat-' + tableRowIdx + '">Product : Categories</button>'
				+ '<div id="div-tbl-enr-res-prd-cat-' + tableRowIdx + '" class="collapse">'
				+ '<table class="table table-bordered table-hover">';

				for (var i=0; i < result.productPlan.categories.length; i++) {
					detailsHtml += '<tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"></td></tr>'
					+ '<tr><td class="col-md-10">' + result.productPlan.categories[i] + '</td></tr>';
				}
				detailsHtml += '</table></div>';
				
			} else {
				detailsHtml += '<table class="table table-bordered table-hover"><tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"><h4>Product : No Categories</h4></td></tr>'
					+ '<tr><td class="col-md-2" colspan="2" border="0"></td></tr></table>';
			}


			detailsHtml += "<p/>";

			if (result.productPlan.deductibleBuydowns) {

				detailsHtml += '<button type="button" class="btn btn-info btn-block" data-toggle="collapse" data-target="#div-tbl-enr-res-prd-buy-' + tableRowIdx + '">Product : Deductible Buydowns</button>'
				+ '<div id="div-tbl-enr-res-prd-buy-' + tableRowIdx + '" class="collapse">'
				+ '<table class="table table-bordered table-hover">';

				for (var i=0; i < result.productPlan.deductibleBuydowns.length; i++) {
					var buydownCost = (result.productPlan.deductibleBuydowns[i].buydownCost!=0 && result.productPlan.deductibleBuydowns[i].buydownCost!=''?result.productPlan.deductibleBuydowns[i].buydownCost:'N/A');
					detailsHtml += '<tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"></td></tr>'
					+ '<tr><td class="col-md-2">Deductble:</td><td class="col-md-10">' + result.productPlan.deductibleBuydowns[i].newDeductible + '</td></tr>'
					+ '<tr><td class="col-md-2">Buydown Cost:</td><td class="col-md-10">' + buydownCost + '</td></tr>';
				}
				detailsHtml += '</table></div>';
				
			} else {
				detailsHtml += '<table class="table table-bordered table-hover"><tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"><h4>Product : No Deductible Buydowns</h4></td></tr>'
					+ '<tr><td class="col-md-2" colspan="2" border="0"></td></tr></table>';
			}



			detailsHtml += "<p/>";

			if (result.productPlan.productComboOptions) {

				detailsHtml += '<button type="button" class="btn btn-info btn-block" data-toggle="collapse" data-target="#div-tbl-enr-res-prd-combopt-' + tableRowIdx + '">Product : Combo Options</button>'
				+ '<div id="div-tbl-enr-res-prd-combopt-' + tableRowIdx + '" class="collapse">'
				+ '<table class="table table-bordered table-hover">';

				for (var i=0; i < result.productPlan.productComboOptions.length; i++) {
					detailsHtml += '<tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"></td></tr>'
					+ '<tr><td class="col-md-2">Item Id:</td><td class="col-md-10">' + result.productPlan.productComboOptions[i].comboItemId + '</td></tr>'
					+ '<tr><td class="col-md-2">Cost:</td><td class="col-md-10">' + result.productPlan.productComboOptions[i].cost + '</td></tr>'
					+ '<tr><td class="col-md-2">Cost Per Additional Item:</td><td class="col-md-10">' + result.productPlan.productComboOptions[i].costPerAdditionalItem + '</td></tr>'
					+ '<tr><td class="col-md-2">Description:</td><td class="col-md-10">' + result.productPlan.productComboOptions[i].description + '</td></tr>'
					+ '<tr><td class="col-md-2">Max Additional Qty:</td><td class="col-md-10">' + result.productPlan.productComboOptions[i].maxAdditionalQuantity + '</td></tr>'
					+ '<tr><td class="col-md-2">Qty Covered By Default:</td><td class="col-md-10">' + result.productPlan.productComboOptions[i].quantityCoveredByDefault + '</td></tr>'
					+ '<tr><td class="col-md-2">Qty Selected:</td><td class="col-md-10">' + result.productPlan.productComboOptions[i].quantitySelected + '</td></tr>'
					;
				}
				detailsHtml += '</table></div>';
				
			} else {
				detailsHtml += '<table class="table table-bordered table-hover"><tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"><h4>Product : No Combo Options</h4></td></tr>'
					+ '<tr><td class="col-md-2" colspan="2" border="0"></td></tr></table>';
			}


			detailsHtml += "<p/>";

			if (result.productPlan.productOptions) {

				detailsHtml += '<button type="button" class="btn btn-info btn-block" data-toggle="collapse" data-target="#div-tbl-enr-res-prd-opt-' + tableRowIdx + '">Product : Options</button>'
				+ '<div id="div-tbl-enr-res-prd-opt-' + tableRowIdx + '" class="collapse">'
				+ '<table class="table table-bordered table-hover">';

				for (var i=0; i < result.productPlan.productOptions.length; i++) {
					detailsHtml += '<tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"></td></tr>'
					+ '<tr><td class="col-md-2">Category Id:</td><td class="col-md-10">' + result.productPlan.productOptions[i].categoryId + '</td></tr>'
					+ '<tr><td class="col-md-2">Cost:</td><td class="col-md-10">' + result.productPlan.productOptions[i].cost + '</td></tr>'
					+ '<tr><td class="col-md-2">Cost Per Additional Item:</td><td class="col-md-10">' + result.productPlan.productOptions[i].costPerAdditionalItem + '</td></tr>'
					+ '<tr><td class="col-md-2">Description:</td><td class="col-md-10">' + result.productPlan.productOptions[i].description + '</td></tr>'
					+ '<tr><td class="col-md-2">Max Additional Qty:</td><td class="col-md-10">' + result.productPlan.productOptions[i].maxAdditionalQuantity + '</td></tr>'
					+ '<tr><td class="col-md-2">Qty Covered By Default:</td><td class="col-md-10">' + result.productPlan.productOptions[i].quantityCoveredByDefault + '</td></tr>'
					+ '<tr><td class="col-md-2">Qty Selected:</td><td class="col-md-10">' + result.productPlan.productOptions[i].quantitySelected + '</td></tr>'
					;
				}
				detailsHtml += '</table></div>';
				
			} else {
				detailsHtml += '<table class="table table-bordered table-hover"><tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"><h4>Product : No Options</h4></td></tr>'
					+ '<tr><td class="col-md-2" colspan="2" border="0"></td></tr></table>';
			}







	} else {
			detailsHtml += '<table class="table table-bordered table-hover"><tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"><h4>No Product Info</h4></td></tr>'
				+ '<tr><td class="col-md-2" colspan="2" border="0"></td></tr></table>';
	}

	
	// end of Product, start of Enrollment
	
	detailsHtml += '</div><div style="min-height: 50px" class="w-75"></div><div class="w-75">';


	if (result.enrollment) {

		detailsHtml += '<button type="button" class="btn btn-info btn-block" data-toggle="collapse" data-target="#div-tbl-enr-res-enroll-' + tableRowIdx + '">Enrollment</button>'
				+ '<div id="div-tbl-enr-res-enroll-' + tableRowIdx + '" class="collapse">'
				+ '<table class="table table-bordered table-hover">';

		detailsHtml += ''
				+ '<tr><td class="col-md-2">Product Id:</td><td class="col-md-10">' + result.enrollment.productId + '</td></tr>'
				+ '<tr><td class="col-md-2">Tax:</td><td class="col-md-10">' + result.enrollment.tax + '</td></tr>'
				+ '<tr><td class="col-md-2">Base Deductible:</td><td class="col-md-10">' + result.enrollment.baseDeductible + '</td></tr>'
				+ '<tr><td class="col-md-2">Base Premium Price:</td><td class="col-md-10">' + result.enrollment.basePremiumPrice + '</td></tr>'
				+ '<tr><td class="col-md-2">Total Premium Price:</td><td class="col-md-10">' + result.enrollment.totalPremiumPrice + '</td></tr>'
				+ '<tr><td class="col-md-2">Enrollment Date:</td><td class="col-md-10">' + result.enrollment.enrollmentDate + '</td></tr>'
				+ '<tr><td class="col-md-2">Effective Date:</td><td class="col-md-10">' + result.enrollment.effectiveDate + '</td></tr>'
				+ '<tr><td class="col-md-2">Expiration Date:</td><td class="col-md-10">' + result.enrollment.expirationDate + '</td></tr>'
				+ '<tr><td class="col-md-2">Purchase Type Code:</td><td class="col-md-10">' + result.enrollment.purchaseTypeCode + '</td></tr>'
				+ '<tr><td class="col-md-2">Unit Type Code:</td><td class="col-md-10">' + result.enrollment.unitTypeCode + '</td></tr>'
				+ '<tr><td class="col-md-2">Product Type Code:</td><td class="col-md-10">' + result.enrollment.productTypeCode + '</td></tr>'
				+ '<tr><td class="col-md-2">Enrollment Confirmation:</td><td class="col-md-10">' + result.enrollment.enrollmentConfirmation + '</td></tr>'
				+ '</table></div>';


		detailsHtml += "<p/>";

		if (result.enrollment.clientInfo) {
			detailsHtml += '<button type="button" class="btn btn-info btn-block" data-toggle="collapse" data-target="#div-tbl-enr-res-enroll-cli-' + tableRowIdx + '">Enrollment : Client Info</button>'
				+ '<div id="div-tbl-enr-res-enroll-cli-' + tableRowIdx + '" class="collapse">'
				+ '<table class="table table-bordered table-hover">';

			detailsHtml += ''
				+ '<tr><td class="col-md-2">Affiliate Id:</td><td class="col-md-10">' + result.enrollment.clientInfo.affiliateId + '</td></tr>'
				+ '<tr><td class="col-md-2">Agent Name:</td><td class="col-md-10">' + result.enrollment.clientInfo.agentName + '</td></tr>'
				+ '<tr><td class="col-md-2">Ccm Id:</td><td class="col-md-10">' + result.enrollment.clientInfo.ccmId + '</td></tr>'
				+ '<tr><td class="col-md-2">Cell:</td><td class="col-md-10">' + result.enrollment.clientInfo.cellCode + '</td></tr>'
				+ '<tr><td class="col-md-2">Client:</td><td class="col-md-10">' + result.enrollment.clientInfo.clientCode + '</td></tr>'
				+ '<tr><td class="col-md-2">Xref Id:</td><td class="col-md-10">' + result.enrollment.clientInfo.clientXrefId + '</td></tr>'
				+ '<tr><td class="col-md-2">Company Code:</td><td class="col-md-10">' + result.enrollment.clientInfo.companyCode + '</td></tr>'
				+ '<tr><td class="col-md-2">Extrnl Ccm Id:</td><td class="col-md-10">' + result.enrollment.clientInfo.externalCcmId + '</td></tr>'
				+ '<tr><td class="col-md-2">Industry:</td><td class="col-md-10">' + result.enrollment.clientInfo.industryCode + '</td></tr>'
				+ '<tr><td class="col-md-2">Supplmt Ccm Id:</td><td class="col-md-10">' + result.enrollment.clientInfo.supplementaryCcmId + '</td></tr>'
				+ '</table></div>';
		} else {
			detailsHtml += '<table class="table table-bordered table-hover"><tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"><h4>Enrollment : No Client Info</h4></td></tr>'
				+ '<tr><td class="col-md-2" colspan="2" border="0"></td></tr></table>';
		}


		detailsHtml += "<p/>";

		if (result.enrollment.billingAddress) {
			detailsHtml += '<button type="button" class="btn btn-info btn-block" data-toggle="collapse" data-target="#div-tbl-enr-res-bill-adr-' + tableRowIdx + '">Enrollment : Billing Address</button>'
				+ '<div id="div-tbl-enr-res-bill-adr-' + tableRowIdx + '" class="collapse">'
				+ '<table class="table table-bordered table-hover">';

			detailsHtml += ''
				+ '<tr><td class="col-md-2">Address1:</td><td class="col-md-10">' + result.enrollment.billingAddress.addressLine1 + '</td></tr>'
				+ '<tr><td class="col-md-2">Address2:</td><td class="col-md-10">' + result.enrollment.billingAddress.addressLine2 + '</td></tr>'
				+ '<tr><td class="col-md-2">Address3:</td><td class="col-md-10">' + result.enrollment.billingAddress.addressLine3 + '</td></tr>'
				+ '<tr><td class="col-md-2">City:</td><td class="col-md-10">' + result.enrollment.billingAddress.city + '</td></tr>'
				+ '<tr><td class="col-md-2">Country:</td><td class="col-md-10">' + result.enrollment.billingAddress.country + '</td></tr>'
				+ '<tr><td class="col-md-2">County:</td><td class="col-md-10">' + result.enrollment.billingAddress.county + '</td></tr>'
				+ '<tr><td class="col-md-2">State:</td><td class="col-md-10">' + result.enrollment.billingAddress.state + '</td></tr>'
				+ '<tr><td class="col-md-2">Zip:</td><td class="col-md-10">' + result.enrollment.billingAddress.zip + '</td></tr>'
				+ '</table></div>';
		} else {
			detailsHtml += '<table class="table table-bordered table-hover"><tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"><h4>Enrollment : No Billing Address</h4></td></tr>'
				+ '<tr><td class="col-md-2" colspan="2" border="0"></td></tr></table>';
		}


		detailsHtml += "<p/>";

		if (result.enrollment.deductibleBuydown) {

			detailsHtml += '<button type="button" class="btn btn-info btn-block" data-toggle="collapse" data-target="#div-tbl-enr-res-enr-ded-' + tableRowIdx + '">Enrollment : Deductible Buydown</button>'
				+ '<div id="div-tbl-enr-res-enr-ded-' + tableRowIdx + '" class="collapse">'
				+ '<table class="table table-bordered table-hover">';

			var buydownCost = (result.enrollment.deductibleBuydown.buydownCost!=0 && result.enrollment.deductibleBuydown.buydownCost!=''?result.enrollment.deductibleBuydown.buydownCost:'N/A');
			detailsHtml += ''
				+ '<tr><td class="col-md-2">Deductible:</td><td class="col-md-10">' + result.enrollment.deductibleBuydown.newDeductible + '</td></tr>'
				+ '<tr><td class="col-md-2">Buydown Cost:</td><td class="col-md-10">' + buydownCost + '</td></tr>'
				+ '</table></div>';
		} else {
			detailsHtml += '<table class="table table-bordered table-hover"><tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"><h4>Enrollment : No Deductible Buydown</h4></td></tr>'
				+ '<tr><td class="col-md-2" colspan="2" border="0"></td></tr></table>';
		}


		detailsHtml += "<p/>";

		if (result.enrollment.paymentInformation) {

			detailsHtml += '<button type="button" class="btn btn-info btn-block" data-toggle="collapse" data-target="#div-tbl-enr-res-enr-pay-' + tableRowIdx + '">Enrollment : Payment Info</button>'
				+ '<div id="div-tbl-enr-res-enr-pay-' + tableRowIdx + '" class="collapse">'
				+ '<table class="table table-bordered table-hover">';

			detailsHtml += ''
				+ '<tr><td class="col-md-2">Bank Acct Info:</td><td class="col-md-10">' + result.enrollment.paymentInformation.bankAccountInformation + '</td></tr>'
				+ '<tr><td class="col-md-2">Billing Mechanism Code:</td><td class="col-md-10">' + result.enrollment.paymentInformation.billingMechanismCode + '</td></tr>'
				+ '<tr><td class="col-md-2">Payment Frequency:</td><td class="col-md-10">' + result.enrollment.paymentInformation.paymentFrequency + '</td></tr>'
				+ '</table></div>';
		} else {
			detailsHtml += '<table class="table table-bordered table-hover"><tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"><h4>Enrollment : No Payment Info</h4></td></tr>'
				+ '<tr><td class="col-md-2" colspan="2" border="0"></td></tr></table>';
		}


		detailsHtml += "<p/>";

		if (result.enrollment.paymentInformation && result.enrollment.paymentInformation.creditCardInformation) {

			detailsHtml += '<button type="button" class="btn btn-info btn-block" data-toggle="collapse" data-target="#div-tbl-enr-res-enr-pay-cc-' + tableRowIdx + '">Enrollment : Payment Info : Credit Card Info</button>'
				+ '<div id="div-tbl-enr-res-enr-pay-cc-' + tableRowIdx + '" class="collapse">'
				+ '<table class="table table-bordered table-hover">';

			detailsHtml += ''
				+ '<tr><td class="col-md-2">CC# :</td><td class="col-md-10">' + result.enrollment.paymentInformation.creditCardInformation.creditCardNumber + '</td></tr>'
				+ '<tr><td class="col-md-2">Type Code:</td><td class="col-md-10">' + result.enrollment.paymentInformation.creditCardInformation.creditCardTypeCode + '</td></tr>'
				+ '<tr><td class="col-md-2">Expr Date:</td><td class="col-md-10">' + result.enrollment.paymentInformation.creditCardInformation.expirationDate + '</td></tr>'
				+ '<tr><td class="col-md-2">Expr Month:</td><td class="col-md-10">' + result.enrollment.paymentInformation.creditCardInformation.expirationMonth + '</td></tr>'
				+ '<tr><td class="col-md-2">Expr Year:</td><td class="col-md-10">' + result.enrollment.paymentInformation.creditCardInformation.expirationYear + '</td></tr>'
				+ '<tr><td class="col-md-2">First Name:</td><td class="col-md-10">' + result.enrollment.paymentInformation.creditCardInformation.holderFirstName + '</td></tr>'
				+ '<tr><td class="col-md-2">Last Name:</td><td class="col-md-10">' + result.enrollment.paymentInformation.creditCardInformation.holderLastName + '</td></tr>'
				+ '<tr><td class="col-md-2">Middle Name:</td><td class="col-md-10">' + result.enrollment.paymentInformation.creditCardInformation.holderMiddleName + '</td></tr>'
				+ '<tr><td class="col-md-2">Sec Code:</td><td class="col-md-10">' + result.enrollment.paymentInformation.creditCardInformation.securityCode + '</td></tr>'
				+ '</table></div>';
		} else {
			detailsHtml += '<table class="table table-bordered table-hover"><tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"><h4>Enrollment : Payment Info : No Credit Card Info</h4></td></tr>'
				+ '<tr><td class="col-md-2" colspan="2" border="0"></td></tr></table>';
		}


		detailsHtml += "<p/>";

		if (result.enrollment.primaryCustomer) {
			detailsHtml += '<button type="button" class="btn btn-info btn-block" data-toggle="collapse" data-target="#div-tbl-enr-res-enr-pri-' + tableRowIdx + '">Enrollment : Primary Customer</button>'
				+ '<div id="div-tbl-enr-res-enr-pri-' + tableRowIdx + '" class="collapse">'
				+ '<table class="table table-bordered table-hover">';

			detailsHtml += ''
				+ '<tr><td class="col-md-2">Email:</td><td class="col-md-10">' + result.enrollment.primaryCustomer.email + '</td></tr>'
				+ '<tr><td class="col-md-2">Gender:</td><td class="col-md-10">' + result.enrollment.primaryCustomer.genderCode + '</td></tr>'
				+ '<tr><td class="col-md-2">Birth Date:</td><td class="col-md-10">' + result.enrollment.primaryCustomer.birthDate + '</td></tr>'
				+ '</table></div>';
		} else {
			detailsHtml += '<table class="table table-bordered table-hover"><tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"><h4>Enrollment : No Primary Customer</h4></td></tr>'
				+ '<tr><td class="col-md-2" colspan="2" border="0"></td></tr></table>';
		}


		detailsHtml += "<p/>";

		if (result.enrollment.primaryCustomer && result.enrollment.primaryCustomer.address) {

			detailsHtml += '<button type="button" class="btn btn-info btn-block" data-toggle="collapse" data-target="#div-tbl-enr-res-enr-pri-adr-' + tableRowIdx + '">Enrollment : Primary Customer : Address</button>'
				+ '<div id="div-tbl-enr-res-enr-pri-adr-' + tableRowIdx + '" class="collapse">'
				+ '<table class="table table-bordered table-hover">';

			detailsHtml += ''
				+ '<tr><td class="col-md-2">Address Line 1:</td><td class="col-md-10">' + result.enrollment.primaryCustomer.address.addressLine1 + '</td></tr>'
				+ '<tr><td class="col-md-2">Address Line 2:</td><td class="col-md-10">' + result.enrollment.primaryCustomer.address.addressLine2 + '</td></tr>'
				+ '<tr><td class="col-md-2">Address Line 3:</td><td class="col-md-10">' + result.enrollment.primaryCustomer.address.addressLine3 + '</td></tr>'
				+ '<tr><td class="col-md-2">City:</td><td class="col-md-10">' + result.enrollment.primaryCustomer.address.city + '</td></tr>'
				+ '<tr><td class="col-md-2">State:</td><td class="col-md-10">' + result.enrollment.primaryCustomer.address.state + '</td></tr>'
				+ '<tr><td class="col-md-2">Zip:</td><td class="col-md-10">' + result.enrollment.primaryCustomer.address.zip + '</td></tr>'
				+ '<tr><td class="col-md-2">County:</td><td class="col-md-10">' + result.enrollment.primaryCustomer.address.county + '</td></tr>'
				+ '<tr><td class="col-md-2">Country:</td><td class="col-md-10">' + result.enrollment.primaryCustomer.address.country + '</td></tr>'
				+ '</table></div>';
		} else {
			detailsHtml += '<table class="table table-bordered table-hover"><tr><td class="col-md-2" colspan="2" align="center" style="background-color:lightgrey"><h4>Enrollment : Primary Customer : No Address</h4></td></tr>'
				+ '<tr><td class="col-md-2" colspan="2" border="0"></td></tr></table>';
		}


	}
	

	detailsHtml += "</div><p/>";

	return detailsHtml;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function convertDialogIdsMapToArray() {
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	globalvar_createdDialogIdsArray = [];
	
	$.each(globalvar_createdDialogIdsMap,function(i,diag) {

		globalvar_createdDialogIdsArray.push(diag);
	});
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function showEnrollmentErrorDetails(dialogId, tableRowIdx, result) {
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	var detailsHtml = enrollmentDetails(tableRowIdx, result);
	$(dialogId).html( detailsHtml );
	doDialog(dialogId,false);
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function showEnrollmentResultDetails(dialogId, tableRowIdx,result) {
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	var detailsHtml = enrollmentDetails(tableRowIdx, result);
	$(dialogId).html( detailsHtml );
	doDialog(dialogId,false);
}

	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function showEnrollmentErrorJsonRequest(dialogId, tableRowIdx, result) {
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	var jsonRequestHtml = '<pre>' + (result?JSON.stringify(result.enrollment,null,4):'No Json Request') + '</pre>';
	$(dialogId).html( jsonRequestHtml );
	doDialog(dialogId,false);
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function showEnrollmentJsonRequest(dialogId, tableRowIdx, result) {
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	var jsonRequestHtml = '<pre>' + (result?JSON.stringify(result.enrollment,null,4):'No Json Request') + '</pre>';
	$(dialogId).html( jsonRequestHtml );
	doDialog(dialogId,false);
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function showEnrollmentResult(i,result) {
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	var uniqId      = getCurrentTime();
	var tableRowIdx = globalvar_enrollmentResultsTableRowIdx + '-' + uniqId;
	
	var productPlan = result.productPlan;
	var enrollment  = result.enrollment;
	
	var buydownCost = 0;
	var deductible  = 0;

	if (enrollment && enrollment.deductibleBuydown) {
		deductible  = enrollment.deductibleBuydown.newDeductible;
	} 
	
	
	// with default , and only the default buydown, there's not such thing as a buydown cost, so put 'N/A'
	// with default , and it has at least one other buydown, but we're using the default - put '0' for cost
	if (useDefaultDeductible()) {
		
		if (productPlan && productPlan.deductibleBuydowns && productPlan.deductibleBuydowns.length > 1) {
			buydownCost = 0;
		} else {
			buydownCost = 'N/A';
		}

		if (enrollment && enrollment.deductibleBuydown && enrollment.deductibleBuydown.newDeductible) {
			deductible = enrollment.deductibleBuydown.newDeductible;
		} else if (productPlan && productPlan.deductible) {
			deductible = productPlan.deductible;
		}
		
	// with testing ALL, there may still be only the default, or more than one deductible buydown
	} else {
		
		if (enrollment && enrollment.deductibleBuydown) {
			buydownCost = (productPlan && productPlan.deductibleBuydowns && productPlan.deductibleBuydowns.length > 1 ? enrollment.deductibleBuydown.buydownCost : 'N/A');
			deductible  = enrollment.deductibleBuydown.newDeductible;
		} else if (productPlan) {
			deductible  = productPlan.deductible;
			buydownCost = productPlan.deductibleBuydowns;
		}
	}
	

	if (result.errorMessage) {
		
		globalvar_displayEnrollmentErrorsTable = true;

		var error = null;
		var errorMessage = null;
		var debugMessage = null;
		try {
			error = JSON.parse(result.errorMessage);
			errorMessage = (error && error.backendApiResultBody?error.backendApiResultBody.message:'No Error Msg');
			debugMessage = (error && error.backendApiResultBody?error.backendApiResultBody.debugMessage:'No Debug Msg');
		} catch (err) {
			error = result.errorMessage;
		}

		var dialogId    = 'enr-error-details-dialog-' + tableRowIdx;

		var dialogHtml =  '<div id="' + dialogId + '" title="Enrollment Error Details: ' + (productPlan?productPlan.prodGenSeq:'No Prod Id!!') 
						+ '  Buydown Cost: ' + buydownCost
						+ '  Deductible: '   + deductible +  '"></div>';

		var enrollmentErrorRow = '<tr id="td-enr-err-'+ globalvar_enrollmentResultsTableRowIdx +'" class="alert-danger">'
						+ '<td>' + globalvar_enrollmentResultsTableRowIdx + '</td>'
						+ '<td>' + (productPlan?productPlan.prodGenSeq:'no prod id') + '</td>'
						+ '<td>' + (productPlan?productPlan.name:'no prod name') + '</td>'
						+ '<td>'
						+ (enrollment && enrollment.paymentInformation?enrollment.paymentInformation.billingMechanismCode:'No Pym Type')
						+ '/<br/>'
						+ (enrollment && enrollment.paymentInformation?enrollment.paymentInformation.paymentFrequency:'No Pym Freq')
						+ '</td>'
						+ '<td>' + (enrollment && enrollment.clientInfo?enrollment.clientInfo.industryCode:'No Ind Code') + '</td>'
						+ '<td>' + (enrollment?enrollment.totalPremiumPrice:'No Totl Prm Price') + '</td>'
						+ '<td>' + buydownCost + '</td>'
						+ '<td>' + deductible + '</td>'
						+ '<td>' + (debugMessage?debugMessage+'<br/>':'') + (errorMessage?errorMessage+'<br/>':'') + (!debugMessage && !errorMessage && error?error+'<br/>':'') 
								+ '<a id="td-enr-err-details-' + globalvar_enrollmentResultsTableRowIdx + '" href="#">More Details</a>'
								+ '<br/><a id="td-enr-err-req-json-' + globalvar_enrollmentResultsTableRowIdx + '" href="#">Raw JSON Request</a>'
								+ dialogHtml + '</td>'
						+'</tr>';



		
		$('#table-enrollment-errors tbody').append(enrollmentErrorRow);
		$('#td-enr-err-details-' + globalvar_enrollmentResultsTableRowIdx).on('click',function(e) { e.preventDefault(); showEnrollmentErrorDetails('#' + dialogId , tableRowIdx , result); });
		$('#td-enr-err-req-json-' + globalvar_enrollmentResultsTableRowIdx).on('click',function(e) { e.preventDefault(); showEnrollmentErrorJsonRequest('#' + dialogId , tableRowIdx , result); });

			

	} else {

		globalvar_displayEnrollmentResultsTable = true;

		var dialogId    = 'enr-details-dialog-' + tableRowIdx;

		var dialogHtml =  '<div id="' + dialogId + '" title="Product Enrollment Details: ' + (productPlan?productPlan.prodGenSeq:'No Prod Id!!') 
						+ '  Buydown Cost: ' + buydownCost
						+ '  Deductible: ' + deductible +  '"></div>';

		
		var enrollmentRow = 
						'<tr id="td-enr-res-'+ globalvar_enrollmentResultsTableRowIdx +'">'
						+ '<td>' + globalvar_enrollmentResultsTableRowIdx + '</td>'
						+ '<td>' + (productPlan?productPlan.prodGenSeq:'') + '</td>'
						+ '<td>' + (productPlan?productPlan.name:'') + '</td>'
						+ '<td>'
						+ (enrollment && enrollment.paymentInformation?enrollment.paymentInformation.billingMechanismCode:'')
						+ '/<br/>'
						+ (enrollment && enrollment.paymentInformation?enrollment.paymentInformation.paymentFrequency:'')
						+ '</td>'
						+ '<td>' + (enrollment && enrollment.clientInfo?enrollment.clientInfo.industryCode:'No Ind Code') + '</td>'
						+ '<td>' + (enrollment?enrollment.totalPremiumPrice:'') + '</td>'
						+ '<td>' + buydownCost + '</td>'
						+ '<td>' + deductible + '</td>'
						+ '<td>' + result.contractNumber + '</td>'
						+ '<td>'
						+ '<a id="td-enr-res-details-' + globalvar_enrollmentResultsTableRowIdx + '" href="#">More</a>'
						+ '<br/><a id="td-enr-req-json-' + globalvar_enrollmentResultsTableRowIdx + '" href="#">Raw JSON Request</a>'
						+ dialogHtml
						+ '</td>'
						+ '<td><a id="' + result.contractNumber + '" href="#">Contract Details</a>'
						+ '</td>'
						+'</tr>';
		
		$('#table-enrollment-results tbody').append(enrollmentRow);
		$('#td-enr-res-details-' + globalvar_enrollmentResultsTableRowIdx).on('click',function(e){ e.preventDefault(); showEnrollmentResultDetails('#' + dialogId , tableRowIdx , result); });
		$('#td-enr-req-json-' + globalvar_enrollmentResultsTableRowIdx).on('click',function(e) { e.preventDefault(); showEnrollmentJsonRequest('#' + dialogId , tableRowIdx , result); });
		$('#' + result.contractNumber).on('click',function(){ fireAjax_SubmitMainContractInfoSearch(result.contractNumber); });
	}

	globalvar_enrollmentResultsTableRowIdx++;
}

