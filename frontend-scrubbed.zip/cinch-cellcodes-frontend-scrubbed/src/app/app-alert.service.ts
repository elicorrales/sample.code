import { OnChanges, EventEmitter, Output } from "@angular/core";

export class AppAlertService {

    _appSuccessAlerts:string[] = [];
    _appInfoAlerts:string[] = [];
    _appWarningAlerts:string[] = [];
    _appErrorAlerts:string[] = [];

    @Output() newAlerts = new EventEmitter();

    appSuccessAlerts() { return this._appSuccessAlerts.slice(); }
    appInfoAlerts() { return this._appInfoAlerts.slice(); }
    appWarningAlerts() { return this._appWarningAlerts.slice(); }
    appErrorAlerts() { return this._appErrorAlerts.slice(); }

    clearAllAlerts() {
        this._appSuccessAlerts.length = 0;
        this._appInfoAlerts.length = 0;
        this._appWarningAlerts.length = 0;
        this._appErrorAlerts.length = 0;
        this.newAlerts.emit();
    }

    addSuccessAlert(alert:string) {
        this._appSuccessAlerts.push(alert);
        this.newAlerts.emit();
    }

    addInfoAlert(alert:string) {
        this._appInfoAlerts.push(alert);
        this.newAlerts.emit();
    }

    addWarningAlert(alert:string) {
        this._appWarningAlerts.push(alert);
        this.newAlerts.emit();
    }

    addErrorAlert(error:any) {

        let alert = '';

        if (undefined !== error.error) {
            if (undefined !== error.error.error) {
                alert = (error.error.error + (undefined !== error.message?' : ' + error.message:'') + (undefined !== error.error.message?' : ' + error.error.message :''));
            } else {
                alert = error.error;
            }
        } else {
             alert = error;
        }

        this._appErrorAlerts.push(alert);
        this.newAlerts.emit();
    }

}