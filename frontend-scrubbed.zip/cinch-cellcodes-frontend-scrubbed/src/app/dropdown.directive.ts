import { Directive , HostListener, HostBinding } from '@angular/core';

@Directive({
  selector: '[appDropdown]'
})
export class DropdownDirective {

  constructor() { }

  @HostBinding('class.open') isOpen:boolean = false;

  @HostListener('click') toggleClickOpen() { this.isOpen = !this.isOpen; } 
  @HostListener('mouseover') toggleMouseOverOpen() { this.isOpen = true; } 
  @HostListener('mouseleave') toggleMouseLeaveOpen() { this.isOpen = false; } 


}
