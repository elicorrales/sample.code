import { EventEmitter, Injectable, OnInit } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { AppAlertService } from './app-alert.service';
import { CellCodeEntry } from "./cell-code-entry.model";

@Injectable()
export class CellCodeService implements OnInit {

    cellCodeSelected   = new EventEmitter<CellCodeEntry>();
    cellCodesReceived  = new EventEmitter();
    cellCodeAdded    = new EventEmitter();
    cellCodeDeleted    = new EventEmitter();
    cellCodeUpdated    = new EventEmitter();

    doEditCellCodeMode:EventEmitter<boolean>     = new EventEmitter<boolean>();
    doDeleteCellCodeMode:EventEmitter<boolean>   = new EventEmitter<boolean>();


    getAllUrl = '/entries?';
    getOneUrl = '/entry/';
    addUrl = '/entry/create';
    delUrl = '/entry/delete';
    updUrl = '/entry/update';

    private _cellCodes:CellCodeEntry[] = [ ];

    constructor(private http:HttpClient,private appAlertService:AppAlertService) { }

    ngOnInit() {
        this._cellCodes = [];
    }

    cellCodes() {
        return this._cellCodes;
    }

    getOneCellCode(cellCode:CellCodeEntry) {
        this.http.get(this.getOneUrl + '/' + cellCode.cellCode).subscribe(
            (response) => {
                if (undefined !== response && null !== response && '' !== response) {
                    this.appAlertService.addErrorAlert('Cell Code ' + cellCode.cellCode + ' was NOT deleted.');
                }
            },
            (error) => { this.appAlertService.addErrorAlert(error); },
            () => { console.log('TfnsService. http get complete'); }
        );
    }

    getAllCellCodes() {
        this._cellCodes = [];
        this.http.get(this.getAllUrl).subscribe(
            (cellCodes) => {

                if (undefined !== cellCodes && null !== cellCodes && '' !== cellCodes) {

                    Object.keys(cellCodes).map((key,value) => {
                        const cellCode = cellCodes[key];
                        this._cellCodes.push(new CellCodeEntry(cellCode.id,cellCode.cellCode,cellCode.tollFree,cellCode.cellCodeStartDate,cellCode.cellCodeEndDate,cellCode.createdBy));
                    });
                    this.cellCodesReceived.emit();
                    this.appAlertService.addSuccessAlert('Existing Cell Codes Retrieved');
                }
            },
            (error) => { this.appAlertService.addErrorAlert(error); },
            () => { }
        );
    }

    addCellCode(cellCode:CellCodeEntry) {

        this.http.post(this.addUrl, cellCode).subscribe(
            (response) => {
                this.cellCodeAdded.emit();
                this.appAlertService.addSuccessAlert('New Cell Code ' + cellCode.cellCode + ' Added.');
                this.appAlertService.addInfoAlert('Change may Not reflect immediately. Try browser refresh after a few seconds');
            },
            (error) => { this.appAlertService.addErrorAlert(error); },
            () => { console.log('TfnsService.addTfn() :  http post complete'); }


        );
    }


    deleteCellCode(cellCode:CellCodeEntry) {

        this.http.delete(this.delUrl + '/' + cellCode.id).subscribe(
            (response) => {
                this.getOneCellCode(cellCode);
                this.cellCodeDeleted.emit();
                this.appAlertService.addSuccessAlert('Cell Code ' + cellCode.cellCode + ' Deleted.');
                this.appAlertService.addInfoAlert('Change may Not reflect immediately. Try browser refresh after a few seconds');
                this.doDeleteCellCodeMode.emit(false);
            },
            (error) => { this.appAlertService.addErrorAlert(error); },
            () => { console.log('TfnsService. http delete complete'); }
        );
    }

    updateCellCode(cellCode:CellCodeEntry) {

        this.http.put(this.updUrl,cellCode).subscribe(
            (response) => {
                this.getOneCellCode(cellCode);
                this.cellCodeUpdated.emit();
                this.appAlertService.addSuccessAlert('Cell Code ' + cellCode.cellCode + ' Updated.');
                this.appAlertService.addInfoAlert('Change may Not reflect immediately. Try browser refresh after a few seconds');
                this.doEditCellCodeMode.emit(false);
            },
            (error) => { this.appAlertService.addErrorAlert(error); },
            () => { console.log('TfnsService. http update complete'); }
        );
    }

}
