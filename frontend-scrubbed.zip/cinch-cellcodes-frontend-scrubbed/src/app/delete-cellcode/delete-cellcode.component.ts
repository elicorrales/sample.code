import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CellCodeService } from '../cellcode.service';
import { AppAlertService } from '../app-alert.service';
import { CellCodeEntry } from '../cell-code-entry.model';

@Component({
  selector: 'app-delete-cellcode',
  templateUrl: './delete-cellcode.component.html',
  styleUrls: ['./delete-cellcode.component.css']
})
export class DeleteCellCodeComponent implements OnInit {

  @Input() selectedCellCode:CellCodeEntry;

  @Input() cellCode = '';
  @Input() tollFree = '';
  @Input() cellCodeStartDate = '';
  @Input() cellCodeEndDate = '';
  @Input() createdBy = '';

  //@ViewChild('deleteCellCodeForm') deleteCellCodeForm: NgForm;

  constructor(private cellCodesService:CellCodeService,private appAlertService:AppAlertService) { }

  ngOnInit() {
    this.cellCode = this.selectedCellCode.cellCode;
    this.tollFree = this.selectedCellCode.tollFree;
    this.cellCodeStartDate = this.selectedCellCode.cellCodeStartDate;
    this.cellCodeEndDate = this.selectedCellCode.cellCodeEndDate;
    this.createdBy = this.selectedCellCode.createdBy;
    console.log(this.cellCodeStartDate);
  }

  onCancel() {
    this.cellCodesService.doDeleteCellCodeMode.emit(false);
  }

  onSubmit() {
    this.appAlertService.clearAllAlerts();
    this.cellCodesService.deleteCellCode(this.selectedCellCode);
  }
}
