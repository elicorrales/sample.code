import { CellCodeEntry } from '../cell-code-entry.model';
import { Component, OnInit, OnChanges } from '@angular/core';
import { CellCodeService } from '../cellcode.service';
import { AppAlertService } from '../app-alert.service';

@Component({
  selector: 'app-cellcode-list',
  templateUrl: './cellcode-list.component.html',
  styleUrls: ['./cellcode-list.component.css']
})
export class CellCodeListComponent implements OnInit {

  cellCodes:CellCodeEntry[] = [];

  constructor(private cellCodeService:CellCodeService,private appAlertService:AppAlertService) { }

  ngOnInit() {

    this.cellCodeService.getAllCellCodes();

    this.cellCodeService.cellCodesReceived.subscribe(
      (cellCodes) => { this.cellCodes = this.cellCodeService.cellCodes(); },
      (error) => { console.log('TfnListComponent : fnsReceived : subscribed : error'); },
      () => { }
    );

    this.cellCodeService.cellCodeAdded.subscribe(
      (response) => { console.log('TfnListComponent : tfnAdded : subscribed : response ' + response); this.cellCodes = this.cellCodeService.cellCodes(); },
      (error) => { console.log('TfnListComponent : tfnAdded : subscribed : error'); },
      () => { }
    );

    this.cellCodeService.cellCodeDeleted.subscribe(
      (response) => { console.log('TfnListComponent : tfnDeleted : subscribed : response ' + response); this.cellCodes = this.cellCodeService.cellCodes(); },
      (error) => { console.log('TfnListComponent : tfnDeleted : subscribed : error'); },
      () => { }
    );

  }

  onEdit(i) {
    this.appAlertService.clearAllAlerts();
    this.cellCodeService.cellCodeSelected.emit(this.cellCodes[i]);
    this.cellCodeService.doEditCellCodeMode.emit(true);
  }

  onDelete(i) {
    this.appAlertService.clearAllAlerts();
    this.cellCodeService.cellCodeSelected.emit(this.cellCodes[i]);
    this.cellCodeService.doDeleteCellCodeMode.emit(true);
  }

}
