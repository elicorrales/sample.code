import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CellCodeService } from '../cellcode.service';
import { AppAlertService } from '../app-alert.service';
import { CellCodeEntry } from '../cell-code-entry.model';

@Component({
  selector: 'app-edit-cellcode',
  templateUrl: './edit-cellcode.component.html',
  styleUrls: ['./edit-cellcode.component.css']
})
export class EditCellCodeComponent implements OnInit {

  @Input() selectedCellCode:CellCodeEntry;

  @Input() cellCode = '';
  @Input() tollFree = '';
  @Input() cellCodeStartDate = '2018-10-10';
  @Input() cellCodeEndDate = '2018-10-10';
  @Input() createdBy = '';

  //@ViewChild('editCellCodeForm') editCellCodeForm: NgForm;

  constructor(private cellCodesService:CellCodeService,private appAlertService:AppAlertService) { }

  ngOnInit() {
    this.cellCode = this.selectedCellCode.cellCode;
    this.tollFree = this.selectedCellCode.tollFree;
    //this.cellCodeStartDate = this.selectedCellCode.cellCodeStartDate;
    //this.cellCodeEndDate = this.selectedCellCode.cellCodeEndDate;
    this.createdBy = this.selectedCellCode.createdBy;
  }

  onCancel() {
    this.cellCodesService.doEditCellCodeMode.emit(false);
  }

  onSubmit() {
    this.appAlertService.clearAllAlerts();
    this.selectedCellCode.cellCode = this.cellCode;
    this.selectedCellCode.tollFree = this.tollFree;
    this.selectedCellCode.cellCodeStartDate = this.cellCodeStartDate;
    this.selectedCellCode.cellCodeEndDate   = this.cellCodeEndDate;
    this.selectedCellCode.createdBy         = this.createdBy;
    console.log(this.selectedCellCode.id);
    console.log(this.selectedCellCode.cellCode);
    console.log(this.selectedCellCode.tollFree);
    console.log(this.selectedCellCode.cellCodeStartDate);
    console.log(this.selectedCellCode.cellCodeEndDate);
    console.log(this.selectedCellCode.createdBy);
    //this.cellCodesService.updateCellCode(this.selectedCellCode);
  }
}
