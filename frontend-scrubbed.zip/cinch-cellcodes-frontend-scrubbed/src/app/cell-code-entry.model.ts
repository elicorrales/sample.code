import { DateFormatter } from "ngx-bootstrap/datepicker";

export class CellCodeEntry {

    id:string = '';
    cellCode:string = '';
    tollFree:string = '';
    cellCodeStartDate:string = '';
    cellCodeEndDate:string = '';
    createdBy:string = '';

    constructor(id:string,cellcode:string,phone:string,startDate:string,endDate:string,createdBy:string) {

        this.id = id;
        this.cellCode = cellcode;
        this.tollFree = phone;
        let sdate = new Date(startDate);
        let syear = sdate.getFullYear();
        let smon  = sdate.getMonth().toString().length<2?'0'+ (sdate.getMonth()+1):(sdate.getMonth()+1);
        let sday  = sdate.getDay().toString().length<2?'0'+ (sdate.getDay()+1):(sdate.getDay()+1);
        let startDateString = syear + '-' + smon + '-' + sday;
        this.cellCodeStartDate = startDateString;
        let edate = new Date(startDate);
        let eyear = edate.getFullYear();
        let emon  = edate.getMonth().toString().length<2?'0'+ (edate.getMonth()+1):(edate.getMonth()+1);
        let eday  = edate.getDay().toString().length<2?'0'+ (edate.getDay()+1):(edate.getDay()+1);
        let endDateString = eyear + '-' + emon + '-' + eday;
        this.cellCodeEndDate = endDateString;
        this.createdBy = createdBy;
    }
}