import { CellCodeService } from './cellcode.service';
import { Component, OnInit, OnChanges, Input } from '@angular/core';
import { CellCodeEntry } from './cell-code-entry.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit  {

  @Input() theCellCodeSelected:CellCodeEntry;
  @Input() cellCodeSelected:boolean = false;
  @Input() doEditCellCodeMode:boolean   = false;
  @Input() doDeleteCellCodeMode:boolean   = false;

  constructor(private cellCodesService:CellCodeService) { }

  ngOnInit() {
    this.cellCodesService.cellCodeSelected.subscribe(
      (cellCode:CellCodeEntry) => {
        this.cellCodeSelected = true;
        this.theCellCodeSelected = cellCode;
      }
    );
    this.cellCodesService.doEditCellCodeMode.subscribe(
      (value:boolean) => {
        this.doEditCellCodeMode = value;
      }
    );
    this.cellCodesService.doDeleteCellCodeMode.subscribe(
      (value:boolean) => {
        this.doDeleteCellCodeMode = value;
      }
    );
  }

}
