import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CellCodeService } from '../cellcode.service';
import { AppAlertService } from '../app-alert.service';
import { CellCodeEntry } from '../cell-code-entry.model';

@Component({
  selector: 'app-new-cellcode',
  templateUrl: './new-cellcode.component.html',
  styleUrls: ['./new-cellcode.component.css']
})
export class NewCellCodeComponent implements OnInit {

  cellCode = '';
  tollFree = '';
  cellCodeStartDate = '';
  cellCodeEndDate = '';
  createdBy = 'Enrollment-Testing-App';


  constructor(private cellCodesService:CellCodeService,private appAlertService:AppAlertService) { }

  ngOnInit() {
  }


  onSubmit() {
    this.appAlertService.clearAllAlerts();
    this.cellCodesService.addCellCode(new CellCodeEntry('',this.cellCode,this.tollFree,this.cellCodeStartDate,this.cellCodeEndDate,this.createdBy));
  }
}
