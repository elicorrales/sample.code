import { AppAlertService } from '../app-alert.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cellcode-alert',
  templateUrl: './cellcode-alert.component.html',
  styleUrls: ['./cellcode-alert.component.css']
})
export class TfnAlertComponent implements OnInit {

  appSuccessAlerts:string[] = [];
  appInfoAlerts:string[] = [];
  appWarningAlerts:string[] = [];
  appErrorAlerts:string[] = [];

  constructor(private appAlertService:AppAlertService) { }

  ngOnInit() {
    this.appAlertService.newAlerts.subscribe(
      () => {
        this.appSuccessAlerts = this.appAlertService.appSuccessAlerts();
        this.appInfoAlerts = this.appAlertService.appInfoAlerts();
        this.appWarningAlerts = this.appAlertService.appWarningAlerts();
        this.appErrorAlerts = this.appAlertService.appErrorAlerts();
      }
    );
  }

}
