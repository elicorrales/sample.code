import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
//import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AlertModule } from 'ngx-bootstrap/alert';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { NewCellCodeComponent } from './new-cellcode/new-cellcode.component';
import { EditCellCodeComponent } from './edit-cellcode/edit-cellcode.component';
import { DeleteCellCodeComponent } from './delete-cellcode/delete-cellcode.component';
import { CellCodeListComponent } from './cellcode-list/cellcode-list.component';
import { DropdownDirective } from './dropdown.directive';
import { TfnAlertComponent } from './cellcode-alert/cellcode-alert.component';

import { CellCodeService } from './cellcode.service';
import { AppAlertService } from './app-alert.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    NewCellCodeComponent,
    EditCellCodeComponent,
    DeleteCellCodeComponent,
    CellCodeListComponent,
    DropdownDirective,
    TfnAlertComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    //BsDatepickerModule.forRoot(),
    NgbModule.forRoot(),
    AlertModule.forRoot()
  ],
  providers: [CellCodeService,AppAlertService],
  bootstrap: [AppComponent]
})
export class AppModule { }
